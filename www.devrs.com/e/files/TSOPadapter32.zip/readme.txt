Custom adapter for 32 pin TSOP Flash memory

Introduction:

This is a PCB artwork to make a custom adapter for programming 32 pin TSOP package flash memory chips on Jeff Frowein's Rev C flash programmer circuit (plans available from the same place you got this). It was designed to work on this programmer but should also work on several commercial programmers. The design intent is to enable the end user to save money by making their own adapter PCB and buy only the socket instead of buying the pre-assembled AS-32-32-01TS-6YAM-GANG-S adapter from Emulation Technologies which is about double the price of the socket only.

Parts:

To make this circuit, you will need:

- 1 TSOP socket part no. S-TSO-00-032-E from Emulation Technologies (www.emulation.com)
- 1 blank PCB about 1.5 x 2 inches (presensitized photoresist or bare copper)
- some wire for the jumpers
- header strips for the DIP socket legs

Note:

No additional instructions provided, use your imagination. Built and fully tested by your truly and garanteed to work if done with skill and care. Electronic projects experience and tools required. Not for beginners.

Tucker