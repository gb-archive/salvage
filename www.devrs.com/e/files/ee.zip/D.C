#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <time.h>

#define DELAY   delay(wait_delay)

/* Change those defines to match your compiler. */
#define OUTPORT(port, val)	outp(port, val); DELAY
#define INPORT(port)		inp(port)

#define CTRL    ctrl_port
#define DATA    data_port
#define STATUS  status_port

/*
 * Bits for MUX (C B A):
 *      ~AUTOFDXT ~SCLINT ~STROBE
 * Bits in CTRL register (7..0):
 *      N/A N/A N/A IRQEnable ~SCLINT INIT ~AUTOFDXT ~STROBE
 */

#define MASK            0x00
#define nSTROBE         0x01
#define nAUTOFDXT       0x02
#define INIT            0x04
#define nSCLINT         0x08

/* CTRL MUX */
#define GET_LOW         MASK | nAUTOFDXT | nSCLINT | nSTROBE
#define GET_HIGH        MASK | nAUTOFDXT | nSCLINT
#define LOW_ADDR        MASK | nAUTOFDXT           | nSTROBE
#define HIGH_ADDR       MASK | nAUTOFDXT
#define SET_DATA        MASK |             nSCLINT | nSTROBE
#define DATA_REG        MASK |             nSCLINT
#define NOT_USED        MASK |                       nSTROBE
#define NOP             MASK

/* CTRL U3 */
#define MREQ            MASK | INIT

/* Load a register: toggle CK (OFF and ON) */
#define LOAD(reg)       OUTPORT(CTRL, reg); OUTPORT(CTRL, NOP)

/* Put data on the bus */
#define WRITE(val)      OUTPORT(DATA, val)

/* Write data in bank-switch IC */
#define WRITE_BKSW      WRITE(0x00); OUTPORT(CTRL, SET_DATA); \
						WRITE(0x01); WRITE(0x00); OUTPORT(CTRL, NOP)

/* Write data in RAM */
#define WRITE_MEM       WRITE(0x00); OUTPORT(CTRL, SET_DATA); \
						OUTPORT(CTRL, SET_DATA | MREQ); WRITE(0x01); \
						WRITE(0x00); OUTPORT(CTRL, NOP)

/*
 * Bits read (7..0):
 *      BUSY ~ACKPR PE SLCT ERROR N/A N/A N/A
 * Bits from REGISTER (D7..D4, D3..D0):
 *      SLCT PE BUSY ~ACK
 */
#define READ_LOW(val)       OUTPORT(CTRL, GET_LOW); val = INPORT(STATUS)
#define READ_HIGH(val)      OUTPORT(CTRL, GET_HIGH); val = INPORT(STATUS)
#define READ_MEM_LOW(val)   OUTPORT(CTRL, GET_LOW | MREQ); val = INPORT(STATUS)
#define READ_MEM_HIGH(val)  OUTPORT(CTRL, GET_HIGH | MREQ); val = INPORT(STATUS)
#define D7(val)             (val & 0x10) << 3
#define D6(val)             (val & 0x20) << 1
#define D5(val)             ((val ^ 0x80) & 0x80) >> 2
#define D4(val)             (val & 0x40) >> 2
#define D3(val)             (val & 0x10) >> 1
#define D2(val)             (val & 0x20) >> 3
#define D1(val)             ((val ^ 0x80) & 0x80) >> 6
#define D0(val)             (val & 0x40) >> 6
#define CONVERT(l, h)       D7(h) | D6(h) | D5(h) | D4(h) | D3(l)  | D2(l)  | D1(l)  | D0(l)

#define NO_MBC  0
#define MBC1    1
#define MBC2    2

#ifdef MK_FP
  #undef MK_FP
#endif
#define MK_FP(seg, ofs)     ((void far *) ((unsigned long) (seg)<<16|(ofs)))


int wait_delay;
unsigned ctrl_port;
unsigned data_port;
unsigned status_port;

void usage()
{
	printf("Usage: read [-p int] [-w int] [-t | -d | -a | -s file | -b file | -r file]\n");
	printf("\t-p\tSpecify the port to use (default is 1 = LPT1)\n");
	printf("\t-w\tSpecify the time to wait between accesses to the cartridge\n");
	printf("\t-t\tDebug mode (if the cartridge reader don't work)\n");
	printf("\t-t\tTest the cartridge reader\n");
	printf("\t-a\tAnalyze the cartridge\n");
	printf("\t-s\tSave the cartridge in a file\n");
	printf("\t-b\tBackup the SRAM and save it in a file\n");
	printf("\t-r\tRestore the SRAM from a file\n");
}


int init_port(int port)
{
	data_port = *(unsigned far *)MK_FP(0x0040, 6 + 2*port);
	if(data_port == 0)
	{
		printf("Can't find address of parallel port %d...\n", port);
		exit(1);
	} else {
		status_port = data_port + 1;
		ctrl_port = data_port + 2;
		printf("Parallel port %d is located at %Xh\n", port, data_port);
	}
}

void delay(int d)
{
	while(d--);
}

void write_byte(int i)
{

	OUTPORT(DATA,i);    OUTPORT(CTRL, nSTROBE); OUTPORT(CTRL, 0);
	OUTPORT(DATA,i<<1); OUTPORT(CTRL, nSTROBE); OUTPORT(CTRL, 0);
	OUTPORT(DATA,i<<2); OUTPORT(CTRL, nSTROBE); OUTPORT(CTRL, 0);
	OUTPORT(DATA,i<<3); OUTPORT(CTRL, nSTROBE); OUTPORT(CTRL, 0);

	// Write byte & Inc to next memory location

	OUTPORT(CTRL, nAUTOFDXT); OUTPORT(CTRL, 0);
}

void main(int argc, char **argv)
{
	int arg;
	FILE *fp;
	char fname[20];

	wait_delay = 10;

	printf("Eprom Emulator Downloader V1.0, Jeff Frohwein\n\n");

	strcpy(fname,argv[1]);
	if (strchr(fname,'.') == NULL)
	 strcat(fname,".gb");

	if ((fp = fopen(fname, "rb")) == NULL)
	{
	    printf("Error opening file %s\n", fname);
	    exit(1);
	}

	init_port(1);

// Set Reset Line

	OUTPORT(CTRL, 0);

// Reset Address Counters to Zero

	OUTPORT(CTRL, nAUTOFDXT); OUTPORT(CTRL, 0);

// Send whole data file to eprom emulator


	while (!feof(fp))
	 write_byte(fgetc(fp));

//Release Reset

	OUTPORT(CTRL, INIT);

	exit(0);
}
