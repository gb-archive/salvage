Custom adapter for 48 pin TSOP Flash memory

Introduction:

This is a PCB artwork to make a custom adapter specifically for programming 48 pin TSOP package AM29F400B type flash memory chips on Jeff Frowein's Rev C flash programmer circuit (plans available from the same place you got this). It was designed to work on this programmer ONLY and cannot be garanteed to work on other programmers. The design intent is to enable the end user to program AM29F400B 8bit/16bit type flash memory TSOP chips on this programmer although it was not originally supposed to be able to.

Parts:

To make this circuit, you will need:

- 1 TSOP socket part no. S-TSO-00-048-C from Emulation Technologies (www.emulation.com)
- 1 blank PCB about 2.5 x 2 inches (presensitized photoresist or bare copper)
- some wire for the jumpers
- header strips for the DIP socket legs

Note:

No additional instructions provided, use your imagination. Built and fully tested by your truly and garanteed to work if done with skill and care. Electronic projects experience and tools required. Not for beginners.

Tucker