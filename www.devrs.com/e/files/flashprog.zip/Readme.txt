FROHWEIN-TUCKER FLASH PROGRAMMER V 1.0
--------------------------------------


Introduction:
------------

This archive contains all the documents and information you need to build a Flash memory reader/programmer
This circuit and the software to operate it was designed by Jeff Frohwein. The PCB layout and artwork was
designed by me. It's purpose is to provide a way for hobbyists to inexpensively build a unit capable of
programming a certain number of specific memory IC's. It also has a read only capability for certain other
memory types.

Despite its excellent flexibility, this circuit is in no way intended to replace a full-fledged (but much
more expensive) universal programmer. Please consult the compatible device list in the design notes to
verify that it can meet your needs before you decide to build it.


Design notes:
------------

This programmer & software is only designed to support devices which can be programmed with 5 volts only.
As such, EPROMs and some EEPROMs cannot be programmed with this hardware. However, these chips may be read
or verified. For help, type the filename of the program exe at the DOS prompt with no parameters and hit enter.
Please note that for the sake of reliability, it is recommended to run the software in pure DOS instead of a
DOS box in Windows. Although it might work in a DOS box on some PC's, it might not work reliably on some
of the newer and faster machines.

The PCB artwork was designed in Protel for a single-sided board. The main reason for this is that it makes
it much easier for hobbyists to build a board at home using materials commonly found in electronics retail
stores. In order to route all the connections, all the traces that would normally have been routed on the top
side of the board on a double-sided board were replaced by wire jumpers. I have built and tested a board from
this artwork and can assure you that it works fine. Please note that you will need to download the trial version
of Protel from their website to be able to open and print the artwork at an exact 1:1 scale.

IMPORTANT:

The gif image of the copper layer is provided for visual reference only and is not to scale. Do NOT use this
image to print your artwork. The other 2 gif's (jumper map and silkscreen) are intended as assembly guides.
Assemble all the wire jumpers BEFORE assembling the components.


List of read/write compatible devices:
-------------------------------------

The current software supports three different programming algorithms: AMD 29Fxxx, Data Valid, and 10ms.
Here is a list of algorithms and chips that are supported by that algorithm:

=====================

The AMD format is specific to AMD flash EPROM chips. As such it may only work with AMD parts.

- AMD : Am29F256, Am29F512, Am29F010, Am29F002, Am29F040 

=====================

The Data Valid (Data polling) format may be compatible with many different chips. After programming a byte at a memory
location, the same location is continually read until it matches the data written.

- Atmel : AT28C16, AT28C64, AT28C256, AT28C010, AT28C040, AT29C256, AT29C512, AT29C010, AT29C020, AT29C040,
          AT49F512, AT49F001, AT49F010, AT49F002, AT49F020, AT49F040

- Microchip : 28C64A

- SST : SST28SF040A, SST29EE512, SST29EE010, SST29EE020, SST39SF512, SST39SF010, SST39SF020, SST39SF040

- Xicor : X28HC64, X28HC256, X28C512, X28C010, XM28C040

=====================

The 10ms algorithm is needed by some early chips. After data is written to a memory location there is a
delay of 10 milliseconds before the next memory location is written.

- Xicor : X2816

=====================


List of read-only compatible devices:
------------------------------------

Standard EPROM's

2716, 2732, 2764, 27128, 27256, 27512, 27010, 27020



JP1 header position and orientation as seen on PCB layout:
---------------------------------------------------------


                                   +---+
                                   |o o|
                                   |   |
Pin 1 O+-------v-------+o          |o o|
       |               |           |   |
      o+               +o          |o o|
       |               |           |   |
      o+               +o          |o o|
       |               |           |   |
      o+               +o          |o o|
       |               |           |   |
      o+               +o          |o o|
       |               |           |   |
      o+               +o          |o o|
       |               |           |   |
      o+    32 Pin     +o          |o o|
       |     Flash     |           |   |
      o+   IC Socket   +o          |o o|
       |               |           |   |
      o+               +o          |o O| Pin 1
       |               |           +---+
      o+               +o
       |               |
      o+               +o
       |               |
      o+               +o
       |               |
      o+               +o
       |               |
      o+               +o
       |               |
      o+               +o
       |               |
      o+---------------+o



Jumper settings for read/write compatible devices:
-------------------------------------------------

 24 Pin              28 Pin                                32 Pin
 __|__        _________|__________     ______________________|_________________________
/     \      /                    \   /                                                \
                          
 16Kbit       64Kbit       256Kbit      512Kbit      1Mbit        2Mbit        4Mbit
                                                                              
 AT28C16      AT28C64      AT28C256    Am29F512     Am29F010     Am29F002     Am29F040
 X2816        28C64A       AT29C256    AT29C512     AT28C010     AT29C020     AT28C040
              X28HC64                  AT49F512     AT29C010     AT49F002     AT29C040
                                       X28C512      AT49F001     AT49F020     AT49F040
                                       SST29EE512   AT49F010     SST29EE020   XM28C040
                                       SST39SF512   X28C010      SST39SF020   SST39SF040
                                                    SST29EE010                SST28SF040          
                                                    SST39SF010
                                       
  o o          o o          o o          o o          o o          o o          o o
                                                                    +-+          +-+
  o o          o o          o o          o o          o o          o|o|         o|o|
 +-+          +---+        +---+                                    | |          | |
 |o|o         |o o|        |o o|         o o          o o          o|o|         o|o|
 | |          +---+        +---+        +---+        +---+        +-+-+        +-+-+
 |o|o          o o         |o o|        |o o|        |o o|        |o o|        |o o|
 +-+          +---+        +---+        +---+        +---+        +---+        +---+
 |o|o         |o o|        |o o|        |o o|        |o o|        |o o|        |o o|
 | |          +---+        +---+        +-+-+        +-+-+        +-+-+        +-+-+
 |o|o         |o o|        |o o|         o|o|         o|o|         o|o|         o|o|
 +-+          +---+        +---+        +-+ |        +-+ |        +-+ |        +-+ |
  o o          o o         |o o|        |o|o|        |o|o|        |o|o|        |o|o|
                           +---+        | +-+        | +-+        | +-+        | +-+ 
  o o          o o          o o         |o|o         |o|o         |o|o         |o|o
                                        +-+          +-+          +-+          +-+-+
  o o          o o          o o          o o          o o          o o         |o o|
                                                                               +---+
  o O          o O          o O          o O          o O          o O          o O
 


Jumper settings for read-only compatible devices (standard EPROM's):
-------------------------------------------------------------------

       24 Pin                                  28 Pin                                 32 Pin
 ________|_________        ______________________|_____________________        _________|________
/                  \      /                                            \      /                  \
              
  2716         2732         2764        27128        27256        27512        27010        27020
                                                                                           
                           +---+        +---+                                              
  o o          o o         |o o|        |o o|         o o          o o          o o          o o
                           +---+        +---+                                                 +-+
  o o          o o          o o          o o          o o          o o          o o          o|o|
 +-+          +-+          +---+        +---+        +---+        +---+                       | |
 |o|o         |o|o         |o o|        |o o|        |o o|        |o o|         o o          o|o|
 | |          | |          +---+        +---+        +---+        +---+        +---+        +-+-+
 |o|o         |o|o          o o         |o o|        |o o|        |o o|        |o o|        |o o|
 +-+          +-+-+        +---+        +---+        +---+        +---+        +---+        +---+
 |o|o         |o o|        |o o|        |o o|        |o o|        |o o|        |o o|        |o o|
 | |          +---+        +---+        +---+        +-+-+        +-+-+        +-+-+        +-+-+
 |o|o          o o         |o o|        |o o|        |o|o|         o|o|         o|o|         o|o|
 +-+                       +---+        +---+        | | |        +-+ |        +-+ |        +-+ |
  o o          o o          o o          o o         |o|o|        |o|o|        |o|o|        |o|o|
                                                     +-+-+        | +-+        | +-+        | +-+
  o o          o o          o o          o o          o o         |o|o         |o|o         |o|o
                                                                  +-+          +-+          +-+
  o o          o o          o o          o o          o o          o o          o o          o o
                                                                                           
  o O          o O          o O          o O          o O          o O          o O          o O



Position of devices when inserting in programmer socket:
-------------------------------------------------------



Pin 1   O+-------v-------+o  Pin 32     Pin 1   O+               +o  Pin 32     Pin 1   O+               +o  Pin 32
         |               |                                                                                       
        o+               +o                     o+               +o                     o+               +o        
         |               |                                                                                        
        o+               +o                     o+-------v-------+o                     o+               +o        
         |               |                       |               |                                               
        o+               +o                     o+               +o                     o+               +o        
         |               |                       |               |                                               
        o+               +o                     o+               +o                     o+-------v-------+o        
         |               |                       |               |                       |               |         
        o+               +o                     o+               +o                     o+               +o        
         |               |                       |               |                       |               |         
        o+               +o                     o+               +o                     o+               +o        
         |               |                       |               |                       |               |         
        o+    32 Pin     +o                     o+               +o                     o+               +o        
         |    devices    |                       |               |                       |               |         
        o+               +o                     o+    28 Pin     +o                     o+               +o        
         |               |                       |    devices    |                       |               |         
        o+               +o                     o+               +o                     o+     24 Pin    +o        
         |               |                       |               |                       |     devices   |         
        o+               +o                     o+               +o                     o+               +o        
         |               |                       |               |                       |               |         
        o+               +o                     o+               +o                     o+               +o        
         |               |                       |               |                       |               |         
        o+               +o                     o+               +o                     o+               +o        
         |               |                       |               |                       |               |         
        o+               +o                     o+               +o                     o+               +o        
         |               |                       |               |                       |               |         
        o+               +o                     o+               +o                     o+               +o        
         |               |                       |               |                       |               |         
Pin 16  o+---------------+o  Pin 17     Pin 16  o+---------------+o  Pin 17     Pin 16  o+---------------+o  Pin 17




A word of caution:
-----------------

This documentation set is provided for free to those who wish to build their own circuits for fun and educational
purposes ONLY. I DO NOT and WILL NOT build blank PCB's or assembled units for resale so don't bother asking.
No exceptions, sorry.

I should also mention that YOU ARE ON YOUR OWN HERE. If you have trouble with your unit, DON'T email me asking
for guidance or help. The reason is that you made a mistake somewhere along the line and you'll have to
troubleshoot the problem YOURSELF. No exceptions. I have assembled this unit and I have tested all the main
features. They ALL work so there is no question that the design is flawless. If you start trying to substitute
components or make modifications to it, that's fine with me but YOU'RE RESPONSIBLE FOR THE OUTCOME.
My mission in life is NOT to take your hand and assume your "education" in electronics design.


What you will need:
------------------

1. A regular paint tool to open and print the included gif images: schematic diagram, jumper assembly guide
   and component assembly guide.

2. A good quality inkjet printer (600 DPI or more recommended) or even better: a laser printer.

3. The free trial version of Protel CAD. You can download it from http://www.protel.com/etech/trial_home.html
   I know it's a large download but it's absolutely required to print out the transparencies you need for exposing
   your presensitized board. The reason for this is that ONLY this can garantee that your films will be at an
   exact 1:1 scale. Here's how to proceed:
   
   a) install the Protel software
   
   b) extract the unlooper.PCB file included in the zip to the "Program Files\Design Explorer 99\examples"
      folder.
   
   c) open the included Flashprog.pcb file in Protel (make sure you change the file type to *.pcb in the "open
      file" dialog). It will ask if you "The document you selected to open must be imported into a new design
      database...etc.". Click OK and PCB copper layout will load. 
   
   d) The print setup in the file is already configured for the proper layers and options for your film to be
      printed out like it should. Click on the Print toolbar button. Next, select the option:
      
      "<your printer name> final"
      
      from the print dialog that appears and click on the "Options" button. Click on the "Setup" button in the
      following dialog and use your printer's Properties dialog to set the paper type to "Tranparency" and the
      copy quality to the highest possible setting. Click OK till you are back to the first print dialog.
      
      Make sure you have 2 transparencies ready in the printer tray and click on the "Print" button: 2 films
      are required so repeat the above operation one more time.

   e) Cut away some excess blank plastic from one of the films. Carefully superimpose and align it over
      the other. Stick a few short lengths of scotch tape on the edges of the top film to hold both films
      together

4. A good soldering iron with a temperature control or temperature controlled tips. For PCB work, 600 - 700
   degrees Celsius is best. Good quality flush-cut pliers (Xcelite model 170M is inexpensive and works great).

5. A 20,000 RPM Dremel tool with a Dremel drill-press stand accessory. Plus a machinist drill bit set (no. 40
   to no. 80 are needed) Don't even think about making this project if you don't have these tools.

6. A plethora of other miscellaneous hand tools, supplies and accessories too long to list here.

7. A straight-through serial cable and 12V DC (300mA minimum) power supply. Any polarity will do.


Fabrication guidelines:
----------------------

The main difficulty with this board is drilling it without ripping off the pads from the fiberglass base.
The reason is that Protel does not print out the real hole sizes of the pads on the films. Regardless of the
actual hole size, it will print tiny holes in the pads much smaller in diameter than the actual hole size. To
make matters worse, since the printout is a bitmap instead of a vectored based Gerber plot, the "guide holes"
are often NOT exactly in the center of the pads thus causing the actual holes to be eccentric.

Since you have to drill the holes from the bottom side of the board, special care has to be taken in order not
to destroy it. Specifically, you will have to drill the holes in successive steps.

READ THIS, YOU HAVE BEEN WARNED!!

IF YOU TRY TO DRILL THE FINAL HOLE SIZES FROM THE SOLDER SIDE ON THE FIRST RUN, YOU WILL RIP THE PADS RIGHT OFF
THE BOARD AND YOUR UNIT WILL BE SCRAPPED. AS A RESULT, YOU WILL HAVE TO START OVER FROM SCRATCH.

Here's how to do it the right way:

1. First, drill ALL the pad holes with a no. 74 machine drill (0.0225" dia.)
   from the bottom side (of course!).

2. Trial fit components which have very small leads to see which holes won't
   need to be enlarged. The small capacitors are typical examples.

3. Flip the board over and enlarge the existing holes now drilling from the
   component side. Start with a no. 70 (0.028" dia.) and do another trial fit
   run. Most wire jumpers, resistors and IC sockets should fit.

4. Repeat the process now using a no. 67 (0.032" dia.). Components like the
   DB25 connector and 7805 voltage regulator might need their holes enlarged to
   no. 65 (0.035" dia.)

5. The 2mm power jack requires special attention. The final drill size to
   make the leads fit should be around no. 40 (0.098" dia.). BUT, if you try
   to go directly from 0.032" to 0.098", the stress placed on the pad could
   STILL rip it out. So to avoid this, you must go about it in steps and
   enlarge the hole in 0.010" size increments until you reach the final size.
   When you get close to the final size, do a trial fit after each shot and
   try to keep the hole size as small as possible.

6. Generally speaking, ALL your holes must be as small as possible to leave
   as much copper as possible on those pads. The more copper is left, the
   easier it will be to solder those component leads. Since many of the final
   holes will be eccentric, they might be difficult to solder in some cases.

7. Once you can fit the jack leads in to the holes, bend them flat onto the
   copper pad to make them easier to solder. DON'T do this right away tho
   because...

8. You have to assemble and solder ALL the wire jumpers FIRST.

9. Then, assemble all the resistors, IC sockets, etc. Generally work your
   way up by order of component profile (height). Usually, the last to be
   assembled should be the large electrolytic capacitor and toggle switch.

10. Once you're done, always check all the connections of your board versus
    the schematic using an ohmmeter and a yellow highlighter pen to mark the
    conections which checked out. Also check for shorts especially between
    VCC and GND and for shorts between PWR and GND (at the Flash socket pin 32).

11. Plug in the power supply and check all the +5V voltage points.

12. Your programmer is now ready for a functional test. First make sure the
    switch is the OFF position: the LED should be off. Get a sample memory
    IC of a compatible device and set the jumpers accordingly. Plug the IC in
    the socket and flip the switch in the ON position: the LED should light on.
    Perform read, write and verify tests to make sure everything works properly.
    If the chip's content is already known and you have a copy of the .obj file,
    perform a read and save the .obj file under a new name. Compare the 2 .obj
    files in a good text editor which has this capability (like UltraEdit or
    EditPad for example).

13. That's it. You now have a fully functional Flash programmer.


Credits:
-------

Jeff Frohwein: the real brains behind this thing, thanks Jeff :)