3.3V/5V switchable Supply Voltage adapater for
FROHWEIN-TUCKER FLASH PROGRAMMER V 1.0
--------------------------------------


Introduction:
------------

The purpose of this circuit is to provide the capability of programming low voltage type flash memory chips
with Jeff Frohwein's Rev C programmer. Those chips require a 3V to 3.7V power supply. The circuit is
equipped with a jumper that can be set open or closed depending on whether you want to program low voltage
3V flash memories or standard 5V memory chips. Thus the programmer retains all it's previous features too.


Design notes:
------------

This adapter circuit was designed to replace the 7805 voltage regulator normally assembled on the standard
programmer circuit without modifying the existing artwork of the programmer. It has 2 pots which are used
to calibrate the 2 possible voltage levels of the circuit. The lowest voltage output is set by adjusting R3
while the JP1 jumper is closed and the the highest voltage output is set by adjusting R3 while the JP1 jumper
is open.

IMPORTANT:

The gif image of the copper layer is provided for visual reference only and is not to scale. Do NOT use this
image to print your artwork. The other 2 gif's (jumper map and silkscreen) are intended as assembly guides.
Assemble all the wire jumpers BEFORE assembling the components.

The PCB artwork was designed in Protel for a single-sided board. The main reason for this is that it makes
it much easier for hobbyists to build a board at home using materials commonly found in electronics retail
stores. In order to route all the connections, all the traces that would normally have been routed on the top
side of the board on a double-sided board were replaced by wire jumpers. I have built and tested a board from
this artwork and can assure you that it works fine. Please note that you will need to download the trial version
of Protel from their website to be able to open and print the artwork at an exact 1:1 scale.


Assembly instructions:
---------------------

Since the LM317 variable voltage regulator used in this design can set to a value almost as high as
the input voltage (around 12V depending on the transformer you use), it MUST be calibrated BEFORE you
assemble it into the programmer otherwise, you could fry the circuit's TTL logic circuitry. TTL HC type IC's
can operate at voltages from 2V to 6V safely. Once this is done, solder a 3 pin .100 center male header strip
intoe the blank TO-220 footprint on the right hand side of the PCB. The bottom of the header is soldered into
the 7805 footprint on the programmer PCB (7805 regulator must be removed first). Put a plastic standoff between
the adapter PCB and programmer PCB and use the holes normally used for the TO-220 tab screws to fasten the
standoff to both PCB's.


A word of caution:
-----------------

This documentation set is provided for free to those who wish to build their own circuits for fun and educational
purposes ONLY. I DO NOT and WILL NOT build blank PCB's or assembled units for resale so don't bother asking.
No exceptions, sorry.

I should also mention that YOU ARE ON YOUR OWN HERE. If you have trouble with your unit, DON'T email me asking
for guidance or help. The reason is that you made a mistake somewhere along the line and you'll have to
troubleshoot the problem YOURSELF. No exceptions. I have assembled this unit and I have tested all the main
features. They ALL work so there is no question that the design is flawless. If you start trying to substitute
components or make modifications to it, that's fine with me but YOU'RE RESPONSIBLE FOR THE OUTCOME.
My mission in life is NOT to take your hand and assume your "education" in electronics design.