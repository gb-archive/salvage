***********************
*  CbaBootLoader v1.1 *
***********************

 Thanks to Tim,Costis,DF,Flavor, and everyone in #gp32dev

 This program allows you to run unencrypted .gxb demos
on your gp32. If there is only one file to run then it
needs to be named gp:\demo.gxb. If you have multiple
.gxb files and you wish to use the menu to decide which
to load then put all of the .gxb files in the gp:\
directory. I'd prefer to use a gp:\pd (public domain)
subdirectory instead of the root directory to hold demo
.gxb files but there appears to be a bug in the libs
that prevents being able to list the contents of subdirs.

 There is a current limit of 24 demos that can be selected.

 The .gxb file is loaded into ram and then copied
to 0xc000000.

 First, get someone with an encryptor to encrypt this
loader.gxb file for you. They will give you a loader.gxe
and a loader.gxc file in return. Using a SMC card
reader/writer or the USB link software create a
loader directory in the Game directory. Put the loader.gxe
in the Game directory and the loader.gxc in the loader
directory:

 gp:\Game\loader.gxe
 gp:\Game\loader\loader.gxc
 gp:\demo.gxb

 Now turn on your gp32 with the SMC card installed
and you should see the icon. Press Start on the icon
to run that demo.


