#include "gpdef.h"
#include "gpstdlib.h"
#include "gpgraphic.h"
//#include "gpmain.h"
#include "gpstdio.h"
#include "gpfont.h"

GPDRAWSURFACE gpDraw;
char tmp_string[256];
char FileName[256];
#define TEXT_RED 0xE0
#define TEXT_BLACK 0

void GpError( char* text)
{
    GpTextOut(NULL, &gpDraw, 0, 16, text, TEXT_RED);
	while(1);
}

void GpMain(void *arg)
{
	int i;
	unsigned char * p_buf;
	unsigned long m_size;

//    ERR_CODE err_code;
	F_HANDLE h_file;

    int cy;
	int entry_start_idx;
    int FileCount;

	ERR_CODE err_code;
	GPDIRENTRY *p_list;
	unsigned long list_count = 0, read_count = 0;
	GPFILEATTR mAttr;

	i = GpLcdSurfaceGet(&gpDraw, 0);

	GpSurfaceSet(&gpDraw);

	GpRectFill(NULL, &gpDraw, 0, 0, 320, 240, 0xff);

//    GpTextOut(NULL, &gpDraw, 0, 16, "Run", 0xE0);

	err_code = GpFatInit();
	if (err_code != SM_OK) GpError( "GpFatInit");

    // gp:/ & / & / - Lists all file & dirs in root
    // gp:/pd & / & / - Just gives . - directoy
    // gp:/pd/ & / & / - Just gives . - directoy

    err_code = GpRelativePathSet("gp:\\");
	if (err_code != SM_OK) GpError( "GpRelativePathSet");


//    GpRelativePathSet("gp:\\temp"); //��� ��� ����

	/*GpDirEnumNum
		������ ���丮 ������ ��Ʈ�� ���� �Ѱ� �޴´�
	*/
    err_code = GpDirEnumNum("\\", &list_count);
    if (err_code != SM_OK) GpError( "GpDirEnumNum");

	/*GpDirEnumList
		������ ���丮�� ������ �ִ� ��Ʈ���� ����Ʈ�� �Ѱ� �޴´�.
		����Ʈ�� GPDIRENTRY����ü�� �迭 ���·μ� �޸𸮸� �Ҵ��Ͽ� �Ѱ���� �Ѵ�.

		entry_start_idx : zero base �ε����μ� ���� ���丮�� ������ �ִ� ��Ʈ���� ��ȣ�̴�.
		list_count : entry_start_idx���� �о���� ��Ʈ���� ���̴�.
		read_count : ���� �о���� ��Ʈ���� ���̴�.

		!!! : GPDIRENTRY�� name ����� full path�� �ƴϴ�.

	  GpFileAttr

	*/

	entry_start_idx = 0;
    tmp_string[0] = 0;
    FileCount = 0;
	p_list = (GPDIRENTRY*)gp_mem_func.calloc(list_count, sizeof(GPDIRENTRY));
    GpDirEnumList("\\", entry_start_idx, list_count, p_list, &read_count);
	for (i=0; i<read_count; i++)
       {
       err_code = GpFileAttr(p_list[i].name, &mAttr);  /* ������ ��� ��θ� ���������Ƿ� �̸��� �ѱ�� */
       gp_str_func.strcpy(tmp_string, p_list[i].name);
       if (err_code != SM_OK) GpError( "GpFileAttr");
       if (err_code == SM_OK && ((mAttr.attr & 0x10) == 0))    /* file */
          {
//          gp_str_func.strcat(tmp_string, " - file");
//          GpTextOut(NULL, &gpDraw, 0, cy, ( char*)tmp_string, 0x0);
//          cy += 10;
          FileCount++;
          }
//       else    /* directory <-- (mAttr.attr & 0x10 == 1) */
//          {
//          gp_str_func.strcat(tmp_string, " - directory");
//          }
//       GpTextOut(NULL, &gpDraw, 0, cy, ( char*)tmp_string, 0x0);
//       cy += 20;
       }

    if (FileCount > 1)
       {
       int Loop = 1;
       int CurY = 0;
       unsigned char keydata;
       int ExKey;
       int Pressed = 0;
       int Redraw = 1;
//       int x,y;

//       gp_str_func.strcpy(tmp_string, "X");
//       for (y=0; y<16; y++)
//          {
//          for (x=0; x<16; x++)
//             {
//             GpTextOut(NULL, &gpDraw, (x<<4), (y*14), (char*)tmp_string, (y<<4)+x);
//             }
//          }
//       while (1) {}

       while (Loop)
          {
          int FilePos = 0;
          // Multiple files so throw up a menu
          if (Redraw)
             {
             cy = 20;
             for (i=0; i<read_count; i++)
                {
                err_code = GpFileAttr(p_list[i].name, &mAttr);
                if (err_code != SM_OK) GpError( "GpFileAttr");
                if (err_code == SM_OK && ((mAttr.attr & 0x10) == 0))    /* file */
                   {
//                   gp_str_func.strcpy(tmp_string, "  ");
                   gp_str_func.strcpy(tmp_string, p_list[i].name);
                   if (CurY == FilePos)
                      {
                      gp_str_func.strcpy(FileName, p_list[i].name);
                      GpTextOut(NULL, &gpDraw, 10, cy, ( char*)tmp_string, TEXT_BLACK);
                      }
                   else
                      GpTextOut(NULL, &gpDraw, 10, cy, ( char*)tmp_string, TEXT_RED);

//          gp_str_func.strcat(tmp_string, " - file");
                   cy += 10;
                   FilePos++;
                   }
                }
             Redraw = 0;
             }
          GpKeyGetEx(&ExKey);
          keydata = ExKey & 0xff;

          if (Pressed == 0)
             {
             if ( ( keydata & GPC_VK_DOWN ) == GPC_VK_DOWN )
                {
                CurY++;
                if (CurY == FileCount) CurY = 0;
                Pressed = 1;
                Redraw = 1;
                }
             if ( ( keydata & GPC_VK_UP ) == GPC_VK_UP )
                {
                if (CurY == 0) CurY = FileCount-1; else CurY--;
                Pressed = 1;
                Redraw = 1;
                }
             if ( (ExKey & GPC_VK_START) ||
                  (ExKey & GPC_VK_SELECT) )
                {
                Loop = 0;
                }

             }
          else
             {
             if ( ( ( keydata & GPC_VK_DOWN ) == GPC_VK_DOWN ) ||
                  ( ( keydata & GPC_VK_UP ) == GPC_VK_UP ) )
                Pressed = 1;
             else
                Pressed = 0;
             }
          }
       }
    else
       {
       // Only one file so assume it's demo.gxb
       gp_str_func.strcpy(FileName, "demo.gxb");
       }

    gp_str_func.strcpy(tmp_string, "Can't open gp:\\");
    gp_str_func.strcat(tmp_string, FileName);

    err_code = GpFileGetSize(FileName, &m_size);
    if (err_code != SM_OK) GpError( tmp_string);

    err_code = GpFileOpen(FileName, OPEN_R, &h_file);
	if (err_code != SM_OK) GpError( "GpFileOpen");

	p_buf = (unsigned char*)gp_mem_func.malloc(m_size+4);

	GpTextOut(NULL, &gpDraw, 0, 0, "LOADING ...", 0x0);

	*(unsigned long*)p_buf = m_size;

    err_code = GpFileRead(h_file, p_buf+4, m_size, &m_size);
    if (err_code != SM_OK) GpError( "GpFileRead");

	err_code = GpFileClose(h_file);
	if (err_code != SM_OK) GpError( "GpFileClose");

	GpAppExecute( (char*)p_buf, "gp:\\pd\\");

	gp_mem_func.free(p_buf);
}
