// Fast line drawing stuff

#include "gpdef.h"
#include "gpstdlib.h"
#include "gpgraphic.h"
#include "gpmain.h"

 extern void gfxFastLine8 (u16 x1, u8 y1, u16 x2, u8 y2, u8 color, u8 *addr);

GPDRAWSURFACE gpDraw;

// Draw 1120 lines in a clock-wise sweep of the screen
void DoSweep (unsigned char color)
   {
   int x,y;
   for (x=0; x<320; x++)
      gfxFastLine8 (x, 0, 160, 120, color, &gpDraw.ptbuffer[0]);
   for (y=0; y<240; y++)
      gfxFastLine8 (319, y, 160, 120, color, &gpDraw.ptbuffer[0]);
   for (x=320; x>=0; x--)
      gfxFastLine8 (x, 239, 160, 120, color, &gpDraw.ptbuffer[0]);
   for (y=240; y>=0; y--)
      gfxFastLine8 (0, y, 160, 120, color, &gpDraw.ptbuffer[0]);
   }

void DoSweep2 (unsigned char color)
   {
   int x,y;
   for (x=0; x<320; x++)
      GpLineDraw (&gpDraw, x, 0, 160, 120, color);
   for (y=0; y<240; y++)
      GpLineDraw (&gpDraw, 319, y, 160, 120, color);
   for (x=320; x>=0; x--)
      GpLineDraw (&gpDraw, x, 239, 160, 120, color);
   for (y=240; y>=0; y--)
      GpLineDraw (&gpDraw, 0, y, 160, 120, color);
   }

void GpMain(void *arg)
{
	int rand_sx, rand_sy, rand_ex, rand_ey;
	unsigned char keydata;
	unsigned char color;
    int i,j;

	GpLcdSurfaceGet(&gpDraw, 0);

    GpSurfaceSet(&gpDraw);  //gpDraw primary surface� setting

    GpSrand (549);    //seed random value

    for (i=0; i<7500; i++) //50000*10; i++)
       {
       rand_sx = GpRand() % 320;
       rand_sy = GpRand() % 240;
       rand_ex = GpRand() % 320;
       rand_ey = GpRand() % 240;
       color = 0xff & GpRand();
       GpLineDraw (&gpDraw, rand_sx, rand_sy, rand_ex, rand_ey, color); //primary surface�� line�� �׸�
       }

    for (i=0; i<75000; i++) //50000*10; i++)
       {
       rand_sx = GpRand() % 320;
       rand_sy = GpRand() % 240;
       rand_ex = GpRand() % 320;
       rand_ey = GpRand() % 240;
       color = 0xff & GpRand();
       gfxFastLine8 (rand_sx, rand_sy, rand_ex, rand_ey, color, &gpDraw.ptbuffer[0]);
       }

    // Draw ~ 5000 lines/sec to screen
    for (i=0; i<10; i++)
       {
       DoSweep2 (0);                     // 1120 lines
       DoSweep2 (55);
       DoSweep2 (0);
       DoSweep2 (55);
       }

    // Draw ~49280 lines/sec to screen
    for (i=0; i<110; i++)
       {
       DoSweep (0);                     // 1120 lines
       DoSweep (55);
       DoSweep (0);
       DoSweep (55);
       }

    while (1) {}

}
