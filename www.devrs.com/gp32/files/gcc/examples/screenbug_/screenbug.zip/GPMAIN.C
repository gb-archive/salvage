// Screen bug demo?

#include "gpdef.h"
#include "gpstdlib.h"
#include "gpgraphic.h"
#include "gpmain.h"

GPDRAWSURFACE gpDraw;

void GpMain(void *arg)
   {
   int rand_sx, rand_sy;
   unsigned char color;
   int i,j;

   GpLcdSurfaceGet(&gpDraw, 0);


   GpSurfaceSet(&gpDraw);  //gpDraw primary surface� setting

   GpSrand (549);    //seed random value

   for (j=1; j<10; j++) //50000*10; i++)
      for (i=0; i<75000*5; i++) //50000*10; i++)
         {
         int k;
         rand_sx = GpRand() % 320;
         rand_sy = GpRand() % 240;
         rand_ex = GpRand() % 320;
         rand_ey = GpRand() % 240;
         color = 0xff & GpRand();
         for (k=0; k<j; k++)
            gpDraw.ptbuffer[((rand_sx+k)*240)+rand_sy] = color;
         }
   }

