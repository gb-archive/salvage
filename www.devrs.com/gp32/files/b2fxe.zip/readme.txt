b2fxe v1.1 for dos/linux
------------------------
v1.0 - Original release
v1.1 - Fixed 1 pixel bug with -b option.
       Now halts if you put options after filenames.

 Converts gp32 .gxb/.bin/.axf files to .fxe format

 Note: Make sure you strip debug info out of input files
before conversion to save space.

 There is a built-in icon if you don't specify one. If you make
your own then you must use the palette from the included bmp
example file since this is the palette that is used by the gp32.
It appears that color #239 (0xef) is used for transparent.

 If you wish to use a title that includes a space then you
must surround the whole title with "".

Examples:

 b2fxe demo.gxb demo.fxe
  - Sets title name to the input file by default.

 b2fxe -t DemoV1.0 -a "John Doe" -r Copyright2001 demo.gxb demo.fxe
  - Sets title name, author name, and some reserved info.

