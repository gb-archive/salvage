=========
= ABOUT =
=========
This is simply a program to be used in conjunction with Jeff Frohwein's FLinker program, which can be found at http://www.devrs.com/gba/ (current version: 1.72)
It was written because my laptop hates both FAW and LW, but loves the userport method of communicating with the LPT port.
If you want to contact me, please don't ask any questions about how to get FLinker 1.XX to work;  this program simplifies all the commands exponentially, but it also assumes you understand UserPort and whatever else is needed to get FLinker 1.XX to work.
You can ask about FlinkerFront, though.

================
= VERSION INFO =
================
.9b9
+got rid of need for comdlg32.ocx, now runs just fine on its own
+various clean ups relating to visual functions

.9b6
+heavily simplified compilation part of code to make it work on any Windows box
-need to have comdlg32.ocx registered (example: "c:\windows\system\regsvr32 comdlg32.ocx")
-larger zip due to inclusion of comdlg32.ocx
-cleaned up listbox a bit to make it work on other systems (well, the test dummy box I have)

.9b5
-attempted quick fix because I forgot not all systems are similar

.9b4
+first released version
+contains ability to add games to a list
+contains ability to sort that list
+contains ability to then take said list and compile it to a multirom
+contains ability to flash the previously mentioned multirom to a cartridge
+can configure basically all FLinker commandline options
+contains submenu for all game backup/save backup/save restoring functions
+makes me happy
-is ugly looking
-assumes FLinker will do all work correctly, we'll leave it at that
-only used for multiroms (I have a 256 meg card, so I only do multiroms)

==============
= HOW TO USE =
==============
It's pretty much self-explanatory, but here's a quick rundown:

1) Select the location of FLinker (it searches the current directory at startup)
2) Select the output directory (will make a file named multi.gba in that directory)
3) Select your bootloader file (it searches for gbaldr32.bin in the current directory at startup)
4) Navigate to the directory containing your games (it searches only for *.gba)
5) Select the files (use ctrl+click to multiselect)
6) Click the add button to add them to list (sugoi!)
note: you can't add the same game twice (unless it is the same game in two diff. directories)
7) Sort your list if you want to
8) Hit "Compile multirom" and watch DOS do its thing
9) Set any "Other Variables" (defaults are already selected)
10) Hit "Flash"

The Save/Load screen is even more self-explanatory, so I'll leave it up to you to play around

The "multi found" message comes up if you navigate to a directory with a multi.gba file existing in it already.  It's done simply because sometimes you either a) forget you've already compiled a multirom or b) don't want to make multiple/append an existing one/just plain screw up.  It's a setting tailored to my own preferences, and since this is my program, you just enjoy please.

================
= CONTACT INFO =
================
I simply go by "newbie" on the GBAEmu forum, located at http://forums.gbaemu.com/
Just send a message to that name

==================
= NOTES & THANKS =
==================
I have not beta tested this in any way outside of giving a basic version to one person once. 
FlinkerFront is probably not idiot-proof, so don't report "bugs" that you find if it is through something stupid a normal user wouldn't do (i.e. - putting letters in the waitstep box instead of numbers).  
I cannot be held responsible for stupidity.

Thanks go out to Jeff Frohwein for making the *one* program my computer likes.