/****************************/
/*Milhouse Basic Divx Player*/
/*for AGB		    */
/*march - april 2001	    */
/****************************/

typedef  const unsigned char  const_u8;
//#include "video.h"
#include "avi_read.h"
#include "divx/decore.h"
#include "mem.h"

//handler for Decore random value
#define HANDLER_ID 0x456

//various data for Decore
DEC_PARAM dec_param;
DEC_SET dec_set;
DEC_FRAME dec_frame;

//GBA Register
#define DISPCNT		*(u32*)0x04000000
#define PALETTE	((unsigned short *)0x5000000)
#define FRAME0	((unsigned char *)0x6000000)
#define FRAME1	((unsigned char *)0x600A000)
#define BG0CNT		*(u16*)0x04000008
#define BG1CNT     	*(u16*)0x0400000A
#define BG2CNT      *(u16*)0x0400000C
#define BG3CNT      *(u16*)0x0400000E


extern const_u8 video [380928];     //la video de Zelda en raw
int    taillevideo;     //la taille de la video

int AgbMain(void)
{
    avi_t * headerAvi;
    u8 vidbuf[160*128*2];
	u32 rv;

	Mem_Init();  //initiate custom mem allocation routine

    taillevideo = sizeof(video);

    BG2CNT = 0x0000;
	DISPCNT = 0x0405;//mode 5

	headerAvi=AVI_open_input(video,1);

	dec_param.x_dim = 160;
	dec_param.y_dim = 128;
    dec_param.color_depth = 16;
    dec_param.output_format = 1;

	decore(HANDLER_ID, DEC_OPT_INIT, &dec_param,0);

        rv = AVI_read_frame(headerAvi, vidbuf);
        dec_frame.bitstream = vidbuf;
        dec_frame.render_flag = 1;

    while (rv > 0) {

            dec_frame.length = rv;
	    switch (DISPCNT)
	     {
	     	case 0x0405:
	     		DISPCNT=0x0415;
	     		dec_frame.bmp=FRAME0;
			break;
	     	case 0x0415:
	     		DISPCNT=0x0405;
	     		dec_frame.bmp=FRAME1;
			break;
	     }

	    decore(HANDLER_ID, 0, &dec_frame, 0);
	    rv = AVI_read_frame(headerAvi, vidbuf);
      }
    while(1){}
}
