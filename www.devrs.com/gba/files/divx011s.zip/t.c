typedef  const unsigned char  const_u8; 
