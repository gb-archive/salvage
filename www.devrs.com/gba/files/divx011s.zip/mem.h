/* THE HEADER MEM.H */ 
#ifndef _MEM_H_
#define _MEM_H_ 
#ifdef __cplusplus
extern "C" {
#endif 

#include "typegba.h"
 /*--------------------------- Purge Tags-----------------------------------*/ 
 
#define PU_NULL 0// This block is free.
#define PU_STATIC 1// Static during entire execution time.
#define PU_LEVEL 2// Static until level exited. // Tags >= 100 are purgable whenever needed. 

#define PU_PURGELEVEL 100
#define PU_CACHE 101

#define STARTADRESS 0x0200bec0   //half WRam is for Dynamic allocation
#define TOTALSIZE 0x3413f

 /*--------------------------- Memory functions-----------------------------*/ 
 
// Initialises the memory management system.
void  Mem_Init(void); // This function allocates memory for you.
void* Mem_Alloc(u32 size, u32 tag); // This two functions deallocate memory previously allocated by Mem_Alloc.

// The first is a general deallocator, the second deallocates blocks from a
// certain tag range.
void Mem_Free(void *ptr);
void Mem_FreeTags(u32 lowerTag, u32 upperTag); // Return the amount of memory free.

u32 Mem_Avail (void); 

/*--------------------------- The end!-------------------------------------*/
#endif