                             /* THE CODE - MEM.C */


//                             #include<agb.h>
                             #include"mem.h"

                             #define MIN_FRAGMENT 64

                             /*--------------------------- Memblock structure
                             ---------------------------*/

                             // Every memory allocation has the following data p
                             typedef struct MemBlock_s {
                                     u32 size;// Size of block including header and possibly tiny fragments.  Maximum size if 64K.
                                     u32 tag;//Determines behaviour of memory block.
                                     struct MemBlock_s *next;// Offset to next me block.
                                     struct MemBlock_s *prev;// Offset to previoublock.
                             } MemBlock_t;

                             /*--------------------------- Memzone structure
                             ----------------------------*/

                             // A memory zone is an area where memory can be all is
                             // only one and that is in EX_WRAM.  This structurememory
                             // zone.
                             typedef struct MemZone_s {
                                     u32 size;// Total bytes allocated,including headers.
                                     MemBlock_t blockList;// Start sentinel for l
                                     MemBlock_t *rover;// End of linked list.
                             } MemZone_t;

                             MemZone_t*g_mainZone;

                             /*--------------------------- Functions
                             ------------------------------------*/
                             
                             static void Mem_ClearZone (MemZone_t *memZone)
                             {
				MemBlock_t *block; // Set the entire zone to one free block.
				memZone->blockList.next = memZone->blockList.prev =
				block = (MemBlock_t*)(memZone + 1);
				memZone->blockList.tag = PU_STATIC;
				memZone->rover = block;
				block->tag = PU_NULL;
				block->next = block->prev = &memZone->blockList;
				block->size = memZone->size - sizeof(MemZone_t);
                             }

                             void Mem_Init (void)
                             {
                                     g_mainZone = (MemZone_t*)STARTADRESS;
                                     g_mainZone->size = TOTALSIZE;
                                     Mem_ClearZone(g_mainZone);
                             }

                             void Mem_Free (void *ptr)
                             {
                                MemBlock_t *block, *other; // Get pointer to block header.
				block = ((MemBlock_t*)ptr)-1; // Mark as free.
				block->tag = PU_NULL; other = block->prev; 
				  if (other->tag == PU_NULL)
					{
				   	 // Merge with previous free block.
					 other->size += block->size;
					 other->next = block->next;
				 	 other->next->prev = other; if (block == g_mainZone->rover)
					 g_mainZone->rover = other; block = other;
					} 
				  other = block->next;
				  if (other->tag == PU_NULL)
					{
					 // Merge with following free block.
					 block->size += other->size;
					 block->next = other->next;
					 block->next->prev = block; 
					 if (other == g_mainZone->rover)
					   g_mainZone->rover = block;
					}
                             }


                             void *Mem_Alloc (u32 size, u32 tag)
                             {
			      u32 extra;
			      MemBlock_t *start, *rover, *newBlock, *base; // Ensure size if exactly divisible by 4.
			      size = (size + 3) & ~3; // Scan through the block list, looking for the first free block of
				// sufficient size, throwing out any purgable blocks along the way.
				// Account for size of header.
			      size += sizeof(MemBlock_t); // If there is a free block at the end of the mem block list, back
				// up over them.
			      base = g_mainZone->rover; if (base->prev->tag == PU_NULL)
				{
				 base = base->prev;
				} 
			      rover = base;
			      start = base->prev; do {
				if (rover == start)
				  {
				   // We scanned all the way around the list.
  				   //ASSERTMSG(0,"Out of memory!");
				  } 
				if (rover->tag != PU_NULL)
				  {
				   if (rover->tag < PU_PURGELEVEL)
				     {
				      // Hit a block that cannot be purged so move
				      // base past it.
				      base = rover->next;
				     }
				   else
				     {
				      // Free the rover block (adding the size to base).
				      base = base->prev;
	  	  		      Mem_Free((u8*)(rover + 1));
				      base = base->next;
				      rover = base->next; 
				     }
				  }
				else
				  {
				   rover = rover->next;
				  }
			      } while (base->tag != PU_NULL || base->size < size); // Found a block big enough.
			      extra = base->size - size; 
			      if (extra > MIN_FRAGMENT)
				{
				 // There will be a fragment  after the allocated block.
				 newBlock = (MemBlock_t*)((u8*)base + size);
				 newBlock->size = extra; newBlock->tag = PU_NULL;
				 newBlock->prev = base;
				 newBlock->next = base->next;
				 newBlock->next->prev = newBlock; base->next = newBlock;
				 base->size = size;
 				} 
 			     base->tag = tag; g_mainZone->rover = base->next; 
 			     return (void*)(base + 1);
                            }

                             void Mem_FreeTags (u32 lowerTag, u32 upperTag)
                             {
				MemBlock_t *block, *next; 
				for (block = g_mainZone->blockList.next;block != &g_mainZone->blockList;block = next)
				  {
					// Get link before freeing.
				   next = block->next; // Free block?
				   if (block->tag == PU_NULL) continue; if (block->tag >= lowerTag && block->tag <= upperTag)
				 	{
					 Mem_Free((u8*)(block+1));
					}
				  }                             	
                             }


                             u32 Mem_Avail (void)
                             {
			      MemBlock_t *block;
			      u32 free; free = 0; 
			      for (block = g_mainZone->blockList.next; block != &g_mainZone->blockList; block = block->next)
				{	
				 if (block->tag == PU_NULL || block->tag >= PU_PURGELEVEL)
				   {
				    free += (block->size - sizeof(MemBlock_t));
				   }
				} return free;
                             }
