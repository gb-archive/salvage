/**************************************************************************
 *                                                                        *
 * This code has been developed by Andrea Graziani. This software is an   *
 * implementation of a part of one or more MPEG-4 Video tools as          *
 * specified in ISO/IEC 14496-2 standard.  Those intending to use this    *
 * software module in hardware or software products are advised that its  *
 * use may infringe existing patents or copyrights, and any such use      *
 * would be at such party's own risk.  The original developer of this     *
 * software module and his/her company, and subsequent editors and their  *
 * companies (including Project Mayo), will have no liability for use of  *
 * this software or modifications or derivatives thereof.                 *
 *                                                                        *
 * Project Mayo gives users of the Codec a license to this software       *
 * module or modifications thereof for use in hardware or software        *
 * products claiming conformance to the MPEG-4 Video Standard as          *
 * described in the Open DivX license.                                    *
 *                                                                        *
 * The complete Open DivX license can be found at                         *
 * http://www.projectmayo.com/opendivx/license.php                        *
 *                                                                        *
 **************************************************************************/
/**
*  Copyright (C) 2001 - Project Mayo
 *
 * Andrea Graziani (Ag)
 *
 * DivX Advanced Research Center <darc@projectmayo.com>
**/

#include "mem.h"

#define IN_IWRAM __attribute__ ((section (".iwram")))
extern u32 __FarFunction (u32 (*ptr)(), ...);  // Reference to routine in crt0.S
extern void __FarProcedure (void (*ptr)(), ...);  // Reference to routine in crt0.S

#ifndef _BASIC_PREDICTION_H_
#define _BASIC_PREDICTION_H_

void copyMemBlock(u32 *FuncAddr,
	unsigned char * Src,
	unsigned char * Dst,
	int BlockHeight,
	int BlockWidth,
    int Stride) IN_IWRAM;

void copyMemBlockHor(u32 *FuncAddr,
	unsigned char * Src,
	unsigned char * Dst,
	int BlockHeight,
	int BlockWidth,
	int Stride,
    int Round) IN_IWRAM;

void copyMemBlockVer(u32 *FuncAddr,
	unsigned char * Src,
	unsigned char * Dst,
	int BlockHeight,
	int BlockWidth,
	int Stride,
    int Round) IN_IWRAM;

void copyMemBlockHorVer(u32 *FuncAddr,
	unsigned char * Src,
	unsigned char * Dst,
	int BlockHeight,
	int BlockWidth,
	int Stride,
    int Round) IN_IWRAM;

void copyBlock(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride) IN_IWRAM;
void copyBlockHor(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride) IN_IWRAM;
void copyBlockVer(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride) IN_IWRAM;
void copyBlockHorVer(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride) IN_IWRAM;
void copyBlockHorRound(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride) IN_IWRAM;
void copyBlockVerRound(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride) IN_IWRAM;
void copyBlockHorVerRound(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride) IN_IWRAM;
/**/
void copyMBlock(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride) IN_IWRAM;
void copyMBlockHor(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride) IN_IWRAM;
void copyMBlockVer(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride) IN_IWRAM;
void copyMBlockHorVer(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride) IN_IWRAM;
void copyMBlockHorRound(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride) IN_IWRAM;
void copyMBlockVerRound(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride) IN_IWRAM;
void copyMBlockHorVerRound(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride) IN_IWRAM;

#endif // _BASIC_PREDICTION_H_
