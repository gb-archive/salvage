// idct.h //

#ifndef _IDCT_H_
#define _IDCT_H_

#ifdef _INTEL_IDCT_
#define Fast_IDCT idct
#endif // _INTEL_IDCT_

#endif // _IDCT_H_
