/**************************************************************************
 *                                                                        *
 * This code has been developed by Andrea Graziani. This software is an   *
 * implementation of a part of one or more MPEG-4 Video tools as          *
 * specified in ISO/IEC 14496-2 standard.  Those intending to use this    *
 * software module in hardware or software products are advised that its  *
 * use may infringe existing patents or copyrights, and any such use      *
 * would be at such party's own risk.  The original developer of this     *
 * software module and his/her company, and subsequent editors and their  *
 * companies (including Project Mayo), will have no liability for use of  *
 * this software or modifications or derivatives thereof.                 *
 *                                                                        *
 * Project Mayo gives users of the Codec a license to this software       *
 * module or modifications thereof for use in hardware or software        *
 * products claiming conformance to the MPEG-4 Video Standard as          *
 * described in the Open DivX license.                                    *
 *                                                                        *
 * The complete Open DivX license can be found at                         *
 * http://www.projectmayo.com/opendivx/license.php                        *
 *                                                                        *
 **************************************************************************/
/**
*  Copyright (C) 2001 - Project Mayo
 *
 * Andrea Graziani (Ag)
 *
 * DivX Advanced Research Center <darc@projectmayo.com>
*
**/

#include "basic_prediction.h"

// Purpose: Copy a memory block from Src to Dst
void copyMemBlock(u32 *FuncAddr,
	unsigned char * Src,
	unsigned char * Dst,
	int BlockHeight,
	int BlockWidth,
	int Stride)
{
	int dy, dx;

	for (dy = 0; dy < BlockHeight; dy++) {
		for (dx = 0; dx < BlockWidth; dx++) {
			Dst[dx] = Src[dx];
		}
		Src += Stride;
		Dst += Stride;
	}
}

// Purpose: Copy a memory block with horizontal pixel interpolation of the Src
void copyMemBlockHor(u32 *FuncAddr,
	unsigned char * Src,
	unsigned char * Dst,
	int BlockHeight,
	int BlockWidth,
	int Stride,
	int Round)
{
	int dy, dx;

	for (dy = 0; dy < BlockHeight; dy++) {
		for (dx = 0; dx < BlockWidth; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1] +1 -Round) >> 1; // hor interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}

// Purpose: Copy a memory block with vertical pixel interpolation of the Src
void copyMemBlockVer(u32 *FuncAddr,
	unsigned char * Src,
	unsigned char * Dst,
	int BlockHeight,
	int BlockWidth,
	int Stride,
	int Round)
{
	int dy, dx;

	for (dy = 0; dy < BlockHeight; dy++) {
		for (dx = 0; dx < BlockWidth; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+Stride] +1 -Round) >> 1; // ver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}

// Purpose: Copy a memory block with horizontal and vertical pixel interpolation of the Src
void copyMemBlockHorVer(u32 *FuncAddr,
	unsigned char * Src,
	unsigned char * Dst,
	int BlockHeight,
	int BlockWidth,
	int Stride,
	int Round)
{
	int dy, dx;

	for (dy = 0; dy < BlockHeight; dy++) {
		for (dx = 0; dx < BlockWidth; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1] +
								Src[dx+Stride] + Src[dx+Stride+1] +2 -Round) >> 2; // horver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}

/*

	half_flag[t]

	t = 0		horizontal component
	t = 1		vertical component

*/

// Purpose: specialized basic motion compensation routines
#ifndef GBA
void copyBlock(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy;

	long *lpSrc = (long *) Src;
	long *lpDst = (long *) Dst;
	int lpStride = Stride >> 2;

	for (dy = 0; dy < 8; dy++) {
		lpDst[0] = lpSrc[0];
		lpDst[1] = lpSrc[1];
		lpSrc += lpStride;
		lpDst += lpStride;
	}
}
#else   //#define GBA
void copyBlock(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)

{
int dy;
for (dy = 0; dy < 8; dy++) {
Dst[0] = Src[0];
Dst[1] = Src[1];
Dst[2] = Src[2];
Dst[3] = Src[3];
Dst[4] = Src[4];
Dst[5] = Src[5];
Dst[6] = Src[6];
Dst[7] = Src[7];
Dst += Stride;
Src += Stride;
}
}
#endif //GBA
/**/
void copyBlockHor(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 0; dy < 8; dy++) {
		for (dx = 0; dx < 8; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1]+1) >> 1; // hor interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void copyBlockVer(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 0; dy < 8; dy++) {
		for (dx = 0; dx < 8; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+Stride] +1) >> 1; // ver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void copyBlockHorVer(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 0; dy < 8; dy++) {
		for (dx = 0; dx < 8; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1] +
								Src[dx+Stride] + Src[dx+Stride+1] +2) >> 2; // horver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void copyBlockHorRound(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 0; dy < 8; dy++) {
		for (dx = 0; dx < 8; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1]) >> 1; // hor interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void copyBlockVerRound(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 0; dy < 8; dy++) {
		for (dx = 0; dx < 8; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+Stride]) >> 1; // ver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void copyBlockHorVerRound(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 0; dy < 8; dy++) {
		for (dx = 0; dx < 8; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1] +
								Src[dx+Stride] + Src[dx+Stride+1] +1) >> 2; // horver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/** *** **/
#ifndef GBA
void copyMBlock(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy;

	long *lpSrc = (long *) Src;
	long *lpDst = (long *) Dst;
	int lpStride = Stride >> 2;

	for (dy = 0; dy < 16; dy++) {
		lpDst[0] = lpSrc[0];
		lpDst[1] = lpSrc[1];
		lpDst[2] = lpSrc[2];
		lpDst[3] = lpSrc[3];
		lpSrc += lpStride;
		lpDst += lpStride;
	}
}
#else //#define GBA
void copyMBlock(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
int dy;
for (dy = 0; dy < 16; dy++) {
Dst[0] = Src[0];
Dst[1] = Src[1];
Dst[2] = Src[2];
Dst[3] = Src[3];
Dst[4] = Src[4];
Dst[5] = Src[5];
Dst[6] = Src[6];
Dst[7] = Src[7];
Dst[8] = Src[8];
Dst[9] = Src[9];
Dst[10] = Src[10];
Dst[11] = Src[11];
Dst[12] = Src[12];
Dst[13] = Src[13];
Dst[14] = Src[14];
Dst[15] = Src[15];
Dst += Stride;
Src += Stride;
}
}

#endif  //GBA
/**/
void copyMBlockHor(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 0; dy < 16; dy++) {
		for (dx = 0; dx < 16; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1]+1) >> 1; // hor interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void copyMBlockVer(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 0; dy < 16; dy++) {
		for (dx = 0; dx < 16; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+Stride] +1) >> 1; // ver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void copyMBlockHorVer(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 0; dy < 16; dy++) {
		for (dx = 0; dx < 16; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1] +
								Src[dx+Stride] + Src[dx+Stride+1] +2) >> 2; // horver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void copyMBlockHorRound(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 0; dy < 16; dy++) {
		for (dx = 0; dx < 16; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1]) >> 1; // hor interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void copyMBlockVerRound(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 0; dy < 16; dy++) {
		for (dx = 0; dx < 16; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+Stride]) >> 1; // ver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
/**/
void copyMBlockHorVerRound(u32 *FuncAddr, unsigned char * Src, unsigned char * Dst, int Stride)
{
	int dy, dx;

	for (dy = 0; dy < 16; dy++) {
		for (dx = 0; dx < 16; dx++) {
			Dst[dx] = (Src[dx] + Src[dx+1] +
								Src[dx+Stride] + Src[dx+Stride+1] +1) >> 2; // horver interpolation with rounding
		}
		Src += Stride;
		Dst += Stride;
	}
}
