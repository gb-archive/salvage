/**************************************************************************
 *                                                                        *
 * This code has been developed by John Funnell. This software is an      *
 * implementation of a part of one or more MPEG-4 Video tools as          *
 * specified in ISO/IEC 14496-2 standard.  Those intending to use this    *
 * software module in hardware or software products are advised that its  *
 * use may infringe existing patents or copyrights, and any such use      *
 * would be at such party's own risk.  The original developer of this     *
 * software module and his/her company, and subsequent editors and their  *
 * companies (including Project Mayo), will have no liability for use of  *
 * this software or modifications or derivatives thereof.                 *
 *                                                                        *
 * Project Mayo gives users of the Codec a license to this software       *
 * module or modifications thereof for use in hardware or software        *
 * products claiming conformance to the MPEG-4 Video Standard as          *
 * described in the Open DivX license.                                    *
 *                                                                        *
 * The complete Open DivX license can be found at                         *
 * http://www.projectmayo.com/opendivx/license.php                        *
 *                                                                        *
 **************************************************************************/
/**
*  Copyright (C) 2001 - Project Mayo
 *
 * John Funnell
 * Andrea Graziani
 *
 * DivX Advanced Research Center <darc@projectmayo.com>
*
**/
// yuv2rgb.c //

//#include <memory.h>
#include <string.h>

#ifdef WIN32
#include "portab.h"
#else
#ifdef GBA
#include "portab.h"
#else
#include <inttypes.h>
#endif // GBA
#endif // WIN32

#include "mp4_decoder.h"

#include "global.h"

#include "yuv2rgb.h"

/***

  /  2568      0   3343  \
 |   2568  -0c92  -1a1e   | / 65536 * 8
  \  2568   40cf      0  /

    Y -= 16;
    U -= 128;
    V -= 128;

    R = (0x2568*Y + 0x0000*V + 0x3343*U) / 0x2000;
    G = (0x2568*Y - 0x0c92*V - 0x1a1e*U) / 0x2000;
    B = (0x2568*Y + 0x40cf*V + 0x0000*U) / 0x2000;

    R = R>255 ? 255 : R;
    R = R<0   ?   0 : R;

    G = G>255 ? 255 : G;
    G = G<0   ?   0 : G;

    B = B>255 ? 255 : B;
    B = B<0   ?   0 : B;

***/
#define _S(a)		(a)>255 ? 255 : (a)<0 ? 0 : (a)

#ifndef GBA
#define _R(y,u,v) (0x2568*(y) + 0x3343*(u)) /0x2000
#define _G(y,u,v) (0x2568*(y) - 0x0c92*(v) - 0x1a1e*(u)) /0x2000
#define _B(y,u,v) (0x2568*(y) + 0x40cf*(v)) /0x2000
#else  //#define GBA
#define _R(y,u,v) (0x25*(y) + 0x33*(u)) >>5
#define _G(y,u,v) (0x25*(y) - 0x0d*(v) - 0x1a*(u)) >>5
#define _B(y,u,v) (0x25*(y) + 0x41*(v)) >>5
#endif //GBA

/* all stride values are in _bytes_ */

void yuv2rgb_32(uint8_t *puc_y, int stride_y,
                uint8_t *puc_u, uint8_t *puc_v, int stride_uv,
                uint8_t *puc_out, int width_y, int height_y)
{

	int x, y;

	puc_out = puc_out + width_y * (height_y-1) * 4;

	for (y=0; y<height_y; y++)
	{
		for (x=0; x<width_y; x++)
		{
			signed int _r,_g,_b;
			signed int r, g, b;
			signed int y, u, v;

			y = puc_y[x] - 16;
			u = puc_u[x>>1] - 128;
			v = puc_v[x>>1] - 128;

			_r = _R(y,u,v);
			_g = _G(y,u,v);
			_b = _B(y,u,v);

			r = _S(_r);
			g = _S(_g);
			b = _S(_b);

			puc_out[0] = r;
			puc_out[1] = g;
			puc_out[2] = b;
			puc_out[3] = 0;

			puc_out+=4;
		}

		puc_y   += stride_y;
		if (y%2) {
			puc_u   += stride_uv;
			puc_v   += stride_uv;
		}
		puc_out -= (width_y*8);
	}
}

/***/

void yuv2rgb_24(uint8_t *puc_y, int stride_y,
                uint8_t *puc_u, uint8_t *puc_v, int stride_uv,
                uint8_t *puc_out, int width_y, int height_y)
{

	int x, y;

	puc_out = puc_out + width_y * (height_y-1) * 3;

	for (y=0; y<height_y; y++)
	{
		for (x=0; x<width_y; x++)
		{
			signed int _r,_g,_b;
			signed int r, g, b;
			signed int y, u, v;

			y = puc_y[x] - 16;
			u = puc_u[x>>1] - 128;
			v = puc_v[x>>1] - 128;

			_r = _R(y,u,v);
			_g = _G(y,u,v);
			_b = _B(y,u,v);

			r = _S(_r);
			g = _S(_g);
			b = _S(_b);

			puc_out[0] = r;
			puc_out[1] = g;
			puc_out[2] = b;

			puc_out+=3;
		}

		puc_y   += stride_y;
		if (y%2) {
			puc_u   += stride_uv;
			puc_v   += stride_uv;
		}
		puc_out -= (width_y*6);
	}
}

/***/

#define _mR	0x7c00
#define _mG 0x03e0
#define _mB 0x001f

#define _Ps(r,g,b) (((r) << 7) & _mR) | (((g) << 2) & _mG) | (((b) >> 3) & _mB)

void yuv2rgb_555(uint8_t *puc_y, int stride_y,
                uint8_t *puc_u, uint8_t *puc_v, int stride_uv,
                uint8_t *puc_out, int width_y, int height_y)
{

	int x, y;
	unsigned short *pus_out;

	puc_out = puc_out + width_y * (height_y-1) * 2;
	pus_out = (unsigned short *) puc_out;

	for (y=0; y<height_y; y++)
	{
		for (x=0; x<width_y; x++)
		{
			signed int _r,_g,_b;
			signed int r, g, b;
			signed int y, u, v;

			y = puc_y[x] - 16;
			u = puc_u[x>>1] - 128;
			v = puc_v[x>>1] - 128;

			_r = _R(y,u,v);
			_g = _G(y,u,v);
			_b = _B(y,u,v);

			r = _S(_r);
			g = _S(_g);
			b = _S(_b);

			pus_out[0] = _Ps(b,g,r);

			pus_out++;
		}

		puc_y   += stride_y;
		if (y%2) {
			puc_u   += stride_uv;
			puc_v   += stride_uv;
		}
		pus_out -= (width_y*2);
	}
}

/***/
#ifndef GBA
#define _Ps565(r,g,b) ( ((r & 0xF8) >> 3) | (((g & 0xF8) << 3)) | (((b & 0xF8) << 8)) )

void yuv2rgb_565(uint8_t *puc_y, int stride_y,
                uint8_t *puc_u, uint8_t *puc_v, int stride_uv,
                uint8_t *puc_out, int width_y, int height_y)
{

	int x, y;
	unsigned short *pus_out;

	if (height_y < 0) {
		height_y  = -height_y;
		puc_y     += (height_y   - 1) * stride_y ;
        puc_u     += ((height_y>>1) - 1) * stride_uv;
        puc_v     += ((height_y>>1) - 1) * stride_uv;
		stride_y  = -stride_y;
		stride_uv = -stride_uv;
	}
	pus_out = (unsigned short *) puc_out;

	for (y=0; y<height_y; y++)
	{
		for (x=0; x<width_y; x++)
		{
			signed int _r,_g,_b;
			signed int r, g, b;
			signed int y, u, v;

			y = puc_y[x] - 16;
			u = puc_u[x>>1] - 128;
			v = puc_v[x>>1] - 128;

			_r = _R(y,u,v);
			_g = _G(y,u,v);
			_b = _B(y,u,v);

			r = _S(_r);
			g = _S(_g);
			b = _S(_b);

			pus_out[0] = (unsigned short) _Ps565(r,g,b);

			pus_out++;
		}

		puc_y   += stride_y;
		if (y%2) {
			puc_u   += stride_uv;
			puc_v   += stride_uv;
		}
	}
}
#else
#define _Ps565(r,g,b) (((r) << 7) & _mR) | (((g) << 2) & _mG) | (((b) >> 3) & _mB)

void yuv2rgb_565(uint8_t *puc_y, int stride_y,
                uint8_t *puc_u, uint8_t *puc_v, int stride_uv,
                uint8_t *puc_out, int width_y, int height_y) IN_IWRAM;

void yuv2rgb_565(uint8_t *puc_y, int stride_y,
                uint8_t *puc_u, uint8_t *puc_v, int stride_uv,
                uint8_t *puc_out, int width_y, int height_y)
{

	int x, y;
    int w = width_y - 1;

	unsigned short *pus_out;

	if (height_y < 0) {
		height_y  = -height_y;
		puc_y     += (height_y   - 1) * stride_y ;
        puc_u     += ((height_y>>1) - 1) * stride_uv;
        puc_v     += ((height_y>>1) - 1) * stride_uv;
		stride_y  = -stride_y;
		stride_uv = -stride_uv;
	}
	pus_out = (unsigned short *) puc_out;
	pus_out += 0x5000;   //to avoid the upside down effect of OpenDivx
	for (y=0; y<height_y; y++)
	{
        for (x=0; x<width_y; x++)
		{
			signed int _r,_g,_b;
			signed int r, g, b;
			signed int y, u, v;
            int z = w - x;

            y = puc_y[z] - 16;
            u = puc_u[z>>1] - 128;
            v = puc_v[z>>1] - 128;

			_r = _R(y,u,v);
			_g = _G(y,u,v);
			_b = _B(y,u,v);

			r = _S(_r);
			g = _S(_g);
			b = _S(_b);

			pus_out[0] = (unsigned short) _Ps565(r,g,b);

			pus_out--;
		}

		puc_y   += stride_y;
		if (y<<31) {
			puc_u   += stride_uv;
			puc_v   += stride_uv;
		}
	}
}
#endif

/***/
void convert_linux(uint8_t *puc_y, int stride_y,
  uint8_t *puc_u, uint8_t *puc_v, int stride_uv,
  uint8_t *puc_out, int width_y, int height_y)
{
	int i;

	for (i=0; i<height_y; i++) {

		memcpy(((char **) puc_out)[0] + i*width_y,
			puc_y + i*stride_y,
			width_y);
	}

    for(i=0; i<(height_y>>1); i++) {

        memcpy(((char **) puc_out)[1] + i*(width_y>>1),
			puc_v + i*stride_uv,
            (width_y>>1));

        memcpy(((char **) puc_out)[2] + i*(width_y>>1),
			puc_u + i*stride_uv,
            (width_y>>1));
	}
}

