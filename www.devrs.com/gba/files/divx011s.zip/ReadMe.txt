OpenDivx 4.48 port on GBA using GCC
by milhouse31  version :  0.1
---------------------------------------
Version 0.11 by Jeff Frohwein
 - Put critical routines in IWRAM.
 - Replaced standard divide with BIOS fast divide.
 - Replaced float "pow" with int Power [] lookup table.
 - made v2c.bat to convert video to C file.
 - b2x v1.6 or later needed for v2c.bat

 Episode 1 : can it work on a 17 mhz CPU with +256Kb ????
----------- ---------------------------------------------------------------
            in a galaxy far Away GBA has just been release,
            in another part of the galaxy a small group of coder
            try to emulate and Code the Machine will they succed ....
            (man i'm lame :-D)


First / Preambule
----------------------
If someone can test the binarie and tell me if it work  the general performance
Si qqun peut essayer la rom sur le hardware et me donner les performances(si ca marche)

milhouse31@multimania.com

Note: In the source i haven't include the file video.h (the raw video in a C array)
-----
      because it was quiet big ( 1.9 Mb )-
      to create it : - use the video (the zelda or one of your OpenDivx movie)with B2X
		     - name the array video[] and include "typegba.h"


*********************************************
English Version (excuse my english it suck ):
*********************************************


Why ?
------

I download the demo with the FF movies trailer.
300kb -> 3 secondes -> 256 colors
Not very good ( i'm not atttacking the demo author his demo was not intented
To be a model for playback movie )
So i think ( yes i do sometimes ! ! i swear ) and while surfing i land on OpenDivx site.
(more info on OpenDivX : http://www.project-mayo.com )
i tell me : " i have  never code for any console, gba seem cool to start "
	 " i have never code a codec, an opensource project seem cool "
	" if i port the codec on gba its all good for me "

And i like trying to do thing that seem impossible

Constraint :
--------------
Gba hasn't a fast cpu nor a lot of memory.
Plus, GBA Gfx mode only let you display 160*128 in 15bits with double buffering.
Video must be in 160*128 in 16bits (OpenDivx doesn't have a 15 bits mode )
If you want to use it in a commercial games 2 problemes :
-you have to pay DivXNetwork ( i fell screwed now :()
-and the codec use alot of memory +/- 200kb

Performance So far :

The rom only work with VGBA 0.5 i don't know if it work on real GBA
On VGBA i get something like 4/5 fps.
I think it's not bad since i haven't optimize ( almost ) and that OpenDivx is still in beta stage

Futur :
---------
Currently the development is freeze because i don't have time since i have to finish my study and write a thesis( ?). So i think i will comeback on the project in the end of june

Greeting :

See the french part :

*****************
Version Fran�aise:

Pq ?
-----

j'ai telecharge la demo avec la video de FinalFantasy the movie.
R�sultat +300kb -> 3 secondes -> en 256 couleurs
Pas tr�s concluant le r�sultat (je n'attaque pas l'auteur le but de la demo �tant diff�rent),
alors je r�fl�chis (si ca m'arrive!!!je jures!!!) et je pense a OpenDivx.
OpenDivx (http://www.project-mayo.com)est le nouveau codec d�velopper par DivXNetwork.
le projet est OpenSource m�me si la licence n'est pas la licence standard GNU ( je suis parano les gars ).
Le Projet est d�velopp� par les m�mes personnes qui avait hacker le Codec de M$ pour cr��e DivX;-).
je me dits : - "J'ai jamais programme de console de ma vie le gba ca a l'air nickel"
	     - "J'ai jamais programme de codec de ma vie un projet OpenSource c'est nickel"
	     - "En portant le codec sur GBA je fait d'une pierre d'eux co�t"

Et puis j'aime bien essayer de nouveau truc qui paraisse impossible.


Contrainte :
-------------

Le gba n'as pas bcp de Horse Power et pas bcp de m�moire.
En plus les diff�rent mode graphique du GBA ne permettent
D'affichage en 160*128 en 15 bits en double buffering.
Donc les vid�o doivent �tre dans le format 160 * 128 en 16 bits (ODivX n'encode pas en 15 bits) obligatoirement.
je ne croix pas que le codec  peux �tre exploiter dans des jeux parce que :
- le cote juridique avec DivXNetwork ( c'est gratuit si le soft est gratuit )
- et surtout la m�moire dans l'�tat actuel je croix que la m�moire consommer est de +/- 200kb ( WRAM )

Performance :
--------------

La rom ne marche qu'avec VGBA0.5 je sais pas si elle marche avec le vrai GBA.
Sur VGBA0.5 j'obtient (je pense ?) 4/5 fps.
C'est pas mal surtout que j'ai rien optimiser ( ou si peu ) et que le projet OpenDivX n'est encore
qu'au stade b�ta.

Future :
---------
Pour le moment le d�veloppement est fig� parce que j'ai pas le temps ( je termine mes
�tude et je dois �crire un m�moire ) mais je reviendrais s�rement dessus vers fin juin-debut juillet.


Remerciement (greetings) :
-----------------

la liste est longue :

D'abord moi pour avoir de bonnes id�es ( je suis �gocentrique et narcissique, cool ) :-D

S�rieusement: - l'�quipe OpenDivX et les mecs de la message board ( pocket pc thread )
	      - Jeff F ( from Dev'r ) pour ses examples de compilation avec gcc
	      - Anarko pour avoir cr��e gbadev
	      - Matthew Davies pour ses fonctions d'allocations m�moire sur la mailing-list gbadev
	      - Marat ( de VGBA ) pour avoir fait un emulateur qui fait tourner ma rom
	      - tout les auteurs d'emu GBA
	      - Damien Chavarria de XMPS a qui j'ai hack� les fct pour cr�� le mini player avi
	      - les mecs de la soci�t� dans laquelle je fait mon stage actuellement ( salut Oli )
	      - les mecs du channel #gbadev tout le monde leur dits merci alors pq pas moi
	      - Nintendo pour avoir fait la console
	      - mes amis et ma famille qui ne m'ont pas soutenu parce qu'ils savent m�me pas ce que je faits
	      - les profs du jury pour mon m�moires svp soyez compr�hensif

milhouse31 :
e-mail  : milhouse31@multimania.com
URL    : http://milhouse31.multimania.com/




