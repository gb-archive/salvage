
#define __ANSI_NAMES 0
//
// v1.40 - Initial release.
// v1.41 - Put received keyboard & file data in separate buffers
//         to prevent mixing of data during simultaneous use.
//         Added dfprintf library function.
// v1.42 - Fixed bug in dfputc() where escape characters caused
//         character 0x01 to be sent to console. Thanks to
//         Tim Schuerewegen for finding this bug.
//
//  MB v1.41 or later pc software is required to use this library
// software.
//
// NOTE: THIS LIBRARY USES GLOBAL INITIALIZED DATA SO YOU MUST USE
// A CRT0.S AND A LINKER SCRIPT THAT SUPPORTS THIS AS WELL. GET
// CRTLS V1.1 OR LATER FROM HTTP://www.devrs.com/gba FOR PROPER SUPPORT.
//
// The following library functions are supported:
//
// Library name   Standard Name      Function
//   dprintf        printf       Print a string on PC console.
//   dputchar       putchar      Print a char on PC console.
//   dgetch         getch        Get a char from PC keyboard.
//   dkbhit         kbhit        Return 1 if PC keyboard char is ready.
//
//   dfopen         fopen        Open PC file.
//   dfclose        fclose       Close PC file.
//   dfprintf       fprintf      Print a string to PC file.
//   dfgetc         fgetc        Get char from PC file.
//   dfputc         fputc        Write a char to PC file.
//   drewind        rewind       Set file pointer to start of file.
//
// If you wish to use the standard naming conventions
// rather than the library names then change "__ANSI_NAMES 0"
// to "__ANSI_NAMES 1" instead.
//
// Notes:
//
//  Currently only ONE file may be open at a time.
//
//  If you are sending raw binary data to a PC file, use
//  dfputc instead of dfprintf. Dfprintf will insert
//  carriage return characters before linefeed characters
//  on the PC side if the PC console software is running on
//  dos/windows for proper text formatting.
//
//  If you are missing some .h files during compile than get
// 'arminc.zip' from http://www.devrs.com/gba in the
//  Apps / C Compilers section.
//
// Example command line:
//    mb -s file.mb -c -w 50 -x 255 -m
//
//  In this example, after transferring "file.mb" to the GBA,
// the PC goes into console/file server mode (-c) and also
// shows all of the file open/file close/fgetc/fputc commands
// (-m) on screen. The -w value should be a large enough value
// where the -s is reliable and the -x value should be a large
// enough value where the -c is reliable with the GBA.
//
//      [Sending a file & console mode each have
//       their own delay settings because they
//       each use a different method for transferring
//       data. Each method is about ideal for it's
//       application.]
//
// Example GBA Code:
//
//  #include "mbv2lib.c"
//
//  int main (void)
//    {
//
//    int i,j,k;
//    FILE fp;
//
//    dprintf ("Hello world!");
//
//    // Get character from PC keyboard
//    i = dgetch ();
//
//    // Copy SRAM or Flash backup to PC
//    fp = dfopen("sram.bin","wb");
//    for (i = 0; i != 0x8000; i++)
//       dfputc(*(unsigned char *)(i + 0xE000000), fp);
//    dfclose(fp);
//
//    // Copy PC to SRAM
//    fp = dfopen("sram.bin","rb");
//    for (i = 0; i != 0x8000; i++)
//       *(unsigned char *)(i + 0xE000000) = dfgetc (fp);
//    dfclose(fp);

//    // Read data from file
//    fp = dfopen ("foo.bin", "rb");
//    i = dfgetc (fp);
//    j = dfgetc (fp);
//    k = dfgetc (fp);
//    dfclose (fp);
//
//    }

// Data transfer format
// --------------------
//
// PC -> GBA Comms:
// Raw data is PC File read data.
// ESCCHR 0x00 = nada (used for input polling)
// ESCCHR 0x01 = Escape character from PC file read
// ESCCHR 0x08 0x?? = Keyboard read data
//
//
// GBA -> PC comms
// Raw data is console print data.
// ESCCHR = escape sequence
// ESCCHR 0x00 = nada (used for input polling)
// ESCCHR 0x01 = Escape character for console print
// ESCCHR 0x02 = file open (gba -> PC)
// ESCCHR 0x03 = file close (gba -> PC)
// ESCCHR 0x04 = fgetc (gba -> PC)
// ESCCHR 0x05 0x?? = fputc (gba -> PC)
// ESCCHR 0x06 = rewind (gba -> PC)
// ESCCHR 0x07 = fputc processed (gba -> pC) (Add CR before LF char if win/DOS machine)

#define FILE int

// Uncomment the following line to define the following types if needed
//#define INC_SHORT_NAME_TYPES 1

#ifdef INC_SHORT_NAME_TYPES
 typedef     volatile unsigned char           vu8;
 typedef     volatile unsigned short int      vu16;
 typedef     volatile unsigned int            vu32;
 typedef     volatile unsigned long long int  vu64;

 typedef     unsigned char           u8;
 typedef     unsigned short int      u16;
 typedef     unsigned int            u32;
 typedef     unsigned long long int  u64;

 typedef     signed char             s8;
 typedef     signed short int        s16;
 typedef     signed int              s32;
 typedef     signed long long int    s64;
#endif

#ifdef INC_REG_DEFS
 #define REG_BASE        0x4000000
 #define REG_SIOCNT      (REG_BASE + 0x128)  // Serial Communication Control
 #define REG_SIODATA8    (REG_BASE + 0x12a)  // 8bit Serial Communication Data
 #define REG_RCNT        (REG_BASE + 0x134)  // General Input/Output Control
#endif

#include "vsprintf.c"

#define __DOUTBUFSIZE 256
#define __FINBUFSIZE 256  //Must be a multiple of 2! (ex: 32,64,128,256,512..)
#define __KINBUFSIZE 64   //Must be a multiple of 2! (ex: 32,64,128,256,512..)
#define __ESCCHR 27

#define __ESC_NADA   0
#define __ESC_ESCCHR 1
#define __ESC_FOPEN  2
#define __ESC_FCLOSE 3
#define __ESC_FGETC  4
#define __ESC_FPUTC  5
#define __ESC_REWIND 6
#define __ESC_FPUTC_PROCESSED 7         // PC side add CR before LF if DOS machine
#define __ESC_KBDCHR 8

unsigned char __outstr[__DOUTBUFSIZE];
unsigned char __finstr[__FINBUFSIZE];
unsigned char __kinstr[__KINBUFSIZE];
int finptr = 0;
int foutptr = 0;
int kinptr = 0;
int koutptr = 0;

int __dputchar (int c)
   {
   int rcv;
   static int LastChar = 0;
   static int KbdCharNext = 0;

   // Set non-general purpose comms mode
   *(u16 *)REG_RCNT = 0;

   // Init normal comms, 8 bit transfer, receive clocking
   *(u16 *)REG_SIODATA8 = c;
   *(u16 *)REG_SIOCNT = 0x80;

   // Wait until transfer is complete
   while (*(vu16 *)REG_SIOCNT & 0x80) {}

   // Wait until SC is low
   while (*(vu16 *)REG_RCNT & 1) {}

   // Force SD high
   *(u16 *)REG_RCNT = 0x8022;

   // Wait until SC is high
   while ((*(vu16 *)REG_RCNT & 1)==0) {}

   rcv = *(vu16 *)REG_SIODATA8;

   if (KbdCharNext)
      {
      // Put into keyboard buffer
      __kinstr[kinptr++] = rcv;
      kinptr &= (__KINBUFSIZE-1);

      KbdCharNext = 0;

      // Make received char look like a NADA character
      // so that it won't be buffered elsewhere.
      LastChar = __ESCCHR;
      rcv = __ESC_NADA;
      }

   if (LastChar == __ESCCHR)
      {
      // Process escape character
      switch (rcv)
         {
         case __ESC_ESCCHR:
            __finstr[finptr++] = __ESCCHR;
            finptr &= (__FINBUFSIZE-1);
            break;
         case __ESC_KBDCHR:
            KbdCharNext = 1;
            break;
         }
      LastChar = 0;
      }
   else
      {
      if (rcv == __ESCCHR)
         LastChar = __ESCCHR;
      else
         {
         // If char received from PC then save in receive FIFO
         __finstr[finptr++] = rcv;
         finptr &= (__FINBUFSIZE-1);
         }
      }
   return(1);
   }

int dputchar (int c)
   {
   (void) __dputchar(c);
   if (c == __ESCCHR)
      (void) __dputchar(__ESC_ESCCHR);
   return (1);
   }

void __PrintStr (char *str)
   {
   while (*str)
      (void) dputchar(*str++);
   }

int dgetch (void)
   {
   int c;

   // If no character is in FIFO then wait for one.
   while (kinptr == koutptr)
      {
      __dputchar(__ESCCHR);
      __dputchar(__ESC_NADA);
      }

   c = __kinstr[koutptr++];
   koutptr &= (__KINBUFSIZE-1);

   return (c);
   }

int dfgetch (void)
   {
   int c;

   // If no character is in FIFO then wait for one.
   while (finptr == foutptr)
      {
      __dputchar(__ESCCHR);
      __dputchar(__ESC_NADA);
      }

   c = __finstr[foutptr++];
   foutptr &= (__FINBUFSIZE-1);

   return (c);
   }

int dkbhit (void)
   {
   return(kinptr != koutptr);
   }

FILE dfopen (const char *file, const char *type)
   {
   __dputchar(__ESCCHR);
   __dputchar(__ESC_FOPEN);

   while (*file)
      (void) dputchar(*file++);
   dputchar(0);

   while (*type)
      (void) dputchar(*type++);
   dputchar(0);

   return(1);
   }

int dfclose (FILE fp)
   {
   __dputchar(__ESCCHR);
   __dputchar(__ESC_FCLOSE);

   return(1);
   }

int dfgetc (FILE fp)
   {
   __dputchar(__ESCCHR);
   __dputchar(__ESC_FGETC);

   return(dfgetch());
   }

int dfputc (int ch, FILE fp)
   {
   __dputchar(__ESCCHR);
   __dputchar(__ESC_FPUTC);

   __dputchar(ch);                 /* Bug fix. Was:  dputchar(ch); */

   return(1);
   }

void drewind (FILE fp)
   {
   __dputchar(__ESCCHR);
   __dputchar(__ESC_REWIND);
   }

void __PrintStrToFile (FILE fp, char *str)
   {
   while (*str)
      {
      __dputchar(__ESCCHR);
      __dputchar(__ESC_FPUTC_PROCESSED);

      dputchar(*str++);
      }
   }

#define dprintf(x...) ({ dsprintf(__outstr, x); __PrintStr(__outstr); })
#define dfprintf(y,x...) ({ dsprintf(__outstr, x); __PrintStrToFile(y,__outstr); })

#ifdef __ANSI_NAMES
  #define printf  dprintf
  #define fprintf dfprintf
  #define putchar dputchar
  #define getch   dgetch
  #define kbhit   dkbhit

  #define fopen   dfopen
  #define fclose  dfclose
  #define fgetc   dfgetc
  #define fputc   dfputc
  #define rewind  drewind
#endif
