COMPILING SOURCE CODE
---------------------

 To compile this code you must have Thumb GCC,
ARM GCC, or ARM/Thumb GCC installed. (ARM/Thumb
GCC is a version of GCC that supports both
processors in one compiler.) The following
has only been tested with Thumb GCC for windows.

 Also, you need some of the standard include files.
Get arminc.zip from http://www.devrs.com/gba in
the C compilers section. Create a subdirectory
with the name 'include' where you installed GCC
and unzip arminc.zip in this subdirectory.

 You also need crt0.s & lnkscript files from here:
   http://www.devrs.com/gba/ccode.php#cmisc

 To compile the source code just type 'make'.
Before you do that, though, you need to modify
the 'makefile' and set the path for _GCCLIB to
the path where you installed 'libgcc.a'. Then
set the path for _GCCINC to the path where you
unziped arminc.zip.

 For instance, if this file is in the directory
c:/arm, then modify the 'makefile' like so using
windows notepad or a similar editor that is
capable of generating true tab characters:
  _GCCLIB = c:/arm

LIBRARY DOCUMENTATION
---------------------

 The documentation for each of the library functions
is currently found in the source code itself at the
top of each file. (For JPEG documentation read jpeg5.c,
for line drawing read line5.c, etc)

 There are often multiple versions of each library.
(i.e. line2.s, line3.c, line4.c) The latest version
(in this case line4.c) is the one to use. The others
are usually obsolete but included anyway for the curious.


 Libgcc.a can be obtained from the 'armgcc.zip'
package from http://www.devrs.com/gba/

Revision History
----------------
v1.0224 - Original Release
v1.0311 - Line4.s Horizontal line draw is now ~twice as fast.
        - Bug fix for each .s file. STMED & LDMED replaced with
           STMFD & LDMFD. Now gfxLib can be used in subroutines.
v1.0318 - Added JPEG decompression jpeg4.c & jpeg5.c/jpeg5.s.
        - Speeded up pixel.s just a small bit.
        - Speeded up line4.s just a small bit.
