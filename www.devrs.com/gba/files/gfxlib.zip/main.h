
typedef     unsigned char           u8;
typedef     unsigned short int      u16;
typedef     unsigned int            u32;
typedef     unsigned long long int  u64;

typedef     signed char             s8;
typedef     signed short int        s16;
typedef     signed int              s32;
typedef     signed long long int    s64;

#define DISP_LCDC_OFF  0x80
#define DISP_MODE_3    3
#define DISP_MODE_4    4
#define DISP_MODE_5    5
#define DISP_BG2_ON    0x0400

#define REG_BASE    0x4000000
#define REG_DISPCNT (REG_BASE + 0x0)
#define REG_STAT    (REG_BASE + 0x4)
#define VRAM        0x6000000

extern void gfxPixel(u8 px, u8 py, u16 colr, u32 addr);
extern void gfxLine(u8 x1, u8 y1, u8 x2, u8 y2, u16 colr, u32 addr);
extern void gfxFill(u8 x, u8 y, u16 fc, u16 bc, u32 addr);
extern void gfxEllipse(u8 x, u8 y, u8 xr, u8 yr, u16 color, u32 addr);

#define RGB(r,g,b) ((((b)>>3)<<10)+(((g)>>3)<<5)+((r)>>3))







