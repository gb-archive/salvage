//=====================================
// Fast graphics lib test code
//  by Jeff Frohwein
// http://www.devrs.com
//=====================================

// v1.0224 - Original version
// v1.0318 - Added JPEG decode demo

//includes
#include <math.h>
#include "main.h"

#include "subs/jpeg5.c"                 // JPEG decompression code
#include "gs.inc"                       // JPEG Raw demo photo data
#define _VRAM (u8 *)0x6000000

//u32 *srcdata = &rncdata;
//extern int rncdata;

void AgbMain(void)
   {
   u32 i=0;
   u32 bc = RGB(255,255,255);

   *(u16 *)REG_DISPCNT = DISP_MODE_3 | DISP_LCDC_OFF; // LCDC OFF

   // Clear VRAM
   for (i=0; i<240*160*2; i=i+2)
      *(u16 *)(VRAM + i) = 0;

   // Setup mode 3 graphics
   *(u16 *)REG_DISPCNT = DISP_MODE_3 | DISP_BG2_ON;
   *(u16 *)REG_STAT = 0;

   // Draw a JPEG picture to the screen.

   (void) gfxJpeg(0,0,&PhotoGS[0], _VRAM);

   // Draw the photo again several times.
   // The only reason being to cause a delay.
   // You can't see the redraws.
   // I'm just too busy to put in a real delay right now. :P
   (void) gfxJpeg(0,0,&PhotoGS[0], _VRAM);
   (void) gfxJpeg(0,0,&PhotoGS[0], _VRAM);

   // Now draw a duck

   // Draw fading background
   for (i=0; i<160; i++)
      gfxLine(0,i,239,i,RGB(i,i,i+90), VRAM);

//   *(u16 *)0x5000000 = 0;
//   *(u16 *)0x5000002 = 0x7fff;

   // Draw Border
   gfxLine(9,9,70,44,bc,VRAM);
   gfxLine(70,44,109,5,bc,VRAM);
   gfxLine(109,5,148,36,bc,VRAM);
   gfxLine(148,36,231,9,bc,VRAM);
   gfxLine(231,9,192,62,bc,VRAM);
   gfxLine(192,62,220,80,bc,VRAM);
   gfxLine(220,80,186,102,bc,VRAM);
   gfxLine(186,102,223,151,bc,VRAM);
   gfxLine(223,151,138,130,bc,VRAM);
   gfxLine(138,130,110,153,bc,VRAM);
   gfxLine(110,153,93,136,bc,VRAM);
   gfxLine(93,136,4,155,bc,VRAM);
   gfxLine(4,155,29,76,bc,VRAM);
   gfxLine(29,76,9,9,bc,VRAM);

//   while(1) {}

  // gfxPixel(50,50,0x7fff,VRAM);
   gfxFill(1,1,RGB(255,128,128),0x07fff,VRAM);

   // Draw duck
   gfxEllipse(101,105,40,20,0,VRAM);
   gfxEllipse(85,100,42,10,0,VRAM);
      gfxFill(101,105,RGB(192,192,192),0x0,VRAM);
      gfxFill(101,117,RGB(0,255,128),0x0,VRAM);

   gfxEllipse(154,62,23,5,0,VRAM);
      gfxFill(154,64,RGB(255,255,128),0x0,VRAM);
   gfxEllipse(143,67,14,25,0,VRAM);
   gfxEllipse(145,53,4,3,0,VRAM);
      //Erase left side of bill
   for (i=1; i<15; i++)
      gfxLine(132,57+i,155,57+i,0x7fff,VRAM);
      gfxFill(143,67,RGB(0,255,255),0x0,VRAM);

   // halt
   while (1) {}
}

