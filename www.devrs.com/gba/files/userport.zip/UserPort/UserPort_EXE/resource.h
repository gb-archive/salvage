//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UserPort.rc
//
#define IDD_USERPORT                    101
#define IDI_APP                         102
#define IDC_AUMP_LIST_GRANTS            1000
#define IDC_AUMP_EDIT_ADD               1001
#define IDC_AUMP_BUTTON_ADD             1002
#define IDC_AUMP_BUTTON_REMOVE          1003
#define IDC_TCF_EDIT_ADD                1004
#define IDC_BUTTON_UPDATE               1009
#define IDC_BUTTON_START                1010
#define IDC_TCF_LIST_GRANTS             1011
#define IDC_TCF_BUTTON_ADD              1012
#define IDC_BUTTON_STOP                 1013
#define IDC_AUMP_BUTTON_DEFAULTS        1016
#define IDC_TCF_BUTTON_REMOVE           1017
#define IDC_TCF_BUTTON_DEFAULTS         1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
