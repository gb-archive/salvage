
/* Debug Insert */
/* Insert debug tracing code into GAS source code. */

/* Compiled with DJGPP for DOS & GCC for Linux */

// v1.0 - 01-Jun-15  - Original version

// To compile with linux: cc -o dins dins.c

#include <stdio.h>
#include <string.h>
//#include <conio.h>

#ifdef __MSDOS__
#include <io.h>
#include <fcntl.h>
#endif

void StripCRLF (char *s)
   {
   while ( (s[strlen(s)-1] == 0xd) ||
           (s[strlen(s)-1] == 0xa) )
      s[strlen(s)-1] = 0;
   }

void ProcessFile (FILE *fpi,
          FILE *fpo,
          char Comment,
          char *DebugName,
          char Ignore,
          char *Opt1,
          char *Opt2,
          int OptF,
          int OptQ,
          int OptS)
   {
   char s[255];
   int Pos;
   int AddDebug;
   int FirstIns = OptF;

   while (fgets(s,255,stdin) != NULL)
      {
      StripCRLF(s);

      // Get first non white space in string
      Pos=0;
      if (strlen(s) > 1)
         {
         while ( ((s[Pos] == 0x9) || (s[Pos] == 0x20)) &&
                 ((Pos+1) < strlen(s)) )
            Pos++;
         }

      if ( (Pos != 0) &&
           (s[Pos] != Comment) &&
           (s[Pos] != Ignore) )
         AddDebug = 1;
      else
         AddDebug = 0;

      if ( (FirstIns) &&
           (AddDebug) )
         {
         fprintf (fpo, " %s\n", DebugName);
         FirstIns = 0;
         }

      fprintf (fpo, "%s\n", s);

      if (AddDebug)
         {
         fprintf (fpo, " %s\n", DebugName);
         FirstIns = 0;
         }
      }

   // Write include string parts 1 & 2 to output
   if (strlen(Opt1))
      fprintf (fpo, "%s ", Opt1);

   if (OptQ) fprintf (fpo, "\"");
   if (OptS) fprintf (fpo, "'");

   fprintf (fpo, "%s", Opt2);

   if (OptQ) fprintf (fpo, "\"");
   if (OptS) fprintf (fpo, "'");

   fprintf (fpo, "\n");

   }

void usage (int ExitCode)
   {
   fprintf(stderr, "** Debug INSert v1.0 **, by jeff@devrs.com, 2001-Jun-15\n");
   fprintf(stderr, "  - Insert debug tracing code into assembly source code.\n");
   fprintf(stderr, "\n");
   fprintf(stderr, " Usage: dins [-1 string][-2 string][-c char][-f][-h][-i char][-n string][-q][-s] < in_file > out_file\n\n");
   fprintf(stderr, " Options:\n");
   fprintf(stderr, "  -1 = Include string; part 1\n");
   fprintf(stderr, "  -2 = Include string; part 2\n");
   fprintf(stderr, "  -c = Set comment character (default = @)\n");
   fprintf(stderr, "  -f = Insert debug before first instruction as well\n");
   fprintf(stderr, "  -h = This help screen\n");
   fprintf(stderr, "  -i = Set ignore character (default = .)\n");
   fprintf(stderr, "  -n = Set debug string name (default = DEBUG_CODE)\n");
   fprintf(stderr, "  -q = Enclose -2 option with \"\"\n");
   fprintf(stderr, "  -s = Enclose -2 option with ''\n\n");

   fprintf(stderr, "Lines that start with the -c or -i characters (or spaces/tabs\n");
   fprintf(stderr, "followed by these characters) are ignored.\n\n");

   fprintf(stderr, "Example: -1 .include -2 file.asm -q\n");
   fprintf(stderr, "Result:  Adds '.include \"file.asm\"' to the end of the output file.\n");

   exit (ExitCode);
   }

int main(int argc, char **argv)
   {
   int arg;
   int OptF = 0;
   int OptQ = 0;
   int OptS = 0;

   char DebugName[80] = "DEBUG_CODE";
   char Opt1[80] = "\0";
   char Opt2[80] = "\0";
   char Comment = 0x40;                 // @
   char Ignore = 0x2e;                  // .

#ifdef __MSDOS__
   // Needed by DOS to force binary STDIN mode
   (void) setmode(fileno(stdin), O_BINARY);
#endif

   for (arg = 1; arg < (argc); arg++)    //-2
      {

      /* If invalid command line character then exit */
      if ( (argv[arg][0] != '-') ||
           (strlen(argv[arg]) != 2 ) )
         usage(1);

      switch (argv[arg][1])
         {
         case '1':
            strcpy(Opt1, argv[++arg]);
            break;
         case '2':
            strcpy(Opt2, argv[++arg]);
            break;
         case 'c':
            Comment = argv[++arg][0];
            break;
         case 'f':
            OptF = 1;
            break;
         case 'h':
            usage(1);
            break;
         case 'i':
            Ignore = argv[++arg][0];
            break;
         case 'n':
            strcpy(DebugName, argv[++arg]);
            break;
         case 'q':
            OptQ = 1;
            break;
         case 's':
            OptS = 1;
            break;
         default:
            usage(1);
         }
      }

   ProcessFile (stdin,stdout,Comment,DebugName,Ignore,Opt1,Opt2,OptF,OptQ,OptS);

   exit(0);
   }