/****************************************************************/
/*                                                              */
/*                                                              */
/*                         WarioCraft                           */
/*                                                              */
/*                                                              */
/*                Copyright 1999, Harry Mulder                  */
/*                                                              */
/*                                                              */
/*                                                              */
/* This demo explains how to show a Gameboy Color picture on    */
/* screen using GBDK, with data supplied by GBTD and GBMB.      */
/* Although it is C-source, the explaination of the export-     */
/* functions also applies to ASM-programming.                   */
/*                                                              */
/* This demo uses a 512 tileset for the GBC, and makes use      */
/* of the attributes to display colors. Both can be generated   */
/* by either GBTD or GBMB.                                      */
/*                                                              */
/*                                                              */
/* - 512 tileset                                                */
/*                                                              */
/* The GBC has double the tile-capacity of the GB; instead of   */
/* 256 per set, you can use 512 tiles. To remain downward-      */
/* compatible, Nintendo has placed the top 256 tiles into a     */
/* different VRAM-bank. This means that you can not send the    */
/* tile-information in one go; first you have to fill one       */
/* bank, followed by the next.                                  */
/*                                                              */
/* GBTD is capable of splitting a tileset into separate         */
/* blocks of data; this means that you can work in GBTD with    */
/* a tileset of 512 tiles, while the resulting data is          */
/* supplied in a 2x256 fashion.                                 */
/*                                                              */
/* To accomplish this, go to the "Advanced" Tab while           */
/* exporting, check "Split data", and set a "Block size" of     */
/* 256. You have now told GBTD that you want separate blocks,   */
/* containing 256 tiles each.                                   */
/*                                                              */
/*                                                              */
/* - Attributes                                                 */
/*                                                              */
/* In the GBC, each tile-location on screen has an extra byte,  */
/* which contains various settings, including the palette       */
/* used. Again, to remain downward-compatible, this set of      */
/* attributes are stored in a different bank.                   */
/*                                                              */
/* In this scenario, all we want from GBMB is two arrays, one   */
/* containing all tiles, and one containing all attributes.     */
/*                                                              */
/* First off, set "Plane count" to "2 planes (16 bit)", as we   */
/* need a total of two bytes per location (one for the tile,    */
/* one for the attribute).                                      */
/*                                                              */
/* Next, set up two properties in the location format; the      */
/* first should be "[Tile number: low 8]"; this will export     */
/* the tiles, but only the first 8 bits, as the 9th bit is      */
/* part of the attribute-byte. The second property should by    */
/* "[CGB BG Attribute]". This will generate the attributes.     */
/*                                                              */
/* Note that this property is just a quick way to get a         */
/* default set of attributes; is you need to use some special   */
/* settings, you can build your own by using other properties.  */
/* However, this default applies to the current requirements.   */
/*                                                              */
/* The last thing we have to do is tell GBMB to split the       */
/* result into two separate parts. To do this, set "Plane       */
/* order" to "Planes are continues".                            */
/*                                                              */
/*                                                              */
/* - 512 versus 2x256                                           */
/*                                                              */
/* The GBC actually doesn't have a 512 tileset; it are 2 sets   */
/* 256 tiles. However, to keep this detail out of sight when    */
/* designing graphics, both GBMB and GBTD will let you work     */
/* with a 512 tileset. There are some subtle differences        */
/* between the two, with are worth explaining.                  */
/*                                                              */
/* First off, the tile-data is spread over two banks. You       */
/* can tell GBTD to export a full 512 tileset, and do the       */
/* splitting yourself (ie: send the first half of the array,    */
/* then the second half), but as explained above, GBTD can      */
/* also split it for you, giving you a 512 set when designing   */
/* and a 2x256 set when developing.                             */
/*                                                              */
/* With the map-data (ie: locations), things get a bit more     */
/* tricky. The GBC determines the required VRAM-bank by         */
/* looking at bit 3 of the attribute, and using the tile-byte   */
/* as a pointer into that VRAM-bank. GBMB simulates this        */
/* behaviour using the following conclusion:                    */
/*                                                              */
/* You need 9 bits to store a 512-number. The 9th bit will be   */
/* set to "0" for all numbers up to 255; it will be set to "1"  */
/* for all numbers from 256 up. This means that the 9th bit     */
/* can be used as a bank-selector, while the first 8 bits can   */
/* be used as the tile-number (ie: 257 - 9th bit = 1).          */
/*                                                              */
/* So, when constructing your own attribute, use the            */
/* "[Tile number: high 9]" as the bank-selector, and (as done   */
/* here), use the "[Tile number: low 8]" as the tile-number.    */
/*                                                              */
/*                                                              */
/* - Notes                                                      */
/*                                                              */
/* This demo uses the following files:                          */
/*                                                              */
/*   wc.c            Main source file.                          */
/*   WCTiles.*       Tileset and export-results of GBTD.        */
/*   WCMap.*         Map and export-results of GBMB.            */
/*   Make.bat        Batch file used to compile all this.       */
/*                                                              */
/* I suggest placing everything in a directory WC under the     */
/* Examples-directory of GBDK.                                  */
/*                                                              */
/* This demo is GBC-only. This will not work on a GB or GBP     */
/* (It won't destroy them; it will just give a weird picture).  */
/*                                                              */
/* This source is actually a souped-up version of the colorbar  */
/* demo supplied by GBDK.                                       */
/*                                                              */
/* I can be contacted via hpmulder@casema.net. Goto my site at  */
/* http://www.casema.net/~hpmulder for more info on Gameboy-    */
/* development.                                                 */
/*                                                              */
/* This package is public domain; you are free to use it in     */
/* any way you like. However, if you redistribute it, keep it   */
/* intact; do not add or remove anything from the original      */
/* package.                                                     */
/*                                                              */
/* I can not be held responsible for any damage; use it at your */
/* own risk.                                                    */
/*                                                              */
/*                                                              */
/* - History                                                    */
/*                                                              */
/* 23 January, 1999        Initial release.                     */
/*                                                              */
/****************************************************************/



#include <gb.h>
#include "WCMap.h"
#include "WCTiles.h"



/**************************************************************************/
/* GBTD generates a series of constants which contain the various colors  */
/* used by your tileset. These constants will have to the turned into     */
/* an actual palette-table which can be send to the Gameboy. The          */
/* following array is such a table.                                       */
/*                                                                        */
/* Note that the color-constants are only generated when "Palette         */
/* colors" is checked when exporting from GBTD. They reside in WCTiles.h. */
/**************************************************************************/

UWORD WCTilesPal[8*4] =
{
  WCTilesCGBPal0c0,WCTilesCGBPal0c1,WCTilesCGBPal0c2,WCTilesCGBPal0c3,
  WCTilesCGBPal1c0,WCTilesCGBPal1c1,WCTilesCGBPal1c2,WCTilesCGBPal1c3,
  WCTilesCGBPal2c0,WCTilesCGBPal2c1,WCTilesCGBPal2c2,WCTilesCGBPal2c3,
  WCTilesCGBPal3c0,WCTilesCGBPal3c1,WCTilesCGBPal3c2,WCTilesCGBPal3c3,
  WCTilesCGBPal4c0,WCTilesCGBPal4c1,WCTilesCGBPal4c2,WCTilesCGBPal4c3,
  WCTilesCGBPal5c0,WCTilesCGBPal5c1,WCTilesCGBPal5c2,WCTilesCGBPal5c3,
  WCTilesCGBPal6c0,WCTilesCGBPal6c1,WCTilesCGBPal6c2,WCTilesCGBPal6c3,
  WCTilesCGBPal7c0,WCTilesCGBPal7c1,WCTilesCGBPal7c2,WCTilesCGBPal7c3
};





/***************************************************/
/*                   Main program                  */
/***************************************************/

int main()
{

  /*************************************************************************/
  /* the following set of routines loads the palettes into the display.    */
  /* each palette is send (one by one) by using the command:               */
  /*   set_bkg_palette( palette-no, first color in palette, Palette-data ) */
  /*************************************************************************/

  set_bkg_palette( 7, 1, &WCTilesPal[0]  );
  set_bkg_palette( 6, 1, &WCTilesPal[4]  );
  set_bkg_palette( 5, 1, &WCTilesPal[8]  );
  set_bkg_palette( 4, 1, &WCTilesPal[12] );
  set_bkg_palette( 3, 1, &WCTilesPal[16] );
  set_bkg_palette( 2, 1, &WCTilesPal[20] );
  set_bkg_palette( 1, 1, &WCTilesPal[24] );
  set_bkg_palette( 0, 1, &WCTilesPal[28] );




  /*************************************************************************/
  /* Next, the tile-data is send to the display; there is a total of 512   */ 
  /* tiles, but these have to be send in two steps, as each half resides   */
  /* in a different VRAM-bank.                                             */
  /* The data is send to the display by using the command:                 */
  /*   set_bkg_data( first tile in display, number of tiles, tile-data )   */
  /*                                                                       */
  /* Note that both calls to "set_bkg_data" generate an overflow-warning;  */
  /* these can be ignored.                                                 */
  /*************************************************************************/

  /* Select VRAM bank 0 */
  VBK_REG = 0;

  /* Transfer first half */
  set_bkg_data( 0, 256, WCTilesBLK0 );


  /* Select VRAM bank 1 */
  VBK_REG = 1;

  /* Transfer second half */
  set_bkg_data( 0x0, 256, WCTilesBLK1 );




  /*************************************************************************/
  /* Now it's time to send the map-data to the display. Again, in two      */
  /* steps, as the tiles and attributes reside in different banks.         */
  /* The data is send to the display by using the command:                 */
  /*   set_bkg_tiles( Left, Top, Width, Height, Map-data )                 */
  /*************************************************************************/

  /* Select VRAM bank 1 (which stores the attributes) */
  VBK_REG = 1;

  /* Set attributes */
  set_bkg_tiles( 0, 0, WCMapWidth, WCMapHeight, WCMapPLN1 );


  /* Select VRAM bank 0 (which stores the tiles) */
  VBK_REG = 0;

  /* Set data */
  set_bkg_tiles( 0, 0, WCMapWidth, WCMapHeight, WCMapPLN0);





  /*************************************************************************/
  /* the remaining code init the Gameboy and makes it wait untill you turn */
  /* it off..                                                              */
  /*************************************************************************/

  SHOW_BKG;
  enable_interrupts();
  DISPLAY_ON;

  /* Loop forever */
  while(1)
    ;

  return(0);
}
