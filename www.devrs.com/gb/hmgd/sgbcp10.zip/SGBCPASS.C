/*************************************************************************/
/*                                                                       */
/* SGBCPASS                                                              */
/*                                                                       */
/* Converts a SGB color password to actual RGB-values.                   */
/*                                                                       */
/* v1.0, by H. Mulder.                                                   */
/*                                                                       */
/* Password-format:                                                      */
/*                                                                       */
/* First off, forget the dashes; they have no function for decoding.     */
/* Ignore them when reading this text.                                   */
/*                                                                       */
/* The password contains four parts, each 3 decimal characters long.     */
/* Each part is structurally identical, and contains the information     */
/* to rebuild one color of the palette. The first 3 characters from      */
/* the left represent the value for palette-color 0, the next 3          */
/* characters represent the value for palette-color 1, etc.              */
/*                                                                       */
/* A color-part (the 3 characters) represents two settings: the color    */
/* selected from either of two sources, and the light/dark setting on    */
/* the left of the display.                                              */
/*                                                                       */
/* The 'selected color'-part is stored in the first six bits of the      */
/* binary representation of the decimal number. These bits function as   */
/* an index to a color from one of two sources. The source is       	 */
/* determined by the 10th bit: if this bit is 0, the index points to a   */
/* color from the color tables which are part of the color-set selector- */
/* screen. Note that there are actually 10 colors in a on-screen         */
/* palette; 12 are shown, but the first two are always black and white,  */
/* and internally these are located at the end of the palette.           */
/*                                                                       */
/* if the 10th bit is 1, the index points to one of the predefined       */
/* color-sets supplied by the SGB. The color which is used is linked     */
/* to the current position in the palette.                               */
/*                                                                       */
/* These is no structure in the colors of the five palettes and the      */
/* color-sets; they were handpicked by Nintendo (getting them was the    */
/* hardest part of this password-decode; they were determined, not       */
/* retrieved, so there might be some errors in the table; if you find    */
/* any of these errors, please report them to me).                       */
/*                                                                       */
/* The 'light/dark'-setting is stored in the last three bits. The        */
/* handling is as follows:                                               */
/*                                                                       */
/* For darkness: divide each RGB-part by 4. Multiply the result by the   */
/* level of darkness (1=dark, 3=light). This result is the new RGB       */
/* part-value.                                                           */
/*                                                                       */
/* For lightness, XOR the RGB-part with 31, do the same calculation used */
/* for darkness, then XOR the result. in this case, 3=dark, 1=light.     */
/*                                                                       */
/* If you have any questions, remarks or bugs, I can be contacted        */
/* through hpmulder@worldonline.nl.                                      */
/*                                                                       */
/*************************************************************************/


#include <stdio.h>

typedef struct
{
  int R;
  int G;
  int B;
} RGBColor;


RGBColor ColorTable[(10*5)+2];
RGBColor ColorSetTable[(4*8)][4];


int LightDark(int clr, int Lvl)
{
  return ( (clr / 4) * Lvl );
}


void LightColor(int Lvl, RGBColor *col)
{
  col->R = LightDark(col->R ^ 31, Lvl) ^ 31;
  col->G = LightDark(col->G ^ 31, Lvl) ^ 31;
  col->B = LightDark(col->B ^ 31, Lvl) ^ 31;
}

void DarkColor(int Lvl, RGBColor *col)
{
  col->R = LightDark(col->R, Lvl);
  col->G = LightDark(col->G, Lvl);
  col->B = LightDark(col->B, Lvl);
}


int Color2DW( RGBColor *col)
{
  return ( col->R + (col->G << 5) + (col->B << 10));
}





int main(int argc, char **argv)
{
  int ColParts[4];
  RGBColor Colors[4];
  int i,j,k;
  char *p;
  char s[4];

  printf("\nSGBCPASS\nVersion 1.0, by H. Mulder\n\n");
  printf("Converts a SGB Color password to actual RGB-values.\n\n" );


  /* Password passed ? */
  if (argc < 2)
  {
    printf("Usage:\n");
    printf(" SGBCPASS <Password without dashes>.\n" );
    exit(1);
  }

  /* convert password to color parts */
  s[3] = 0;

  p = argv[1];
  for (i=0;i<4;i++)
  {
    for (j=0;j<3;j++) s[j] = *p++;
    ColParts[i] = atoi(s);
  }


  /* Get colors from color-tables */
  for (i=0;i<4;i++)
  {

    /* which type ? */
    if (ColParts[i] & 0x200)
    {
      /* get from colorsets */
      Colors[i] = ColorSetTable[ColParts[i] & 0x1F][i];
    }
    else
    {
      if ((ColParts[i] & 0x3F) >= ((10*5)+2))
      {
        printf(" Error in password./n");
        exit(1);
      }
      else
          /* get from colortable */
        Colors[i] = ColorTable[ColParts[i] & 0x3F];
    }
  }


  /* Modify colors with light/dark */
  for (i=0;i<4;i++)
  {
    switch((ColParts[i] & 0x1C0) >> 6)
    {
      case 0  : LightColor(1, &Colors[i]); break;
      case 1  : LightColor(2, &Colors[i]); break;
      case 2  : LightColor(3, &Colors[i]); break;
      case 3  : break;
      case 4  : DarkColor(3, &Colors[i]); break;
      case 5  : DarkColor(2, &Colors[i]); break;
      case 6  : DarkColor(1, &Colors[i]); break;
      default : printf(" Error in password./n");
                exit(1);
    }
  }

  /* Print colors on screen */
  for (i=0;i<4;i++)
  {
    printf(" Color #%i: $%.4X  (%.2i,%.2i,%.2i)\n", i, Color2DW(&Colors[i]), Colors[i].R, Colors[i].G, Colors[i].B );
  }


  exit(0);

}



RGBColor ColorTable[(10*5)+2] =
{
  {31, 0,  0},
  {31, 8,  29},
  {24, 6,  24},
  {31, 13, 17},
  {31, 16, 0},
  {31, 31, 0},
  {16, 31, 0},
  {0,  19, 0},
  {0,  31, 31},
  {0,  0,  31},

  {11, 19, 31},
  {6,  12, 31},
  {31, 15, 23},
  {31, 20, 26},
  {31, 17, 12},
  {31, 24, 16},
  {31, 27, 0},
  {21, 31, 11},
  {20, 22, 31},
  {4,  31, 18},

  {15, 29, 31},
  {16, 13, 31},
  {21, 12, 31},
  {24, 8,  4},
  {18, 14, 15},
  {16, 12, 0},
  {23, 19, 0},
  {16, 19, 0},
  {11, 21, 6},
  {0,  18, 14},

  {7,  18, 11},
  {10, 13, 20},
  {11, 9,  24},
  {14, 11, 20},
  {18, 7,  13},
  {18, 17, 13},
  {18, 13, 10},
  {25, 22, 18},
  {19, 17, 9},
  {16, 13, 8},

  {24, 22, 20},
  {21, 20, 0},
  {15, 16, 7},
  {15, 16, 13},
  {10, 17, 7},
  {15, 13, 16},
  {16, 14, 14},
  {25, 25, 25},
  {17, 17, 17},
  {11, 11, 11},

  {31, 31, 31},
  {0,  0,  0}
};


RGBColor ColorSetTable[(4*8)][4] =
{
  { {31, 29, 25}, {27, 18,  9}, {21,  5,  3}, {6,  3,  10} },
  { {27, 27, 24}, {25, 22, 14}, {22, 10,  3}, {0,  0,  0}  },
  { {31, 24, 31}, {29, 19, 10}, {19,  7, 12}, {7,  7,  19} },
  { {31, 31, 31}, {24, 16,  9}, {31,  0,  0}, {10, 3,  0}  },
  { {31, 27, 22}, {15, 24, 15}, {13, 17,  8}, {11, 7,  4}  },
  { {27, 29, 31}, {28, 17, 10}, {21,  0,  0}, {0,  8,  2}  },
  { {0,  0,  10}, {0,  20, 30}, {15, 15,  0}, {31, 31, 11} },
  { {31, 29, 28}, {31, 23, 17}, {16,  8,  0}, {6,  3,  0}  },

  { {33, 25, 20}, {24, 17, 9},  {5,  15, 3},  {0,  0,  0} },
  { {31, 31, 31}, {31, 29, 10}, {31, 5,  3},  {10, 0, 11} },
  { {31, 24, 31}, {29, 17, 17}, {15, 6,  29}, {5,  5, 19} },
  { {31, 31, 20}, {2,  31, 1},  {31, 6,  0},  {0,  0, 10} },
  { {31, 25, 16}, {18, 22, 28}, {5,  2, 12},  {2,  1, 2} },
  { {26, 31, 31}, {31, 18, 10}, {20, 0,  0},  {3,  0, 0} },
  { {13, 23, 7},  {28, 10, 8},  {28, 23, 16}, {0,  3, 0} },
  { {31, 31, 31}, {23, 23, 23}, {14, 14, 14}, {0,  0, 0} },

  { {31, 26, 19}, {14, 24, 24}, {31, 12, 0},  {6,  9, 12} },
  { {27, 27, 24}, {28, 16, 6},  {0,  10, 0},  {0,  2, 2} },
  { {28, 21, 25}, {31, 31, 15}, {0,  23, 31}, {4,  4, 11} },
  { {30, 31, 23}, {28, 21, 15}, {0,  25, 0},  {0,  0, 0} },
  { {31, 31, 24}, {28, 22, 13}, {22, 15, 0},  {10, 9, 14} },
  { {15, 15, 25}, {31, 13, 31}, {31, 26, 0},  {8,  8, 8} },
  { {12, 27, 10}, {31, 31, 31}, {25, 6, 7},   {7,  0, 0} },
  { {28, 31, 20}, {15, 25, 7},  {9,  17, 0},  {1,  3, 0} },

  { {30, 21, 13}, {14, 21, 30}, {26, 0,  26}, {0,  0, 15} },
  { {27, 27, 24}, {29, 20, 12}, {8,  15, 7},  {3,  1, 1} },
  { {28, 21, 25}, {27, 20, 12}, {19, 20, 28}, {1,  0, 0} },
  { {30, 31, 23}, {18, 25, 25}, {9,  13, 15}, {1,  4, 9} },
  { {31, 31, 24}, {28, 21, 15}, {15, 11, 17}, {0,  4, 6} },
  { {15, 15, 25}, {27, 16, 27}, {16, 0,  20}, {7,  0, 0} },
  { {12, 27, 10}, {23, 4, 11},  {5,  2,  0},  {0, 16, 12} },
  { {28, 31, 20}, {23, 24, 11}, {16, 17, 8},  {8, 10, 5} }
};


