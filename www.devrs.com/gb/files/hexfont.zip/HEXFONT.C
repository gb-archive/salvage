/************************************************************
*						load_hex_font
*
* This function builds a 256-tile hexadecimal font table
* and loads it in the Tile Data Table at $8800-$97FF.  Each
* tile represents one 2-digit hexedecimal number ($0-$FF).
* The tiles are formatted as follows:
* . The each character is displayed as a 2-digit hex number.
* . Each 2-digit hex number occupies one 8x8 tile.  
* . The top row in the tile is blank.  
* . Each hex digit occupies 5 rows, 3 columns.
* . The first digit starts at the 2nd row and extends to the 6th row.  
* . The second digit starts at the 4th row and extends to the 8th row.  
*
* Thus,the second digit is displayed 2 rows below the first digit.  
* This makes it easy to distinguish consecutive characters when they are 
* displayed in adjacent locations on the screen.
* For example, the 5E will look like this:
*
*    ........
*    XXX.....        $E0
*    X.......			$80
*    XXX.XXX.        $EE
*    ..X.X...        $28
*    XXX.XXX.        $EE
*    ....X...        $08
*    ....XXX.        $0E
*
*
* Author: Yosuf Taraki					2 Feb 2000
*************************************************************/
UBYTE hex_font[] =
{
	// Each hex digit occupies 5 rows.

	0xe0,0xa0,0xa0,0xa0,0xe0,		// 0  
	0x40,0x40,0x40,0x40,0x40,		// 1
	0xe0,0x20,0xe0,0x80,0xe0,		// 2
	0xe0,0x20,0xe0,0x20,0xe0,		// 3
	0xa0,0xa0,0xe0,0x20,0x20,		// 4
	0xe0,0x80,0xe0,0x20,0xe0,		// 5
	0xe0,0x80,0xe0,0xa0,0xe0,		// 6
	0xe0,0x20,0x20,0x20,0x20,		// 7
	0xe0,0xa0,0xe0,0xa0,0xe0,		// 8
	0xe0,0xa0,0xe0,0x20,0xe0,		// 9
	0xe0,0xa0,0xe0,0xa0,0xa0,		// A
	0x80,0x80,0xe0,0xa0,0xe0,		// B
	0xe0,0x80,0x80,0x80,0xe0,		// C
	0x20,0x20,0xe0,0xa0,0xe0,		// D
	0xe0,0x80,0xe0,0x80,0xe0,		// E
	0xe0,0x80,0xe0,0x80,0x80		// F
};

void load_hex_font()
{
	UBYTE i, j, f, *ptr1, *ptr2;

	ptr2 = (UBYTE *)(0x8800);					// point to tile data table

	display_off();			// turn off display so we can safely access VRAM

	i=0x80;		// start at bottom of table
	do
	{
		*ptr2++ =0;		// the top row is blank
		*ptr2++ =0;

		ptr1 = &hex_font[(i>>4)*5];			// point to font table
		for (j=0; j<5; j++)			// copy first digit to tile data table
		{
			f=*ptr1++;
			*ptr2++=f;
			*ptr2++=f;
		}
		ptr2 -=6;		// backup 3 rows

		ptr1 = &hex_font[(i&0xF)*5];			// point to font table
		for (j=0; j<3; j++) 	// copy top 3 rows of 2nd digit to tile data table
		{
			f = *ptr2;
			f |= *ptr1++ >> 4;
			*ptr2++ = f;
			*ptr2++ = f;
		}

		// Copy bottom 2 rows of 2nd digit to tile data table.
		f=*ptr1++ >> 4; *ptr2++=f; *ptr2++=f;
		f=*ptr1++ >> 4; *ptr2++=f; *ptr2++=f;

	} while (++i !=0x80);
}


