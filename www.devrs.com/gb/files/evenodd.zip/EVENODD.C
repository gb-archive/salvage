
/* File even/odd byte splitter */

/* Compiled with DJGPP */

#include <stdio.h>
#include <string.h>
//#include <conio.h>

void main(int argc, char **argv)
   {
   FILE *fpi, *fpo1, *fpo2;
   char c1,c2,c3,c4;
   int ch = '.';
   char fname[20];
   char fname2[20];
   char fname3[20];

   if ( argc > 1)
      {
      strcpy(fname, argv[1]);
      }
   else
      {
      printf("** evenodd v1.0 **, by Jeff F., 99-Jul-25\n");
      printf("  - Split a file into even & odd bytes.\n");
      printf("Usage: evenodd infile <outfile>\n");
      exit(1);
      }

   if ((fpi = fopen(fname, "rb")) == NULL)
      {
      printf("Error opening file '%s'\n", fname);
      exit(1);
      }
   else
      printf("Reading from file '%s'\n", fname);

   /*If an output file name was specified then get it */
   if (argc > 2 )
      strcpy(fname, argv[2]);

   /* Remove any extension from the output file name */
   if (strchr(fname,ch) != NULL)
      fname[strlen(fname)-4] = 0;

   strcpy(fname2,fname);
   strcat(fname2, ".odd");

   strcpy(fname3,fname);
   strcat(fname3, ".evn");

   printf("Writing to files '%s' & '%s'\n", fname2, fname3);

   /*Remove any extension from name */

    fpo1 = fopen(fname2, "wb");
    fpo2 = fopen(fname3, "wb");

    c1 = fgetc(fpi);
    c2 = fgetc(fpi);

    while (feof(fpi) == 0)
       {
       c3 = fgetc(fpi);  fputc(c1,fpo1);
       c4 = fgetc(fpi);  fputc(c2,fpo2);
       c1 = c3;
       c2 = c4;
       }

   fclose(fpi);
   fclose(fpo1);
   fclose(fpo2);

   exit(0);
   }
