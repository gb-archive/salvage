
/* Convert a binary file to C or ASM */

/* Compiled with DJGPP for DOS & GCC for Linux */

// v1.0  - Original version
// v1.1  - Added support for stdin/stdout streams
// v1.2 - 00-May-14 - Removed extra, unneeded CR's in output
// v1.3 - 00-May-25 - Fixed bug where CR & CTRL-Z affected STDIN in msdos.
//                    Added xxh/0xxh hex format support for ASM output.
// v1.4 - 00-May-26 - Fixed broken -h (help) due to dumb bug in last version.
// v1.5 - 00-Dec-30 - Removed unneeded CR's in .h output.
//                    Added support for double word output to .h
// v1.6 - 01-Aug-17 - Added -u which adds count inside [] for c output
// v1.7 - 01-Sep-30 - Fixed extra ( in -v option for C output
// v1.8 - 02-Mar-23 - Added ARM SDT/ADS support for DCB & DCW

#include <stdio.h>
#include <string.h>
//#include <conio.h>

#ifdef __MSDOS__
#include <io.h>
#include <fcntl.h>
#endif

// cast
int atoi (const char *);


void b2h (FILE *fpi,
          FILE *fpo,
          char *ct,
          char *id,
          int size,
          int endian,
          int cols,
          int decimal,
          int incsize,
          int AddLenLabel,
          int AddLenData,
          int AddLenToArray)
   {
   int i = 0; //, c;
   int c1, c2, c3, c4, c5, c6, c7, c8;

   /* prelude */

   fprintf (fpo, "%s %s [", ct, id);

   if (AddLenToArray)
      {
      c1 = incsize;
      if (size>0) c1 >>= 1;
      if (size>1) c1 >>= 1;

      fprintf (fpo, "%d", c1);
      }

   fprintf (fpo, "] = {\n ");

   switch (size)
    {
   case 2 :
      // handle 4 bytes at a time
      c1 = getc(fpi);
      c2 = getc(fpi);
      c3 = getc(fpi);
      c4 = getc(fpi);

      while (c1 != EOF)
         {
         if ((c5 = getc (fpi)) == EOF)
            break;
         if ((c6 = getc (fpi)) == EOF)
            break;
         if ((c7 = getc (fpi)) == EOF)
            break;
         if ((c8 = getc (fpi)) == EOF)
            break;

         if (decimal)
            {
            if (endian)
               fprintf (fpo, "%d,", (c4&0xff)+((c3&0xff)<<8)+((c2&0xff)<<16)+((c1&0xff)<<24) );
            else
               fprintf (fpo, "%d,", (c1&0xff)+((c2&0xff)<<8)+((c3&0xff)<<16)+((c4&0xff)<<24) );
            }
         else
            {
            if (endian)
               fprintf (fpo, "0x%04x,", (c4&0xff)+((c3&0xff)<<8)+((c2&0xff)<<16)+((c1&0xff)<<24) );
            else
               fprintf (fpo, "0x%04x,", (c1&0xff)+((c2&0xff)<<8)+((c3&0xff)<<16)+((c4&0xff)<<24) );
            }


         if (!(++i % cols))
            fprintf (fpo, "\n ");

         c1 = c5;
         c2 = c6;
         c3 = c7;
         c4 = c8;
         }
      /* postlude */
      if (decimal)
         {
         if (endian)
            fprintf (fpo, "%d\r\n};\n,", (c4&0xff)+((c3&0xff)<<8)+((c2&0xff)<<16)+((c1&0xff)<<24) );
         else
            fprintf (fpo, "%d\r\n};\n,", (c1&0xff)+((c2&0xff)<<8)+((c3&0xff)<<16)+((c4&0xff)<<24) );
         }
      else
         {
         if (endian)
            fprintf (fpo, "0x%04x\n};\n", (c4&0xff)+((c3&0xff)<<8)+((c2&0xff)<<16)+((c1&0xff)<<24) );
         else
            fprintf (fpo, "0x%04x\n};\n", (c1&0xff)+((c2&0xff)<<8)+((c3&0xff)<<16)+((c4&0xff)<<24) );
         }
      break;
   case 1 :
      // handle 2 bytes at a time
      c1 = getc(fpi);
      c2 = getc(fpi);

      while (c1 != EOF)
         {
         if ((c3 = getc (fpi)) == EOF)
            break;
         if ((c4 = getc (fpi)) == EOF)
            break;

         if (decimal)
            {
            if (endian)
               fprintf (fpo, "%d,", (c2&0xff)+((c1&0xff)<<8) );
            else
               fprintf (fpo, "%d,", (c1&0xff)+((c2&0xff)<<8) );
            }
         else
            {
            if (endian)
               fprintf (fpo, "0x%04x,", (c2&0xff)+((c1&0xff)<<8) );
            else
               fprintf (fpo, "0x%04x,", (c1&0xff)+((c2&0xff)<<8) );
            }


         if (!(++i % cols))
            fprintf (fpo, "\n ");

         c1 = c3;
         c2 = c4;
         }
      /* postlude */
      if (decimal)
         {
         if (endian)
            fprintf (fpo, "%d\r\n};\n,", (c2&0xff)+((c1&0xff)<<8) );
         else
            fprintf (fpo, "%d\r\n};\n,", (c1&0xff)+((c2&0xff)<<8) );
         }
      else
         {
         if (endian)
            fprintf (fpo, "0x%04x\n};\n", (c2&0xff)+((c1&0xff)<<8) );
         else
            fprintf (fpo, "0x%04x\n};\n", (c1&0xff)+((c2&0xff)<<8) );
         }
      break;
   case 0 :
      // handle 1 byte at a time
      c1 = getc(fpi);

      while (c1 != EOF)
         {
         if ((c2 = getc (fpi)) == EOF)
            break;

         if (decimal)
            fprintf (fpo, "%d,", c1 & 0xff);
         else
            fprintf (fpo, "0x%02x,", c1 & 0xff);

         if (!(++i % cols))
            fprintf (fpo, "\n ");

         c1 = c2;
         }
      /* postlude */
      if (decimal)
         fprintf (fpo, "%d\n};\n", c1);
      else
         fprintf (fpo, "0x%02x\n};\n", c1);
      break;
    }
//    #define <macro>     ((sizeof(<identifier>)/sizeof(<type>))
   if (AddLenLabel)
      {
      fprintf(fpo, "\n#define %s_LEN  (sizeof(%s) / sizeof(%s))\n", id,id,ct);
      }
   }

void b2db (FILE *fpi,
          FILE *fpo,
          char *ct,
          char *id,
          int size,
          int endian,
          int cols,
          int typefmt,
          int incsize,
          int end,
          int label,
          int decimal,
          int AddLenLabel,
          int AddLenData,
          int HexFormat,
          int LeadingZeros,
          int GnuAsm,
          int ArmAsm,
          int Format0x)
   {
   int i = 0; //, c;
   int c1, c2, c3, c4;
   int cx;
   char su8[10];
   char su16[10];
   char numprefix[10];

   if (Format0x)
      strcpy (numprefix,"0x");
   else
      strcpy (numprefix,"$");

   if (ArmAsm)
      {
      strcpy(su8,"dcb");
      strcpy(su16,"dcw");
      }
   else
      {
      if (GnuAsm)
         {
         strcpy(su8,"byte");
         strcpy(su16,"hword");
         }
      else
         {
         strcpy(su8,"db");
         strcpy(su16,"dw");
         }
      }

   /* prelude */

   if (AddLenLabel)
      {
      // include data size
      fprintf (fpo, "%s_LEN ",id);
      if(typefmt) fprintf(fpo, ".");

      fprintf (fpo, "equ %d\n", incsize/(size+1));  //\r
      }

   if (label)
      fprintf (fpo, "%s:\r\n", id);

   if (AddLenData)
      {
      // include data size
      fprintf (fpo, " ");
      if(typefmt) fprintf(fpo, ".");

      fprintf (fpo, "%s %d\n", su16, incsize/(size+1));  //\r
      }

   fprintf (fpo, " ");
   if (typefmt) fprintf(fpo, ".");

   if (size)
      {
      // handle 2 bytes at a time
      fprintf (fpo, "%s ", su16);
      c1 = getc(fpi);
      c2 = getc(fpi);

      while (c1 != EOF)
         {
         if ((c3 = getc (fpi)) == EOF)
            break;
         if ((c4 = getc (fpi)) == EOF)
            break;

         if (decimal)
            {
            if (endian)
               fprintf (fpo, "%d", (c2&0xff)+((c1&0xff)<<8) );
            else
               fprintf (fpo, "%d", (c1&0xff)+((c2&0xff)<<8) );
            }
         else
            {
            if (endian)
               {
               if (HexFormat)
                  {
                  if (LeadingZeros)
                     fprintf (fpo, "0%04xh", (c2&0xff)+((c1&0xff)<<8) );
                  else
                     {
                     //fprintf (fpo, "%xh", (c2&0xff)+((c1&0xff)<<8) );
                     cx = (c2&0xff)+((c1&0xff)<<8);

                     if ( ( (cx > 9     ) && (cx < 0x10  ) ) ||
                          ( (cx > 0x9f  ) && (cx < 0x100 ) ) ||
                          ( (cx > 0x9ff ) && (cx < 0x1000) ) ||
                          (cx > 0x9fff) )
                        fprintf (fpo, "0");
                     fprintf (fpo, "%x", cx);
                     if (cx > 9)
                        fprintf (fpo, "h");
                     }
                  }
               else
                  {
                  if (LeadingZeros)
                     fprintf (fpo, "%s%04x", numprefix, (c2&0xff)+((c1&0xff)<<8) );
                  else
                     {
                     if (((c2&0xff)+((c1&0xff)<<8)) > 9)
                        fprintf (fpo, "%s", numprefix);
                     fprintf (fpo, "%x", (c2&0xff)+((c1&0xff)<<8) );
                     }
                  }
               }
            else
               {
               if (HexFormat)
                  {
                  if (LeadingZeros)
                     fprintf (fpo, "0%04xh", (c1&0xff)+((c2&0xff)<<8) );
                  else
                     {
                     //fprintf (fpo, "%xh", (c1&0xff)+((c2&0xff)<<8) );
                     cx = (c1&0xff)+((c2&0xff)<<8);

                     if ( ( (cx > 9     ) && (cx < 0x10  ) ) ||
                          ( (cx > 0x9f  ) && (cx < 0x100 ) ) ||
                          ( (cx > 0x9ff ) && (cx < 0x1000) ) ||
                          (cx > 0x9fff) )
                        fprintf (fpo, "0");
                     fprintf (fpo, "%x", cx);
                     if (cx > 9)
                        fprintf (fpo, "h");
                     }
                  }
               else
                  {
                  if (LeadingZeros)
                     fprintf (fpo, "%s%04x", numprefix, (c1&0xff)+((c2&0xff)<<8) );
                  else
                     {
                     if (((c1&0xff)+((c2&0xff)<<8)) > 9)
                        fprintf (fpo, "%s", numprefix);
                     fprintf (fpo, "%x", (c1&0xff)+((c2&0xff)<<8) );
                     }
                  }
               }
            }

         if (!(++i % cols))
            {
            fprintf (fpo, "\n ");      //\r
            if (typefmt) fprintf(fpo, ".");
            fprintf (fpo, "%s ", su16);
            }
         else
            fprintf (fpo, ",");

         c1 = c3;
         c2 = c4;
         }
      /* postlude */
         if (decimal)
            {
            if (endian)
               fprintf (fpo, "%d\n", (c2&0xff)+((c1&0xff)<<8) ); //\r
            else
               fprintf (fpo, "%d\n", (c1&0xff)+((c2&0xff)<<8) ); //\r
            }
         else
            {
            if (endian)
               {
               if (HexFormat)
                  {
                  if (LeadingZeros)
                     fprintf (fpo, "0%04xh\n", (c2&0xff)+((c1&0xff)<<8) ); //\r
                  else
                     {
                     //fprintf (fpo, "%xh\n", (c2&0xff)+((c1&0xff)<<8) ); //\r
                     cx = (c2&0xff)+((c1&0xff)<<8);

                     if ( ( (cx > 9     ) && (cx < 0x10  ) ) ||
                          ( (cx > 0x9f  ) && (cx < 0x100 ) ) ||
                          ( (cx > 0x9ff ) && (cx < 0x1000) ) ||
                          (cx > 0x9fff) )
                        fprintf (fpo, "0");
                     fprintf (fpo, "%x", cx);
                     if (cx > 9)
                        fprintf (fpo, "h");
                     fprintf (fpo, "\n");
                     }
                  }
               else
                  {
                  if (LeadingZeros)
                     fprintf (fpo, "%s%04x\n", numprefix, (c2&0xff)+((c1&0xff)<<8) ); //\r
                  else
                     {
                     if (((c2&0xff)+((c1&0xff)<<8)) > 9)
                        fprintf (fpo, "%s", numprefix);
                     fprintf (fpo, "%x\n", (c2&0xff)+((c1&0xff)<<8) ); //\r
                     }
                  }
               }
            else
               {
               if (HexFormat)
                  {
                  if (LeadingZeros)
                     fprintf (fpo, "0%04xh\n", (c1&0xff)+((c2&0xff)<<8) ); //\r
                  else
                     {
                     //fprintf (fpo, "%xh\n", (c1&0xff)+((c2&0xff)<<8) ); //\r
                     cx = (c1&0xff)+((c2&0xff)<<8);

                     if ( ( (cx > 9     ) && (cx < 0x10  ) ) ||
                          ( (cx > 0x9f  ) && (cx < 0x100 ) ) ||
                          ( (cx > 0x9ff ) && (cx < 0x1000) ) ||
                          (cx > 0x9fff) )
                        fprintf (fpo, "0");
                     fprintf (fpo, "%x", cx);
                     if (cx > 9)
                        fprintf (fpo, "h");
                     fprintf (fpo, "\n");
                     }
                  }
               else
                  {
                  if (LeadingZeros)
                     fprintf (fpo, "%s%04x\n", numprefix, (c1&0xff)+((c2&0xff)<<8) ); //\r
                  else
                     {
                     if (((c1&0xff)+((c2&0xff)<<8)) > 9)
                        fprintf (fpo, "%s", numprefix);
                     fprintf (fpo, "%x\n", (c1&0xff)+((c2&0xff)<<8) ); //\r
                     }
                  }
               }
            }
      }
   else
      {
      // handle 1 byte at a time
      fprintf (fpo, "%s ", su8);
      c1 = getc(fpi);

      while (c1 != EOF)
         {
         if ((c2 = getc (fpi)) == EOF)
            break;

         if (decimal)
            fprintf (fpo, "%d", c1 & 0xff);
         else
            {
            if (HexFormat)
               {
               if (LeadingZeros)
                  fprintf (fpo, "0%02xh", c1 & 0xff);
               else
                  {
                  if ( ( ((c1 & 0xff) > 9) && ((c1 & 0xff) < 16) ) ||
                       ((c1 & 0xff) > 0x9f) )
                     fprintf (fpo, "0");
                  fprintf (fpo, "%x", c1 & 0xff);
                  if ((c1 & 0xff) > 9)
                     fprintf (fpo, "h");
                  }
               }
            else
               {
               if (LeadingZeros)
                  fprintf (fpo, "%s%02x", numprefix, c1 & 0xff);
               else
                  {
                  if ((c1 & 0xff) > 9)
                     fprintf (fpo, "%s", numprefix);
                  fprintf (fpo, "%x", c1 & 0xff);
                  }
               }
            }

         if (!(++i % cols))
            {
            fprintf (fpo, "\n ");   //\r
            if (typefmt) fprintf(fpo, ".");
            fprintf (fpo, "%s ", su8);
            }
         else
            fprintf (fpo, ",");

         c1 = c2;
         }
      /* postlude */
      if (decimal)
         fprintf (fpo, "%d\n", c1 & 0xff); //\r
      else
         {
         if (HexFormat)
            {
            if (LeadingZeros)
               fprintf (fpo, "0%02xh\n", c1 & 0xff);   //\r
            else
               {
               if ( ( ((c1 & 0xff) > 9) && ((c1 & 0xff) < 16) ) ||
                    ((c1 & 0xff) > 0x9f) )
                  fprintf (fpo, "0");
               fprintf (fpo, "%x", c1 & 0xff);   //\r
               if ((c1 & 0xff) > 9)
                  fprintf (fpo, "h");
               fprintf (fpo, "\n");   //\r
               }
            }
         else
            {
            if (LeadingZeros)
               fprintf (fpo, "%s%02x\n", numprefix, c1 & 0xff);   //\r
            else
               {
               if ((c1 & 0xff) > 9)
                  fprintf (fpo, "%s", numprefix);
               fprintf (fpo, "%x\n", c1 & 0xff);   //\r
               }
            }
         }
      }

   if (end)
      {
      // include end statement
      fprintf (fpo, " ");
      if(typefmt) fprintf(fpo, ".");

      fprintf (fpo, "end\n");  //\r
      }

   }

void usage (int ExitCode)
   {
   fprintf (stderr, "** b2x v1.8 **, by jeff@devrs.com, 2002-Mar-23\n");
   fprintf (stderr, "  - Convert binary data to C or ASM.\n");
//   fprintf(stderr, "\n");
   fprintf (stderr, " Usage: b2x [-a] [-b] [-c] [-C <#columns>] [-d] [-e] [-h] [-n <label>] [-p] [-r] [-s] [-t <type>] [-u] [-v] [-w] [-x] [-y] < in_file > out_file\n\n");
   fprintf (stderr, " Options:\n");
   fprintf (stderr, "  -a = Output GNU Assembler\n");
   fprintf (stderr, "  -b = Use big endian for 16 bit values (default=little)\n");
   fprintf (stderr, "  -c = C type output (default=ASM)\n");
   fprintf (stderr, "  -C = Specify number of columns (default=8)\n");
   fprintf (stderr, "  -d = Output decimal values (default=hex)\n");
   fprintf (stderr, "  -D = Disable leading zeros in ASM hex output\n");
   fprintf (stderr, "  -e = Add 'end' to ASM output\n");
   fprintf (stderr, "  -h = This help screen\n");
   fprintf (stderr, "  -n = Specify identifier label\n");
   fprintf (stderr, "  -p = Add period to ASM keyword output\n");
   fprintf (stderr, "  -r = Output ARM Assembler\n");
   fprintf (stderr, "  -s = Generate 16 bit values\n");
   fprintf (stderr, "  -t = Specify C data type (default=U8/U16)\n");
//   fprintf (stderr, "  -T = Generate 32 bit values\n");
   fprintf (stderr, "  -u = Add array count inside [] in c output\n");
   fprintf (stderr, "  -v = Add value count label to output\n");
   fprintf (stderr, "  -w = Add value count data to ASM output\n");
   fprintf (stderr, "  -x = Generate ASM #'s of format XXh (default=$XX)\n");
   fprintf (stderr, "  -y = Generate ASM #'s of format 0xXX (default=$XX)\n");

   exit (ExitCode);
   }

int ArrayIn[25];
int ArrayOut[25];

void ShowArrayIn ()
   {
   int x,y;

   for(y=0;y<5;y++)
      {
      for(x=0;x<5;x++)
         {
         printf(" %d", ArrayIn[x+(y*5)] );
         }
      printf("\n");
      }
   printf("\n");
   }

void ShowArrayOut ()
   {
   int x,y;

   for(y=0;y<5;y++)
      {
      for(x=0;x<5;x++)
         {
         printf(" %d", ArrayOut[x+(y*5)] );
         }
      printf("\n");
      }
   printf("\n");
   }

void RotateArrayRight ()
   {
   int x;
   int y = 0;

   ArrayOut[2+(2*5)] = ArrayIn[2+(2*5)];

   for(x=0;x<4;x++)
      {
      ArrayOut[4-y+(x*5)] = ArrayIn[x+(y*5)];
      ArrayOut[4-x+((4-y)*5)] = ArrayIn[4-y+(x*5)];
      ArrayOut[y+((4-x)*5)] = ArrayIn[4-x+((4-y)*5)];
      ArrayOut[x+(y*5)] = ArrayIn[y+((4-x)*5)];
      }
   y = 1;
   for(x=1;x<3;x++)
      {
      ArrayOut[4-y+(x*5)] = ArrayIn[x+(y*5)];
      ArrayOut[4-x+((4-y)*5)] = ArrayIn[4-y+(x*5)];
      ArrayOut[y+((4-x)*5)] = ArrayIn[4-x+((4-y)*5)];
      ArrayOut[x+(y*5)] = ArrayIn[y+((4-x)*5)];
      }
   }

int main(int argc, char **argv)
   {
   int datacount = 0;
//   int c; //,peek;
   int arg;
   int AddLengthLabel = 0;
   int AddLengthData = 0;
   int AddLengthToArray = 0;
   int EnableC = 0;
   int EnableH = 0;
   int Endian = 0;
   int Size = 0;
   int Columns = 8;
   int Period = 0;
   int End = 0;
   int CTypeForce = 0;
   int AddLabel = 0;
   int Decimal = 0;
   int LeadingZeros = 1;
   int GnuAsm = 0;
   int ArmAsm = 0;
   int Format0x = 0;

   char id[20] = "foo";
   char ct[20] = "U8";
   char *U16String = "U16";
   char *U32String = "U32";

//////mess
//  ArrayIn[1+(2*5)] = 1;
//  ArrayIn[2+(2*5)] = 1;
//  ArrayIn[3+(2*5)] = 1;
//  ArrayIn[2+(3*5)] = 1;

//  printf("Array before:\n");

//  ShowArrayIn();
//  RotateArrayRight();
//  ShowArrayOut();

//  exit(0);
///end mess

#ifdef __MSDOS__
   // Needed by DOS to force binary STDIN mode
   (void) setmode(fileno(stdin), O_BINARY);
#endif

   for (arg = 1; arg < (argc); arg++)    //-2
      {

      /* If invalid command line character then exit */
      if ( (argv[arg][0] != '-') ||
           (strlen(argv[arg]) != 2 ) )
         usage(1);

      switch (argv[arg][1])
         {
         case 'a':
            GnuAsm = 1;
            Period = 1;
            break;
         case 'b':
            Endian = 1;
            break;
         case 'c':
            EnableC = 1;
            break;
         case 'C':
            Columns = atoi(argv[++arg]);
            if ((Columns < 1) || (Columns > 256) )
               {
               printf("Columns value out of range!\n");
               exit(1);
               }
            break;
         case 'd':
            Decimal = 1;
            break;
         case 'D':
            LeadingZeros = 0;
            break;
         case 'e':
            End = 1;
            break;
         case 'h':
         case 'H':
            usage(1);
            break;
         case 'n':
            strcpy(id, argv[++arg]);
            AddLabel = 1;
            break;
         case 'p':
            Period = 1;
            break;
         case 'r':
            ArmAsm = 1;
            break;
         case 's':
            Size = 1;
            if (!CTypeForce)
            strcpy(ct, U16String);
            break;
         case 't':
            strcpy(ct, argv[++arg]);
            CTypeForce = 1;
            break;
         case 'T':
            Size = 2;
            if (!CTypeForce)
            strcpy(ct, U32String);
            break;
         case 'u':
            AddLengthToArray = 1;
            break;
         case 'v':
            AddLengthLabel = 1;
            break;
         case 'w':
            AddLengthData = 1;
            break;
         case 'x':
            EnableH = 1;
            break;
         case 'y':
            Format0x = 1;
            break;

         default:
            usage(1);
         }
      }

   if ((AddLengthLabel) || (AddLengthData) || (AddLengthToArray))
      {
      /* Get file length */
 //     while ((c = getc (stdin)) != EOF)
 //        datacount++;


      while (feof(stdin)==0)
         {
         (void) fgetc(stdin);
         datacount++;
         }
      datacount--;

      rewind (stdin);
      }

   if (EnableC)
      b2h (stdin,stdout,ct,id,Size,Endian,Columns,
           Decimal,datacount,AddLengthLabel,
           AddLengthData,AddLengthToArray);
   else
      b2db (stdin,stdout,ct,id,Size,
            Endian,Columns,Period,
            datacount,End,AddLabel,Decimal,
            AddLengthLabel,AddLengthData,EnableH,LeadingZeros,GnuAsm,ArmAsm,Format0x);

   exit(0);
   }