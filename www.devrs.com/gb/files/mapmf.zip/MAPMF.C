/*
 *  TILE256 Map Mirror Flip V1.0
 *        by Jeff Frohwein
 * Last Edit: 20-Apr-97
 *
 * Compiled with Microsoft C/C++ V6.0
 *
 * V1.0 - Initial release.
 *
 */

#include <stdio.h>
#include <string.h>

/* required to keep LINT happy */
#define FPrintF (void) fprintf
#define PrintF (void) printf
#define StrCat (void) strcat
#define StrCpy (void) strcpy

/* Global Variables */
   FILE *fp;
   char map[290][170];

void exit (int status);

void OpenFile (int argc, char **argv)
   {
   char fname[20];

   if (argc>1)
      /* Get input filename */
      StrCpy(fname, argv[1]);
   else
      /* If no name, default to export.h input file */
      StrCpy(fname, "tiles.dat");

   /* Add default extension to filename if left off */
   if (strchr(fname, '.') == NULL)
      StrCat(fname, ".dat");

   /* If file not found, print error & exit */
   if ((fp = fopen(fname, "r+b")) == NULL)
      {
      PrintF("Error opening input file '%s'.\n", fname);
      exit(1);
      }
   }

void CloseFile (void)
   {
   fclose(fp);
   PrintF("Done.\n");
   }

void ErrorExit (void)
   {
   fclose(fp);
   exit(1);
   }

void MapData (void)
   {

   int c;
   int i,j,k,m;
   int temp;
   int x,y;
   fpos_t pos;

   if ( ((c=fgetc(fp)) != 0x54 ) ||
        ((c=fgetc(fp)) != 0x49 ) ||
        ((c=fgetc(fp)) != 0x4c ) ||
        ((c=fgetc(fp)) != 0x45 ) )
      {
      PrintF("Error! Not a TILE256 .dat file.\n");
      ErrorExit();
      }

   /* look for 'S' */
   while ( (!feof(fp)) && ((c=fgetc(fp))!=0x53) )
      {}

   /* Tile size & number of tilesGet RGB data from file for this color */
   if (!feof(fp))
      (void) fscanf(fp, "%d %d %d", &i, &j, &k);

   /* look for '*' */
   while ( (!feof(fp)) && ((c=fgetc(fp))!=0x2a) )
      {}

   /* skip all tile data */
   for(m=0; m<(k*64); m++)
      {
      if (!feof(fp))
         {
         c=fgetc(fp);
         }
      }

   c=fgetc(fp); /* ignore M */
   c=fgetc(fp); /* ignore A */
   c=fgetc(fp); /* ignore P */

   /* Get Map height & width */
   if (!feof(fp))
      (void) fscanf(fp, "%d %d", &i, &j);

   /* look for '*' */
   while ( (!feof(fp)) && ((c=fgetc(fp))!=0x2a) )
      {}

   PrintF("columns=%d rows=%d\n", i,j);

  /* get file position pointer */
  (void) fgetpos(fp, &pos);

  /* Read entire map into memory */
  for(y=0; y<j; y++)
     for(x=0; x<i; x++)
        {
        if (!feof(fp))
           {
           map[x][y]=fgetc(fp);
           }
        }

  PrintF("Mirroring & flipping map.\n");

  /*  Mirror map in memory */
  for(y=0; y<j; y++)
     for(x=0; x<(i/2); x++)
        {
        temp = map[x][y];
        map[x][y] = map[i-x-1][y];
        map[i-x-1][y] = temp;
        }

  /*  Flip map in memory */
  for(x=0; x<i; x++)
     for(y=0; y<(j/2); y++)
        {
        temp = map[x][y];
        map[x][y] = map[x][j-y-1];
        map[x][j-y-1] = temp;
        }

  /* Set file position pointer */
  (void) fsetpos(fp, &pos);

  /* Write entire map to disk */
  for(y=0; y<j; y++)
     for(x=0; x<i; x++)
        {
        fputc(map[x][y], fp);
        }

   fclose(fp);
   }

void main(int argc, char **argv)
   {
   PrintF("TILE256 Map Mirror Flip V1.0, Jeff Frohwein\n\n");

   OpenFile(argc, argv);
   MapData();
   CloseFile();

   exit(0);
   }
