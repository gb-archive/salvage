/*
 *  TILE256 - to GameBoy Tile Converter V1.1
 *        by Jeff Frohwein
 * Last Edit: 20-Apr-97
 *
 * Compiled with Microsoft C/C++ V6.0
 *
 * V1.0 - Initial release.
 * V1.1 - Added switch for two-color output.
 *
 */

#include <stdio.h>
#include <string.h>
//#include <conio.h>
//#include <time.h>

/* required to keep LINT happy */
#define FPrintF (void) fprintf
#define PrintF (void) printf
#define StrCat (void) strcat
#define StrCpy (void) strcpy

/* Assembler output formats */
#define TASM 0
#define RGBDS 1
#define TWO_COLOR 0
#define FOUR_COLOR 1

/* Global Variables */
   FILE *ifp, *ofp;
   char ColorTable[256];
   int Style = TASM;             /* 0 = TASM (default), 1 = RGBDS */
   int Colors = FOUR_COLOR;

void exit (int status);

void Usage (void)
   {
   PrintF(" Usage: cnvt [-c] [-r | t] [infile[.h]] [outfile[.asm]]\n");
   PrintF("\t-c\tGenerate two color output\n");
   PrintF("\t-r\tGenerate RGBDS style output\n");
   PrintF("\t-t\tGenerate Table Assembler style output (default)\n");
   PrintF("\n");
   PrintF("(Infile default is 'export.h'. Outfile default is 'export.asm'.)\n");
   }

void OpenFiles (int argc, char **argv, int arg)
   {
   char fname[20];

   if (argc-arg>1)
      /* Get input filename */
      StrCpy(fname, argv[arg+1]);
   else
      /* If no name, default to export.h input file */
      StrCpy(fname, "export.h");

   /* Add default extension to filename if left off */
   if (strchr(fname, '.') == NULL)
      StrCat(fname, ".h");

   /* If file not found, print error & exit */
   if ((ifp = fopen(fname, "rb")) == NULL)
      {
      PrintF("Error opening input file '%s'.\n", fname);
      exit(1);
      }

   if (argc-arg>2)
      /*Get output filename */
      StrCpy(fname, argv[arg+2]);
   else
      /*Use only filename given */
      StrCpy(fname, "export.asm");

   /* Add default extension to filename if left off */
   if (strchr(fname, '.') == NULL)
      StrCat(fname, ".asm");

   if ((ofp = fopen(fname, "w")) == NULL)
      {
      PrintF("Error opening output file '%s'.\n", fname);
      (void) fclose(ifp);
      exit(1);
      }
   else
      PrintF("Writing data to '%s'.\n", fname);
   }

void CloseFiles (void)
   {
   fclose(ifp);
   fclose(ofp);

   PrintF("Done.\n");
   }

void ReadColorMap (void)
   {
   char n;
   char line[256];
   int c,i,j,k,m;
   int Color;
   int found = 0;

   /* Look for color map */
   while ( (!feof(ifp)) && (found==0) )
      {
      if (fgets(line, 100, ifp) == NULL)
         {
         PrintF("fgets error\n");
         exit(1);
         }

      /* If 4th char in line is 'c' */
      /* then color map found. */
      if (line[3]==0x63)
         found = 1;
      }

   (void) fgets(line, 100, ifp);  /* ignore numcolors define */
   (void) fgets(line, 100, ifp);  /* ignore static struct */

   for(Color=0; Color<256; Color++)
      {
      /* look for { */
      while ( (!feof(ifp)) && ((c=fgetc(ifp))!=0x7b) )
         {}

      /* Get RGB data from file for this color */
      if (!feof(ifp))
         (void) fscanf(ifp, "%d,%d,%d", &i, &j, &k);

      m=i+j+k;

      /* Convert color intensity to 1 of 4 colors */
      n=3;
      if (m<47)
         n=0;
      else
         if (m<95)
            n=1;
         else
            if (m<142)
               n=2;

//      PrintF("%d %d-%d-%d %d %d\n", Color, i, j, k, m, n);
      ColorTable[Color] = n;
      }

//   while (!feof(ifp))
//      {
//      PrintF("%c", fgetc(ifp));
//      }
   }

void ErrorExit (void)
   {
   fclose(ifp);
   fclose(ofp);
   exit(1);
   }

void OutputByteMnemonic (void)
   {
   if (Style == TASM)
      FPrintF(ofp, " .byte ");
   else
      FPrintF(ofp, " db ");
   }

void ReadAndWriteTileData (void)
   {
   int i[8];
   char line[256];
   int c;
   int j,n;
   int k = 0;
   int m = 0;
   int cnt = 0;
   int found = 0;
   int NumTiles;
   int TileWidth;
   int x,y;

   /* Goto top of input file */
   rewind(ifp);

   (void) fgets(line, 100, ifp);  /* ignore comments */
   (void) fgets(line, 100, ifp);  /* ignore comments */
   (void) fgets(line, 100, ifp);  /* ignore comments */
   (void) fgets(line, 100, ifp);  /* ignore comments */
   (void) fgets(line, 100, ifp);  /* ignore comments */

   /* look for 's' */
   while ( (!feof(ifp)) && ((c=fgetc(ifp))!=0x73) )
      {}

   /* Get number of tiles from file */
   if (!feof(ifp))
      {
      if (fscanf(ifp, "%d", &NumTiles) == 1)
         PrintF("Converting %d tiles.\n", NumTiles);
      else
         {
         PrintF("'numtiles' not found in input file.\n");
         ErrorExit();
         }
      }

   /* look for 'h' */
   while ( (!feof(ifp)) && ((c=fgetc(ifp))!=0x68) )
      {}

   /* Get tile width from file */
   if (!feof(ifp))
      {
      if (fscanf(ifp, "%d", &TileWidth) == 1)
         {
         if (TileWidth != 8)
            {
            PrintF("Error! This isn't an 8x8 tile file.\n");
            ErrorExit();
            }
         }
      else
         {
         PrintF("'tilewidth' not found in input file.\n");
         ErrorExit();
         }
      }
   
   /* Look for tile data */
   while ( (!feof(ifp)) && (found==0) )
      {
      if (fgets(line, 100, ifp) == NULL)
         {
         PrintF("fgets error\n");
         exit(1);
         }

      /* If 4th char in line is 't' */
      /* then color map found. */
      if (line[7]==0x74)
         found = 1;
      }

   /* Add label to beginning of tile table */
   FPrintF(ofp, "TileData:\n");

   while ( (!feof(ifp)) && (m<NumTiles) )
      {

      /* Add a comment to the tile data every 8 lines */
      if ((m & 7) == 0)
         FPrintF(ofp, "; Tile #%d\n", m);

      /* look for { */
      while ( (!feof(ifp)) && ((c=fgetc(ifp))!=0x7b) )
         {}

      OutputByteMnemonic();

      k=0;
      while ( (!feof(ifp)) && (k<8) )
         {

         /* look for { */
         while ( (!feof(ifp)) && ((c=fgetc(ifp))!=0x7b) )
            {}

         if (!feof(ifp))
            (void) fscanf(ifp, "%d,%d,%d,%d,%d,%d,%d,%d",
                 &i[0],&i[1],&i[2],&i[3],&i[4],&i[5],&i[6],&i[7]);

//         PrintF("%d-%d-%d-%d-%d-%d-%d-%d",
//                 i[0],i[1],i[2],i[3],i[4],i[5],i[6],i[7]);

//         for(j=0; j<8; j++)
//            {
//            PrintF(" %d", ColorTable[i[j]]);
//            }

         /* Build GB Tile Row */
         x=0;
         y=0;
         for(j=0; j<8; j++)
            {
            x=x*2;
            y=y*2;
            n = ColorTable[i[j]];
            if ((n&1)==1) x++;
            if ((n&2)==2) y++;
            }
         x=x ^ 0xff;
         y=y ^ 0xff;

//         PrintF(" %x %x", x,y);

         /* seperate data with comma */
         if (k!=0)
            FPrintF(ofp, ",");

         if (Colors == TWO_COLOR)
            FPrintF(ofp, "$%x", y);
         else
            FPrintF(ofp, "$%x,$%x", x, y);

//         PrintF("\n");

         k++;
         }

      FPrintF(ofp, "\n");

      m++;
      }

//   while ( (!feof(ifp)) && (cnt<2) )
//      {
//      cnt++;
//      PrintF("%c", fgetc(ifp));
//      }

   }

void ReadAndWriteMapData (void)
   {
   char line[256];
   int c,i,j,k;
   int cnt;
   int found = 0;
   int NumRows, NumCols;

   /* Look for map data */
   while ( (!feof(ifp)) && (found==0) )
      {
      if (fgets(line, 100, ifp) == NULL)
         {
         PrintF("fgets error\n");
         exit(1);
         }

      /* If 4th char in line is 't' */
      /* then color map found. */
      if (line[3]==0x6d)
         found = 1;
      }

   /* look for 's' */
   while ( (!feof(ifp)) && ((c=fgetc(ifp))!=0x73) )
      {}

   /* Get number of map rows from file */
   if (!feof(ifp))
      {
      if (fscanf(ifp, "%d", &NumRows) == 1)
         PrintF("Converting %d map rows.\n", NumRows);
      else
         {
         PrintF("'numrows' not found in input file.\n");
         ErrorExit();
         }
      }

   /* look for 's' */
   while ( (!feof(ifp)) && ((c=fgetc(ifp))!=0x73) )
      {}

   /* Get number of map cols from file */
   if (!feof(ifp))
      {
      if (fscanf(ifp, "%d", &NumCols) == 1)
         PrintF("Converting %d map columns.\n", NumCols);
      else
         {
         PrintF("'numcols' not found in input file.\n");
         ErrorExit();
         }
      }

   /* look for '{' */
   while ( (!feof(ifp)) && ((c=fgetc(ifp))!=0x7b) )
      {}

   /* add label to beginning of map table */
   FPrintF(ofp, "\nMapData:\n");

   for(k=0; k<NumRows; k++)
      {

      /* look for '{' */
      while ( (!feof(ifp)) && ((c=fgetc(ifp))!=0x7b) )
         {}

      /* add row number comment to output file */
      FPrintF(ofp, "; Row #%d\n", k);

      for(i=0; i<NumCols; i++)
         {

         /* If line gets too long, start another one */
         if ( (i!=0) && ((i & 15) == 0) )
            FPrintF(ofp, "\n");

         if ((i & 15) == 0)
            OutputByteMnemonic();
            
         if (fscanf(ifp, "%d,", &j) == 1)
            {
            if ((i & 15) != 0)
               FPrintF(ofp, ",");
            FPrintF(ofp, "$%x", j);
            }
         else
            {
            PrintF("Error reading map data!\n");
            ErrorExit();
            }

         }
      FPrintF(ofp, "\n");
      }

//   while ( (!feof(ifp)) && (cnt<256) )
//      {
//      cnt++;
//      PrintF("%c", fgetc(ifp));
//      }
   }

void main(int argc, char **argv)
   {
   int arg;
   int argp = 0;

   PrintF("TILE256 - to - GameBoy Tile Converter V1.1, Jeff Frohwein\n\n");

   for (arg = 1; arg < argc; arg++)
      {

      /* process command args */
      if (argv[arg][0] == '-')
         {
         argp++;
         switch (argv[arg][1])
            {
         case 'c':
         case 'C':
            Colors = TWO_COLOR;
            break;
         case 'r':
         case 'R':
            Style = RGBDS;
            break;
         case 't':
         case 'T':
            Style = TASM;
            break;
         default:
            Usage();
            exit(1);
            }
         }
      }

//  PrintF("style=%d\n", Style);

   OpenFiles(argc, argv, argp);
//   PrintF ("argc,argp = %d,%d\n", argc, argp);
   ReadColorMap();
   ReadAndWriteTileData();
   ReadAndWriteMapData();

   CloseFiles();

   exit(0);
   }
