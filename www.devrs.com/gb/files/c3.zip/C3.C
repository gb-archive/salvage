/************************************************/
/* CCC - GameBoy cartridge reader / writer V1.3 */
/*                                              */
/* Compiled with Microsoft C/C++ V6.0           */
/************************************************/
/* V1.0 - Original release */
/* V1.1 - Added reset MBC1 registers to default */
/* V1.2 - Added Nintendo LH28F032 flash Support */
/* V1.3 - Added Nintendo DA28F320 flash support */

#include <stdio.h>
#include <conio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
//#include <sys\stat.h>
#include <dos.h>
#include <io.h>
#include <math.h>

typedef struct
{ /* time holder */
  int hour;
  int minute;
  int sec;
  int hsec;
} TIME, *TIME_PTR;

#define Smallprogram            /* disable -a -n -t menue points and automatic -n */

#define GET_TIME	0x2c		/* time request		 */
#define DOS_INT		0x21		/* int to call DOS	 */
#define INITCLK		6			/* initial clock set */
#define DELAY   delaytime(wait_delay)
#define BYTE    unsigned char
#define WORD    unsigned int
#define LONG    unsigned long

/* Programming algorithm defines */
#define AMD29FXXX     0
#define DATA_VALID    1
#define TEN_MS        2
#define FLASH_ADRH    0x40

/* MBC defines */
#define ROM16_RAM8    0
#define ROM4_RAM32    1

/* Change those defines to match your compiler. */
#define OUTPORT(port, val)      outp(port, val); DELAY
#define INPORT(port)            inp(port);

#define CTRL    ctrl_port
#define DATA    data_port
#define STATUS  status_port

/*
 * Bits for MUX (C B A):
 *      ~AUTOFDXT ~SCLINT ~STROBE
 * Bits in CTRL register (7..0):
 *      N/A N/A N/A IRQEnable ~SCLINT INIT ~AUTOFDXT ~STROBE
 */

#define MASK            0x00
#define nSTROBE         0x01
#define nAUTOFDXT       0x02
#define INIT            0x04
#define nSCLINT         0x08

/* CTRL MUX */
#define GET_LOW         MASK | nAUTOFDXT | nSCLINT | nSTROBE
#define GET_HIGH        MASK | nAUTOFDXT | nSCLINT
#define SET_DATA        MASK | nAUTOFDXT           | nSTROBE
#define DATA_REG        MASK | nAUTOFDXT
#define LOW_ADDR        MASK |             nSCLINT | nSTROBE
#define HIGH_ADDR       MASK |             nSCLINT
#define NOT_USED        MASK |                       nSTROBE
#define NOP             MASK

/* CTRL U3 */
#define MREQ            INIT

/* Load a register: toggle CK (OFF and ON) */
#define LOAD(reg)       outp(CTRL, reg); outp(CTRL, NOP)

/* Put data on the bus */
#define WRITE(val)      OUTPORT(DATA, val)

/* Put data on the bus */
#define STROBE(val)     outp(DATA, val); outp(DATA, 0);

/* Write data in bank-switch IC */
#define WRITE_BKSW      WRITE(0x00);  OUTPORT(CTRL, SET_DATA); \
            WRITE(0x01); WRITE(0x00);  /* STROBE(1); */ OUTPORT(CTRL, NOP)

/* Write data in Flash IC */
#define WRITE_FLASH     WRITE(0x00);  OUTPORT(CTRL, SET_DATA); \
              WRITE(0x02); WRITE(0x00);  /* STROBE(2); */ OUTPORT(CTRL, NOP)

/* Write data in RAM */
#define WRITE_MEM       WRITE(0x00); OUTPORT(CTRL, SET_DATA); \
						OUTPORT(CTRL, SET_DATA | MREQ); WRITE(0x01); \
						WRITE(0x00); OUTPORT(CTRL, NOP)
/* disable LED */
#define LED_OFF         WRITE(0x00); LOAD(DATA_REG); OUTPORT(CTRL, SET_DATA)

/*
 * Bits read (7..0):
 *      BUSY ~ACKPR PE SLCT ERROR N/A N/A N/A
 * Bits from REGISTER (D7..D4, D3..D0):
 *      SLCT PE BUSY ~ACK
 */
#define READ_LOW(val)       OUTPORT(CTRL, GET_LOW); val = INPORT(STATUS)
#define READ_HIGH(val)      OUTPORT(CTRL, GET_HIGH); val = INPORT(STATUS)
#define READ_MEM_LOW(val)   OUTPORT(CTRL, GET_LOW | MREQ); val = INPORT(STATUS)
#define READ_MEM_HIGH(val)  OUTPORT(CTRL, GET_HIGH | MREQ); val = INPORT(STATUS)
#define D7(val)             (val & 0x10) << 3
#define D6(val)             (val & 0x20) << 1
#define D5(val)             ((val ^ 0x80) & 0x80) >> 2
#define D4(val)             (val & 0x40) >> 2
#define D3(val)             (val & 0x10) >> 1
#define D2(val)             (val & 0x20) >> 3
#define D1(val)             ((val ^ 0x80) & 0x80) >> 6
#define D0(val)             (val & 0x40) >> 6
#define CONVERT(l, h)       D7(h) | D6(h) | D5(h) | D4(h) | D3(l)  | D2(l)  | D1(l)  | D0(l)

#define NO_MBC  0
#define MBC1    1
#define MBC2    2

#ifdef MK_FP
  #undef MK_FP
#endif
#define MK_FP(seg, ofs)     ((void far *) ((unsigned long) (seg)<<16|(ofs)))

char *type[] = {"ROM ONLY",             //0
                "ROM+MBC1",             //1
                "ROM+MBC1+RAM",         //2
                "ROM+MBC1+RAM+Battery", //3
                "Unknown",              //4
                "ROM+MBC2",             //5
                "ROM+MBC2+Battery",     //6
                "UNKNOWN",              //7
                "ROM+RAM",              //8
                "ROM+RAM+Battery",      //9
                "Unknown",              //A
                "ROM+MMM01",            //B
                "ROM+MMM01+SRAM",             //C
                "ROM+MMM01+SRAM+Battery",     //D
                "Unknown",                    //E
                "ROM+MBC3+Timer+Battery",     //F
                "ROM+MBC3+Timer+RAM+Battery", //10
                "ROM+MBC3",                   //11
                "ROM+MBC3+RAM",               //12
                "ROM+MBC3+RAM+Battery",       //13
                "Unknown",                    //14
                "Unknown",                    //15
                "Unknown",                    //16
                "Unknown",                    //17
                "Unknown",                    //18
                "ROM+MBC5",                   //19
                "ROM+MBC5+RAM",               //1A
                "ROM+MBC5+RAM+Battery",       //1B
                "ROM+MBC5+Rumble",            //1C
                "ROM+MBC5+Rumble+RAM",        //1D
                "ROM+MBC5+Rumble+RAM+Battery",//1E
                "Pocket Camera"};             //1F

int rom[] = { 32, 64, 128, 256, 512, 1024, 2048, 4096 };
int ram[] = { 0, 2, 8, 32, 128 };
int mbc[] = { NO_MBC, MBC1, MBC1, MBC1, MBC2, MBC2 };

int del, wait_delay;
unsigned ctrl_port;
unsigned data_port;
unsigned status_port;
unsigned checksum;
unsigned char Algorithm, Size;
unsigned long Address;
char Data, Control;
int FlashBlocks, FlashBlocks2;

void usage(char name[])
{
    char small[128];
    char smaller[20];
    char a[2];
    char i = 0;
    char z;

    strncpy(small, name, strlen(name)-4);    /* remove trailing file type */
    small[strlen(name)-4] = 0;               /* mark end of string */

    while (small[strlen(small)-i] != 0x5c)   /* loop until we find a \ */
       i++;

    smaller[0] = 0;
    a[1] = 0;
    for (z=0; z<i-1; z++)                    /* make string of just filename */
       {
       a[0] = small[strlen(small)-i+z+1];
       strcat(smaller, a);
       }

    printf("\nCarbon Copy Card (C3) Reader / Writer Version 1.3\n");
#ifndef Smallprogram
    printf("Usage: %s [-l int] [-w int] [-m int] [-n int]\n", smaller);
	printf("                [-t |-d |-a |-p file |-s file |-v file |-b file |-r file ]\n");
#else
    printf("Usage: %s [-l int][-w int][-d|-a|-p file|-s file|-v file|-b file|-r file]\n", smaller);
#endif
    printf("\t-l\tSpecify the port to use (default is 1 = LPT1)\n");
	printf("\t-w\tSpecify the time to wait between accesses to the cartridge\n");
#ifndef Smallprogram
	printf("\t-t\tTest the cartridge reader\n");
#endif
	printf("\t-d\tDump first 256 bytes of chip to screen\n");
	printf("\t-a\tAnalyze the cartridge header\n");
#ifndef Smallprogram
	printf("\n\t-m\tMode of programming (0=AMD Am29Fxxx,1=Data Valid,2=10ms)\n");
	printf("\t\t(default is 0 = AMD Am29Fxxx)\n");
	printf("\t-n\tNumber of bits (0=16K,1=32K,2=64K,3=128K,4=256K,5=512K,6=1M,\n");
	printf("\t\t7=2M,8=4M,9=8M,10=16M) (default is 8 = 4Mbits)");
#endif
	printf("\n\t-p\tProgram cartridge from file\n");
	printf("\t-s\tSave the cartridge into file\n");
	printf("\t-v\tVerify cartridge matches file\n");
	printf("\n\t-b\tBackup the SRAM into file\n");
	printf("\t-r\tRestore the SRAM from file\n");
}

void init_port(int port)
{
	data_port = *(unsigned far *)MK_FP(0x0040, 6 + 2*port);
	if(data_port == 0)
	{
		printf("Can't find address of parallel port %d...\n", port);
		exit(1);
	} else {
		status_port = data_port + 1;
		ctrl_port = data_port + 2;
#ifndef Smallprogram
		printf("Parallel port %d is located at %X-%X\n", port, data_port, ctrl_port);
#endif
	}
}

void delaytime (int i)
{
//   int i;
//   i = wait_delay;
	while(i--);
}

/* write low address byte */
void ADDRESS_LOW(val)
{
	WRITE((BYTE)val);
	LOAD(LOW_ADDR);
}

/* write high address byte */
void ADDRESS_HIGH(val)
{
	WRITE((BYTE)val);
	LOAD(HIGH_ADDR);
}

/* write data in Nintendo flash cart */

void WRITE_NFLASH(val)
{
    WRITE((BYTE)val);
	LOAD(DATA_REG);
    WRITE(0x00);
    OUTPORT(CTRL, SET_DATA );
	WRITE(0x01);
	WRITE(0x00);
	OUTPORT(CTRL, NOP);
}

void select_mbc_defaults (void)
{

//    WRITE(ROM16_RAM8);                  /* Set MBC to 16Mbit ROM & 8KByte RAM mode */
//    LOAD(DATA_REG);
//    WRITE(0x60);
//    LOAD(HIGH_ADDR);
//    WRITE(0x00);
//    LOAD(LOW_ADDR);
//    WRITE_BKSW;

//    WRITE(0x00);                        /* Set high memory bank select to 0x00 */
//    LOAD(DATA_REG);
//    WRITE(0x40);
//    LOAD(HIGH_ADDR);
//    WRITE(0x00);
//    LOAD(LOW_ADDR);
//    WRITE_BKSW;

   /* Set Nintendo flash cart to memory read */
   ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);
   /*  Set bank ms byte */
   ADDRESS_LOW(0x00); ADDRESS_HIGH(0x30); WRITE_NFLASH(0x0);
   /*  Set bank ms byte */
   ADDRESS_LOW(0x00); ADDRESS_HIGH(0x20); WRITE_NFLASH(0x0);

}

void read_data(FILE *fp, int type, int sizekB)
{
	int bank, page, byte, nbbank;
	unsigned char low, high, val;
    unsigned chk;

	/* One bank is 16k bytes */
	nbbank = sizekB / 16;
    chk = 0;

    for(bank = 0; bank < nbbank; bank++) {
		printf("Reading bank %d\n", bank);
		if(bank) {
			WRITE(bank);
			LOAD(DATA_REG);
			WRITE(0x21);
			LOAD(HIGH_ADDR);
			WRITE(0x00);
			LOAD(LOW_ADDR);
			WRITE_BKSW;
		}
		for(page = (bank ? 0x40 : 0); page < (bank ? 0x80 : 0x40); page++) {
			printf(".");
			WRITE(page);
			LOAD(HIGH_ADDR);

			for(byte = 0; byte <= 0xFF; byte++) {
				WRITE(byte);
				LOAD(LOW_ADDR);

				READ_LOW(low);
				READ_HIGH(high);
				val = CONVERT(low, high);
                fputc(val, fp);
                chk += val;
			}
		}
        LED_OFF;
		printf("\n");
	}
	chk -= checksum & 0xFF;
	chk -= (checksum >> 8);
	if(chk == checksum)
		printf("Checksum OK\n");
	else
		printf("Warning: checksum is wrong (waiting for %uX, got %uX)\n", checksum, chk);
}

void read_sram(FILE *fp, int type, int sizekB)
{
	int bank, page, byte, nbbank, banksize;
	unsigned char low, high;

	if(type == MBC1) {
		/* One bank is 8k bytes */
		nbbank = sizekB / 8;
		if(nbbank == 0) {
			nbbank = 1;
			banksize = sizekB << 2;
		} else
			banksize = 0x20;
	} else {
		/* SRAM is 512 * 4 bits */
		nbbank = 1;
		banksize = 0x02;
	}

	/* Initialize the bank-switch IC */
	WRITE(0x0A);
	LOAD(DATA_REG);
	WRITE(0x00);
	LOAD(HIGH_ADDR);
	WRITE(0x00);
	LOAD(LOW_ADDR);
	WRITE_BKSW;

	for(bank = 0; bank < nbbank; bank++) {
		if(type == MBC1) {
			printf("Reading bank %d\n", bank);
			WRITE(bank);
			LOAD(DATA_REG);
			WRITE(0x40);
			LOAD(HIGH_ADDR);
			WRITE(0x00);
			LOAD(LOW_ADDR);
			WRITE_BKSW;
		}
		for(page = 0xA0; page < 0xA0 + banksize; page++) {
			printf(".");
			WRITE(page);
			LOAD(HIGH_ADDR);

			for(byte = 0; byte <= 0xFF; byte++) {
				WRITE(byte);
				LOAD(LOW_ADDR);

				READ_MEM_LOW(low);
				READ_MEM_HIGH(high);
				fputc(CONVERT(low, high), fp);
			}
		}
        LED_OFF;
        printf("\n");
	}
}

void write_sram(FILE *fp, int type, int sizekB)
{
	int bank, page, byte, nbbank, banksize;

	if(type == MBC1) {
		/* One bank is 8k bytes */
		nbbank = sizekB / 8;
		if(nbbank == 0) {
			nbbank = 1;
			banksize = sizekB << 2;
		} else
			banksize = 0x20;
	} else {
		/* SRAM is 512 * 4 bits */
		nbbank = 1;
		banksize = 0x02;
	}

	/* Initialize the bank-switch IC */
	WRITE(0x0A);
	LOAD(DATA_REG);
	WRITE(0x00);
	LOAD(HIGH_ADDR);
	WRITE(0x00);
	LOAD(LOW_ADDR);
	WRITE_BKSW;

	for(bank = 0; bank < nbbank; bank++) {
		if(type == MBC1) {
			printf("Writing bank %d\n", bank);
			WRITE(bank);
			LOAD(DATA_REG);
			WRITE(0x40);
			LOAD(HIGH_ADDR);
			WRITE(0x00);
			LOAD(LOW_ADDR);
			WRITE_BKSW;
		}
		for(page = 0xA0; page < 0xA0 + banksize; page++) {
			printf(".");
			WRITE(page);
			LOAD(HIGH_ADDR);

			for(byte = 0; byte <= 0xFF; byte++) {
				if(feof(fp)) {
					printf("Unexpected EOF\n");
					exit(1);
				}
				WRITE(byte);
				LOAD(LOW_ADDR);
				WRITE(fgetc(fp));
				LOAD(DATA_REG);
				WRITE_MEM;
			}
		}
        LED_OFF;
		printf("\n");
	}
}

void read_header(unsigned char *h)
{
	unsigned char low, high;
	int byte, index = 0;

	WRITE(0x01);
	LOAD(HIGH_ADDR);

	for(byte = 0; byte < 0x50; byte++) {
		WRITE(byte);
		LOAD(LOW_ADDR);

		READ_LOW(low);
		READ_HIGH(high);
		h[index++] = CONVERT(low, high);
	}
	printf("Game name     : %s\n", &h[0x34]);
	printf("Cartridge type: %d(%s)\n", h[0x47], type[h[0x47]]);
	printf("ROM size      : %d(%d kB)\n", h[0x48], rom[h[0x48]]);
	printf("RAM size      : %d(%d kB)\n", h[0x49], ram[h[0x49]]);
	checksum = ((unsigned)h[0x4E] << 8) + h[0x4F];
}

void test()
{
        printf("\nD0 - D7 data lines check !\n");
        printf("Check pins <22 up to 29> of GB connector\n");
        WRITE(0x00);
        LOAD(LOW_ADDR);
        LOAD(HIGH_ADDR);
        LOAD(DATA_REG);
        OUTPORT(CTRL, SET_DATA);
		printf("They should all be low. Press <RETURN>\n");
		getch();

        WRITE(0xFF);
        LOAD(DATA_REG);
        OUTPORT(CTRL, SET_DATA);
        printf("Now, they should all be high. Press <RETURN>\n");
		getch();

        printf("\n\n\nA0 - A7 address lines check !\n");
        printf("Check pins <6 up to 13> of GB connector\n");
        WRITE(0x00);
        LOAD(LOW_ADDR);
		printf("They should all be low. Press <RETURN>\n");
		getch();

        WRITE(0xFF);
        LOAD(LOW_ADDR);
        printf("Now, they should all be high. Press <RETURN>\n");
		getch();

        printf("\n\n\nA8 - A15 address lines check !\n");
        printf("Check pins <14 up to 21> of GB connector\n");
        WRITE(0x00);
        LOAD(HIGH_ADDR);
		printf("They should all be low. Press <RETURN>\n");
		getch();

        WRITE(0xFF);
        LOAD(HIGH_ADDR);
        printf("Now, they should all be high. Press <RETURN>\n");
		getch();

        printf("\n\n\nCS line check !\n");
        printf("check pin <5> of GB connector\n");
        OUTPORT(CTRL, MREQ);
		printf("Should be low. Press <RETURN>\n");
		getch();

        OUTPORT(CTRL, NOP);
        printf("Should be high. Press <RETURN>\n");
		getch();

        printf("\n\n\nRD line check !\n");
        printf("check pin <4> of GB connector\n");
        OUTPORT(CTRL, NOP);
		printf("Should be low. Press <RETURN>\n");
		getch();

        OUTPORT(CTRL, SET_DATA);
        printf("Should be high. Press <RETURN>\n");
		getch();

        printf("\n\n\nWR line check !\n");
        printf("check pin <3> of GB connector\n");
        WRITE(0x01);
        LOAD(DATA_REG);
		OUTPORT(CTRL, SET_DATA);
        printf("Should be low. Press <RETURN>\n");
		getch();

        OUTPORT(CTRL, NOP);
        printf("Should be high. Press <RETURN>\n");
		getch();

        printf("\n\n\nAudio IN line check !\n");
        printf("check pin <31> of GB connector\n");
        WRITE(0x02);
        LOAD(DATA_REG);
		OUTPORT(CTRL, SET_DATA);
        printf("Should be low. Press <RETURN>\n");
		getch();

        OUTPORT(CTRL, NOP);
        printf("Should be high. Press <RETURN>\n");
		getch();

        LED_OFF;
        printf("\n\n\nTest complete !\n\n");
}

/* fills timetype structure n with current time using DOS interrupt 21 */

get_time(n)
TIME_PTR n;
{
  union REGS inregs;
  union REGS outregs;

  inregs.h.ah = GET_TIME;

  int86(DOS_INT, &inregs, &outregs);

  n->hour = outregs.h.ch;
  n->minute  = outregs.h.cl;
  n->sec  = outregs.h.dh;
  n->hsec = outregs.h.dl;

  return(0);
}

void msleep(int ms)
   {
   /* sleep for ms milliseconds */
   static long count = 0;
   static long wait = 1;
   long d, i, loops;
   TIME n1, n2;
   int delay = 0;

   if (count == 0)
      {
      printf("Delay calibration in progress...\n");
      /* wait for a clock tick */
      count = 1000L;
      while (delay < 200)
         {
         wait = wait << 1;
         get_time(&n1);
         delay = n1.hsec;
         while (n1.hsec == delay)
            get_time(&n1);
         /* get a ballpark figure */
         for (loops = 0; loops < count; loops++)
            for (i = 0; i<wait; i++);
         get_time(&n2);
         delay = (100*n2.sec + n2.hsec) - (100*n1.sec + n1.hsec);
         if (delay < 0) delay += 6000;
         }
/*
printf("1st time %2d:%02d:%02d.%02d\n", n1.hour, n1.minute, n1.sec, n1.hsec);
printf("%02d.%02d ... %02d.%02d\n", n1.sec, n1.hsec, n2.sec, n2.hsec);
printf("delay %d ms\n", 10*delay);
*/
      /* this is the first guess */
      count = 100* count / delay;
/*
printf("Delay %d loops/ms\n", count);
*/
      /* this one should be about 2 sec */
/*
      get_time(&n1);
      d = INITCLK*count;
      for (loops = 0; loops < d; loops++)
         for (i = 0; i<wait; i++);
      get_time(&n2);
      delay = (100*n2.sec + n2.hsec) - (100*n1.sec + n1.hsec);
      if (delay < 0) delay += 6000;
      printf("delay %d ms\n", 10*delay);
      count = INITCLK*100*count / delay;
      printf("Delay %d loops/ms\n", count);
*/
      }
   else
      {
      get_time(&n1);

      d = ms*count/1000;
      for (loops = 0; loops < d; loops++)
         for (i = 0; i<wait; i++);

      get_time(&n2);
      del = (100*n2.sec + n2.hsec) - (100*n1.sec + n1.hsec);
      if (del < 0) delay += 6000;
/*
      printf("delay %d ms\n", delay);
*/
      }
   }

/* Return actual chip size in bits */

LONG ChipSize (BYTE size)
   {
   BYTE i;
   LONG Length = 16384;

   for(i=0; i<size; i++)
      Length *= 2;

   return(Length);
   }

/* Print chip size */

void PrintChipSize (void)
   {
   LONG i = ChipSize(Size);
   printf("Chip size = %lu bits (%lu bytes)\n", i, i/8);
   }

/* Set chip address */

void SetAddr (LONG Addr)
{
	int Bank, AdrReg;

   	Address = Addr;

    Bank = (int)((Address & 0x3fffff) >> 14);
    WRITE(Bank);
	LOAD(DATA_REG);
	WRITE(0x21);
	LOAD(HIGH_ADDR);
	WRITE(0x00);
	LOAD(LOW_ADDR);
	WRITE_BKSW;

    AdrReg = (int)(Address & 0x3fff);
   	if (Address > 0x3fff) AdrReg += 16384;

    WRITE((BYTE)(AdrReg & 0x00ff));
	LOAD(LOW_ADDR);
	WRITE((BYTE)(AdrReg >> 8));
	LOAD(HIGH_ADDR);
}

/* Increment chip address */

void IncAddr(void)
{
   	Address++;
   	SetAddr(Address);
}

/* Read a byte from chip */

BYTE ReadByte(void)
{
   	BYTE i;
	unsigned char low, high;

	READ_LOW(low);
	READ_HIGH(high);
	i = CONVERT(low, high);
  	return(i);
}

/* Read a byte from Nintendo flash cart */

BYTE ReadNByte(void)
{
    BYTE low,high;
//    BYTE a;

    OUTPORT(CTRL, GET_HIGH | MREQ);
    high = INPORT(STATUS);
    OUTPORT(CTRL,  GET_LOW | MREQ);
    low = INPORT(STATUS);

    /* Release the MREQ line */
    OUTPORT(CTRL, GET_LOW);

    return( D7(high)|D6(high)|D5(high)|D4(high)|D3(low)|D2(low)|D1(low)|D0(low) );
}

/* Write a byte to chip */

void WriteByte(BYTE val)
{
	WRITE(val);
	LOAD(DATA_REG);
    WRITE_FLASH;
}

/* Wait for program byte completion */

BYTE ProgramDone (BYTE val)
   {
   BYTE Check;
   BYTE Pass = 0;

   switch (Algorithm)
      {
      case AMD29FXXX:
         Check = ReadByte();

         /* Loop until chip done programming */
         while ( (Check != val) &&
                 ((Check & 0x20)==0) )
            Check = ReadByte();

         if (Check == val)
            Pass = 1;
         else
            {
            Check = ReadByte();
            if (Check == val)
               Pass = 1;
            }
         break;
      case DATA_VALID:
         /* Loop until chip done programming */

         while (ReadByte() != val)
            {}

         Pass = 1;
         break;
      case TEN_MS:
         /* Delay for 10 milliseconds */

         msleep(10);
         Pass = 1;
         break;
      }
   return (Pass);
   }

/* Program a byte on chip */

BYTE ProgramByte(LONG Addr, BYTE val)
   {
   BYTE Pass = 0;
   int AdrReg;

   /* Set bank for byte write enable */
   WRITE(0x01); LOAD(DATA_REG);
   WRITE(0x21); LOAD(HIGH_ADDR);
   WRITE(0x00); LOAD(LOW_ADDR);
   WRITE_BKSW;

   /* Write 5555,aa - 2aaa,55 - 5555,a0 */
   WRITE(0x55); LOAD(LOW_ADDR); LOAD(HIGH_ADDR); WriteByte(0xaa);
   WRITE(0xaa); LOAD(LOW_ADDR); WRITE(0x2a); LOAD(HIGH_ADDR); WriteByte(0x55);
   WRITE(0x55); LOAD(LOW_ADDR); LOAD(HIGH_ADDR); WriteByte(0xa0);

   SetAddr(Addr);    WriteByte(val);

   /* Wait until chip done programming */
   Pass = ProgramDone(val);

   if (Pass == 0)
      printf("Write failed at Address %lx of cartridge.\n", Address);

   return (Pass);
   }


void dump(BYTE BaseAdr)
   {
   unsigned char low, high;
   int i;
   BYTE First = 1;
   BYTE val;
   BYTE Display[17] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

   WRITE(BaseAdr);
   LOAD(HIGH_ADDR);

   for(i=0; i<256; i++)
      {
      if (First == 1)
         {
         if (i < 16) printf("0");
         printf("%hx - ",i);
         First = 0;
         }
      WRITE(i);
      LOAD(LOW_ADDR);
      READ_LOW(low);
      READ_HIGH(high);
      val =  CONVERT(low, high);

      if ((val > 31) & (val < 127))
       Display[i & 0xf] = val;
      else
       Display[i & 0xf] = 46;

      if (val < 16)
         printf("0");
      printf("%hx ",val);
      if ((i & 0xf)==0xf)
         {
         First = 1;
         printf("   %3s",(&Display[0]));
         printf("\n");
         }
      }
   LED_OFF;
   }

/* Compare chip to a file */

void VerifyChip(FILE * fp)
   {
   LONG i = 0;
   BYTE val;
   BYTE CompareFail = 0;
   int c;

   /* Set memory bank ms byte */
//   ADDRESS_LOW(0x00); ADDRESS_HIGH(0x30); WRITE_NFLASH(0);

   PrintChipSize();
   printf("Verify GameBoy cartridge...\n");


   SetAddr(0);

   while ( (!feof(fp)) && (i < (ChipSize(Size)/8)) )
      {
      c = fgetc(fp);
      if (c != EOF)
         {
         val = ReadByte();
         IncAddr();
         if (c != val)
            {
            printf("Address %lx - Cartridge %hx : File %hx\n", i, val, c);
            CompareFail = 1;
            }
         i++;
         }
      }

      if (CompareFail == 0)
         printf("%lu bytes compared ok.\n", i);
   LED_OFF;
   }

/* Erase AMD chips */

BYTE EraseAm29Fxxx(void)
   {
   BYTE Pass = 0;
   BYTE Val  = 0;
   BYTE Val2 = 0x40;

   SetAddr(0x5555); WriteByte(0xaa);
   SetAddr(0x2aaa); WriteByte(0x55);
   SetAddr(0x5555); WriteByte(0x80);
   SetAddr(0x5555); WriteByte(0xaa);
   SetAddr(0x2aaa); WriteByte(0x55);
   SetAddr(0x5555); WriteByte(0x10);

   SetAddr(0);
   printf("Erasing GameBoy cartridge...");

   if (1==0)
      {
      /* Use toggle bit algorithm to tell when done */
      while (1==1) //((Val & 0x40) != (Val2 & 0x40)) &&
                //((Val2 & 0x20)==0) )
         {
         Val = ReadByte();
         Val2 = ReadByte();
         printf("%x,%x\n", Val, Val2);
         }

      /* If toggle stopped, chip erased okay */
      if ((Val & 0x40) == (Val2 & 0x40))
         Pass = 1;
      else
         {
         Val = ReadByte();
         if ((Val & 0x40) == (Val2 & 0x40))
            Pass = 1;
         }
      }
   else
      {
      /* Use data polling algorithm to tell when done */
      Val = ReadByte();
      while (((Val & 0x80)==0) && ((Val & 0x20)==0))
         {
         Val = ReadByte();
         }
      if ((Val & 0xA0)==0xA0) Pass=1;
      }

   if (Pass == 0)
      printf("Cartridge erase failed!\n");
   else
      printf("ok\n");

   return (Pass);
   }

void ErrorExit(void)
   {
   LED_OFF;
   exit(1);
   }

/* Begin chip programming */

void ProgramAMD(FILE *fp)
   {
   BYTE b;
   BYTE Pass = 1;
   int c;
   LONG Addr = 0;

//   PrintChipSize();

   if (Algorithm == AMD29FXXX)
      {
      if (!EraseAm29Fxxx())   /* Chip erase */
         ErrorExit();
      }

   if (Algorithm == TEN_MS)
      msleep(0);             /* Calibrate delay routine */

 /*  getch(); */
   printf("Programming cartridge - |");
   while ( (!feof(fp)) &&
           (Addr < (ChipSize(Size)/8)) &&
           (Pass == 1) )
      {
      c = fgetc(fp);
      if (c != EOF)
         {
         b = c;
         Pass = ProgramByte(Addr, b);
         Addr++;

        switch (Addr & 0x3ff)
            {
            case 0:
               printf("\b/");
               break;
            case 0x100:
               printf("\b-");
               break;
            case 0x200:
               printf("\b\\");
               break;
            case 0x300:
               printf("\b|");
               break;
            }
         }
      }
   printf("\n");

   if (Pass == 0)
      {
      printf("Program error. Cartridge may be bad!\n");
      ErrorExit();
      }
   else
      printf("%lu bytes programmed.\n", Addr);
   LED_OFF;
   }

/* Erase Nintendo flash cart */

BYTE EraseNFlash (void)
   {
   BYTE Pass = 0;
   BYTE Val  = 0;
   int i;

   printf("Erasing Nintendo Type 1 (LH28F032) flash cartridge...");

   for (i=0; i<FlashBlocks; i++)
      {
      /* Set read memory mode */
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);

      /* Set read extended status register */
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x71);

      /* Set read block status register */
      ADDRESS_LOW(0x02); ADDRESS_HIGH(FLASH_ADRH);

      /* wait until queue is available */
      while (ReadNByte() & 0x8)
         {
         };

      /* Set memory bank ls byte */
      ADDRESS_LOW(0x00); ADDRESS_HIGH(0x20); WRITE_NFLASH(i*4);

      /* Set block erase/confirm mode */
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x20);
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xd0);
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xd0);

      /* Set read extended status register */
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x71);

      /* Set read global status register */
      ADDRESS_LOW(0x02); ADDRESS_HIGH(FLASH_ADRH);

      /* wait until block is ready */
      while (!(ReadNByte() & 0x80))
         {
         };
      /* Set clear status registers */
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x50);
      }
   Pass = 1;

   /* Set read memory mode */
   ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);

   if (Pass == 0)
      printf("Cartridge erase failed!\n");
   else
      printf("ok\n");

   return (Pass);
   }

/* Erase Nintendo flash cart #2 */

BYTE EraseNFlash2 (void)
   {
   BYTE Pass = 0;
   BYTE Val  = 0;
   int i;

   printf("Erasing Nintendo Type 2 (DA28F320) flash cartridge...");

   for (i=0; i<FlashBlocks2; i++)
      {
      /* Set read memory mode */
//      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);

      /* Set read extended status register */
//      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x71);

      /* Set read block status register */
//      ADDRESS_LOW(0x02); ADDRESS_HIGH(FLASH_ADRH);

      /* wait until queue is available */
//      while (ReadNByte() & 0x8)
//         {
//         };

      /* Set memory bank ls byte */
      ADDRESS_LOW(0x00); ADDRESS_HIGH(0x20); WRITE_NFLASH(i*8);

      /* Set block erase/confirm mode */
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x20);
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xd0);
//      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xd0);

//      /* Set read extended status register */
//      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x71);

      /* Set read global status register */
      ADDRESS_LOW(0x02); ADDRESS_HIGH(FLASH_ADRH);

      /* wait until block is ready */
      while (!(ReadNByte() & 0x80))
         {
         };
      /* Set clear status registers */
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x50);

//      printf("*");

      }
   Pass = 1;

   /* Set read memory mode */
   ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);

   if (Pass == 0)
      printf("Cartridge erase failed!\n");
   else
      printf("ok\n");

   return (Pass);
   }


void ReadWriteBlocks (FILE *fp)
   {
   int j = 256;
   int AdrReg,bank,c,i,h;
   LONG Addr = 0;

   /* Set Nintendo flash cart to memory read */
   ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);
   /*  Set bank ms byte */
   ADDRESS_LOW(0x00); ADDRESS_HIGH(0x30); WRITE_NFLASH(0x0);
   /*  Set bank ms byte */
   ADDRESS_LOW(0x00); ADDRESS_HIGH(0x20); WRITE_NFLASH(0x0);

   printf("Programming Nintendo flash cartridge...");


   while ( (j == 256) &&
           (Addr < (ChipSize(Size)/8)) )
      {

      if ((Addr & 0x7fff) == 0)
         printf(".",Addr);

      bank = (int)(( (Addr & 0x3fffff) >> 16)*4);
      ADDRESS_LOW(0x00); ADDRESS_HIGH(0x20); WRITE_NFLASH(bank);

      /* Set read extended status register */
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x71);

      /* Set read block status register */
      ADDRESS_LOW(0x04); ADDRESS_HIGH(FLASH_ADRH);

      /* wait until page buffer is available */
      while (ReadNByte() & 0x4)
         {
         };


      bank = (int)((Addr & 0x3fffff) >> 14);
      ADDRESS_LOW(0x00); ADDRESS_HIGH(0x20); WRITE_NFLASH(bank);

      /* Sequential load to page buffer */
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xe0);
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x00);

      i = 0;
      j = 0;
      while (i<256)
         {
         AdrReg = (int)(Addr & 0x3fff) + 0x4000;

         ADDRESS_LOW(AdrReg & 0x00ff);
         ADDRESS_HIGH(AdrReg >> 8);

         if (!feof(fp))
            {
            c= fgetc(fp);
            j++;
            }
         else
            c = 0xff;
         WRITE_NFLASH(c);
         Addr++;
         i++;
         }

      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);

      if (i>0)
         {
         bank = (int)(( (Addr & 0x3fffff) >> 16)*4);
         ADDRESS_LOW(0x00); ADDRESS_HIGH(0x20); WRITE_NFLASH(bank);

         /* Set read extended status register */
         ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x71);

         /* Set read block status register */
         ADDRESS_LOW(0x02); ADDRESS_HIGH(FLASH_ADRH);

         /* wait until queue is available */
         while (ReadNByte() & 0x8)
            {
            };

         bank = (int)(((Addr-256) & 0x3fffff) >> 14);
         ADDRESS_LOW(0x00); ADDRESS_HIGH(0x20); WRITE_NFLASH(bank);

         /* Write page buffer to flash */
         ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x0c);
         ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);

         AdrReg = (int)((Addr-256) & 0x3fff) + 0x4000;
         ADDRESS_LOW(AdrReg & 0x00ff);
         ADDRESS_HIGH(AdrReg >> 8);
         WRITE_NFLASH(0x00);


         bank = (int)(( ((Addr-256) & 0x3fffff) >> 16)*4);
         ADDRESS_LOW(0x00); ADDRESS_HIGH(0x20); WRITE_NFLASH(bank);

         /* Set read extended status register */
         ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x71);

         /* Set read block status register */
         ADDRESS_LOW(0x02); ADDRESS_HIGH(FLASH_ADRH);

         /* wait until block is ready */
         while (!(ReadNByte() & 0x80))
            {
            };

         /* Set clear status registers */
         ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x50);

         /* Set read memory mode */
         ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);

        }
      }
   }

void ReadWriteBlocks2 (FILE *fp)
   {
   int j = 32;
   int AdrReg,bank,c,i,h;
   LONG Addr = 0;
   int waiting;

   /* Set Nintendo flash cart to memory read */
   ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);
   /*  Set bank ms byte */
   ADDRESS_LOW(0x00); ADDRESS_HIGH(0x30); WRITE_NFLASH(0x0);
   /*  Set bank ls byte */
   ADDRESS_LOW(0x00); ADDRESS_HIGH(0x20); WRITE_NFLASH(0x0);

   printf("Programming Nintendo flash cartridge...");


   while ( (j == 32) &&
           (Addr < (ChipSize(Size)/8)) )
      {

      if ((Addr & 0x7fff) == 0)
         printf(".");

      bank = (int)(( (Addr & 0x3fffff) >> 17)*8);
      ADDRESS_LOW(0x00); ADDRESS_HIGH(0x20); WRITE_NFLASH(bank);

      waiting = 1;

      while (waiting)
         {
         /* block write */
         ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xe8);

         /* Set read block status register */
         ADDRESS_LOW(0x02); ADDRESS_HIGH(FLASH_ADRH);

         /* wait until queue is available */
         if (ReadNByte() & 0x80)
            waiting = 0;

         };

      bank = (int)((Addr & 0x3fffff) >> 14);
      ADDRESS_LOW(0x00); ADDRESS_HIGH(0x20); WRITE_NFLASH(bank);

      /* write 256 bytes */
      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);

//      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x00);

      i = 0;
      j = 0;
      while (i<32)
         {
         AdrReg = (int)(Addr & 0x3fff) + 0x4000;

         ADDRESS_LOW(AdrReg & 0x00ff);
         ADDRESS_HIGH(AdrReg >> 8);

         if (!feof(fp))
            {
            c= fgetc(fp);
            j++;
            }
         else
            c = 0xff;
         WRITE_NFLASH(c);
         Addr++;
         i++;
         }

      /* Start flash block program */
//      ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);

      if (i>0)
         {
     
         bank = (int)(( (Addr & 0x3fffff) >> 17)*8);
         ADDRESS_LOW(0x00); ADDRESS_HIGH(0x20); WRITE_NFLASH(bank);

         /* Write page buffer to flash */
         ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xd0);


         /* Set read block status register */
         ADDRESS_LOW(0x02); ADDRESS_HIGH(FLASH_ADRH);

         /* wait until block is ready */
         while (!(ReadNByte() & 0x80))
            {
            };

         /* Set clear status registers */
         ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x50);

         /* Set read memory mode */
         ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);

        }
      }
   }

void ProgramNFlash (FILE *fp)
   {
   (void) EraseNFlash();

//   printf("Programming Nintendo flash cartridge...");

   /* Read & Write blocks to flash */
   ReadWriteBlocks(fp);

   printf("\n");
   }

void ProgramNFlash2 (FILE *fp)
   {
   (void) EraseNFlash2();

//   printf("Programming Nintendo flash2 cartridge...");

   /* Read & Write blocks to flash */
   ReadWriteBlocks2(fp);

   printf("\n");
   }

void ProgramChip(FILE *fp)
   {
      int DeviceType;
      int Manufacturer = 0;

//   ADDRESS_LOW(0x00); ADDRESS_HIGH(0x40); WRITE_NFLASH(0xff);
   /*  Set bank ms byte */
//   ADDRESS_LOW(0x00); ADDRESS_HIGH(0x30); WRITE_NFLASH(0x0);
   /*  Set bank ms byte */
//   ADDRESS_LOW(0x00); ADDRESS_HIGH(0x20); WRITE_NFLASH(0x0);

   /*  Set read manufacturer mode */
   ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0x90);

   SetAddr(0x00);
   Manufacturer = ReadNByte();

   if (Manufacturer == 0x89)
      /* Intel da28f320j5 */
      SetAddr(0x02);
   else
      /* */
      SetAddr(0x01);

   DeviceType   = ReadNByte();

//   printf("Manufacturer = $%x, DeviceType = $%x\n", Manufacturer, DeviceType);

   /*  Set read memory mode */
   ADDRESS_LOW(0x00); ADDRESS_HIGH(FLASH_ADRH); WRITE_NFLASH(0xff);

   if ( (Manufacturer == 0xb0) && (DeviceType == 0x88) )
      ProgramNFlash(fp);
   else if
      ( (Manufacturer == 0x89) && (DeviceType == 0x14) )
      ProgramNFlash2(fp);
   else
      {
      /* Set MBC to 16Mbit ROM & 8KByte RAM mode */
      ADDRESS_LOW(0x00); ADDRESS_HIGH(0x60); WRITE_NFLASH(ROM16_RAM8);

      /* Set high memory bank select to 0x00 */
      ADDRESS_LOW(0x00); ADDRESS_HIGH(0x40); WRITE_NFLASH(0);

      ProgramAMD(fp);
      }
   }

void main(int argc, char **argv)
{
	int arg, fh;
	BYTE Base;
	FILE *fp;
 	char fname[20];
	unsigned char header[0x50];
	double Fsize;

	if(argc < 2) {
        usage(argv[0]);
		exit(1);
	}

    Algorithm = AMD29FXXX;  /* default to Am29Fxxx programming algorithm */
    Size = 8;               /* default to 4mbit chip */

    LED_OFF;
	wait_delay = 10;
	init_port(1);

   /* Select default MBC settings */
   select_mbc_defaults();

	for(arg = 1; arg < argc; arg++) {
		if(argv[arg][0] != '-') {
            usage(argv[0]);
			exit(1);
		}
		switch(argv[arg][1]) {
            case 'm':
            case 'M':
                    Algorithm = atoi(argv[++arg]);
                    if (Algorithm > 2) {
                    	printf("Programming algorithm selection invalid!\n");
                       	exit(1);
                    }
                    break;
            case 'd':
            case 'D':
                    if (argv[++arg] == NULL)
                       Base = 1;
                    else
                       Base = (BYTE)(atoi(argv[arg]));
    //                Base = 0; /////////
                    printf("Base address : %hx\n",Base*256);
                    dump(Base);
                    break;
            case 'p':
            case 'P':
                   /* add extension .GB if none present */
         			strcpy(fname, argv[++arg]);
         			if (strchr(fname, '.') == NULL)
            		strcat(fname, ".gb");
#ifdef Smallprogram
               		if ((fh = _open( fname, _O_RDONLY))  == -1 ) {
                       	printf("Error opening file %s\n", fname);
                       	exit(1);
                    }
   				    if (_filelength( fh ) <= 2048L) {
   				       Size = 0; }
   				    else {
   					   Fsize = (log(_filelength( fh )/2048)/log(2));
                       FlashBlocks = _filelength( fh ) / 65536;
                       if (_filelength(fh) != (FlashBlocks*65536))
                          FlashBlocks++;
                       FlashBlocks2 = _filelength( fh ) / 131072;
                       if (_filelength(fh) != (FlashBlocks2*131072))
                          FlashBlocks2++;
           

   					   printf("File size = %.0f\n",Fsize);
//                       printf("64k blocks = %d\n",FlashBlocks);

                       Size = (unsigned char)Fsize;
   					   _close( fh ); }
#endif
				  	if ((fp = fopen(fname, "rb")) == NULL) {
                       	printf("Error opening file %s\n", fname);
                       	exit(1);
                    }
                    ProgramChip(fp);
                    fclose(fp);
                    break;
#ifndef Smallprogram
            case 'n':
            case 'N':
                    Size = atoi(argv[++arg]);
                    if (Size>10) {
                      	printf("Chip size selection invalid!\n");
                       	exit(1);
                    }
                    break;
#endif
            case 'v':
            case 'V':
	           		/* add extension .GB if none present */
         			strcpy(fname, argv[++arg]);
         			if (strchr(fname, '.') == NULL)
            		strcat(fname, ".gb");
#ifdef Smallprogram
             		if ((fh = _open( fname, _O_RDONLY))  == -1 ) {
                       	printf("Error opening file %s\n", fname);
                       	exit(1);
                    }
   				    if (_filelength( fh ) <= 2048L) {
   				       Size = 0; }
   				    else {
   				       Fsize = (log(_filelength( fh )/2048)/log(2));
   					   printf("File size = %.0f\n",Fsize);
   					   Size = (unsigned char)Fsize;
   					   _close( fh ); }
#endif
                    if ((fp = fopen(fname, "rb")) == NULL) {
                   		printf("Error opening file %s\n", fname);
                       	exit(1);
                    }
                    VerifyChip(fp);
                    fclose(fp);
                    break;
			case 'l':
			case 'L':
					init_port(atoi(argv[++arg]));
			    	break;
			case 'w':
			case 'W':
					wait_delay = atoi(argv[++arg]);
					break;
			case 't':
			case 'T':
					test();
					break;
			case 'a':
			case 'A':
					read_header(header);
					break;
			case 's':
			case 'S':
                    /* add extension .GB if none present */
         			strcpy(fname, argv[++arg]);
         			if (strchr(fname, '.') == NULL)
            		strcat(fname, ".gb");

					if((fp = fopen(fname, "wb")) == NULL) {
						printf("Error opening file %s\n", fname);
						exit(1);
					}
					read_header(header);
					read_data(fp, mbc[header[0x47]], rom[header[0x48]]);
					fclose(fp);
					break;
			case 'b':
			case 'B':
                    /* add extension .SAV if none present */
         			strcpy(fname, argv[++arg]);
         			if (strchr(fname, '.') == NULL)
            		strcat(fname, ".sav");

					if((fp = fopen(fname, "wb")) == NULL) {
            			printf("Error opening file %s\n", fname);
						exit(1);
					}
					read_header(header);
					read_sram(fp, mbc[header[0x47]], ram[header[0x49]]);
					fclose(fp);
					break;
			case 'r':
			case 'R':
                    /* add extension .SAV if none present */
         			strcpy(fname, argv[++arg]);
         			if (strchr(fname, '.') == NULL)
            		strcat(fname, ".sav");

       				if((fp = fopen(fname, "rb")) == NULL) {
						printf("Error opening file %s\n", fname);
						exit(1);
					}
   					read_header(header);
					write_sram(fp, mbc[header[0x47]], ram[header[0x49]]);
					fclose(fp);
					break;
			default:
                    usage(argv[0]);
                    LED_OFF;
					exit(1);
		}
	}
    LED_OFF;
	exit(0);
}


