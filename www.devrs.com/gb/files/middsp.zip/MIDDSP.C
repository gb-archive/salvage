/*
 *  MIDI file display
 *        by Jeff Frohwein
 * Last Edit: 7-Mar-98
 *
 * Compiled with Microsoft C/C++ V6.0
 *
 * V1.0 - 5-Oct-97 Initial release.
 * V1.1 - 7-Mar-98 Added support for displaying "Running Status" messages.
 *
 */

#include <stdio.h>
#include <string.h>

/* required to keep LINT happy */
#define FPrintF (void) fprintf
#define PrintF (void) printf
#define StrCat (void) strcat
#define StrCpy (void) strcpy

/* Global Variables */
   FILE *fp;

void exit (int status);
int GetCh (FILE *f);
void PrintNote (int i);

int count;
int tsize;
int FilePos;
int MidiFormat;
int NumTracks;
int PPQN;
int ShortestNote;
int DeltaInc;
int tpos;
int RunningStatus = 0;

void OpenFile (int argc, char **argv, int arg)
   {
   char fname[20];

   fname[0] = 0x0;
   if (argc-arg > 1)
      /* Get input filename */
      StrCpy(fname, argv[arg+1]);
   else
      /* If no name, print usage info */
      {
      usage();
      exit(1);
      }

   /* Add default extension to filename if left off */
   if (strchr(fname, '.') == NULL)
      StrCat(fname, ".mid");

   /* If file not found, print error & exit */
   if ((fp = fopen(fname, "r+b")) == NULL)
      {
      PrintF("Error opening input file '%s'.\n", fname);
      exit(1);
      }
   }

void CloseFile (void)
   {
   fclose(fp);
   }

void ErrorExit (void)
   {
   fclose(fp);
   exit(1);
   }

long BlockLen (void)
   {
   int i;
   long total = 0;

   for (i=0; i<4; i++)
      {
      total *=256;
      total += GetCh(fp);
      }
   return (total);
   }

long GetDeltaTime (void)
   {
   long value;
   int c;

   if ( (value = GetCh(fp)) & 0x80 )
      {
      value &=0x7f;
      do
         {
         value = (value << 7) + ((c = GetCh(fp)) & 0x7f);
         }
      while (c & 0x80);
      }
   return (value);
   }

void PrintEventFF (void)
   {
   int i,j,k,m,y,denom;
   long dt,x,z;

   i = GetCh(fp);
   switch (i)
      {
      case 0x00 :
         i=GetCh(fp);
         PrintF("Sequence Number");
         if (i!=0)
            {
            i=GetCh(fp);
            PrintF(" = %d,%d", i, GetCh(fp));
            }
         PrintF("\n");
         break;
      case 0x01 :
         x = GetDeltaTime();
         PrintF("Text='");
         for (z=0; z<x; z++)
            PrintF("%c", GetCh(fp));
         PrintF("'\n");
         break;
      case 0x02 :
         x = GetDeltaTime();
         PrintF("Copyright='");
         for (z=0; z<x; z++)
            PrintF("%c", GetCh(fp));
         PrintF("'\n");
         break;
      case 0x03 :
         x = GetDeltaTime();
         PrintF("Sequence/Track Name='");
         for (z=0; z<x; z++)
            PrintF("%c", GetCh(fp));
         PrintF("'\n");
         break;
      case 0x04 :
         x = GetDeltaTime();
         PrintF("Instrument='");
         for (z=0; z<x; z++)
            PrintF("%c", GetCh(fp));
         PrintF("'\n");
         break;
      case 0x05 :
         x = GetDeltaTime();
         PrintF("Lyric='");
         for (z=0; z<x; z++)
            PrintF("%c", GetCh(fp));
         PrintF("'\n");
         break;
      case 0x06 :
         x = GetDeltaTime();
         PrintF("Marker='");
         for (z=0; z<x; z++)
            PrintF("%c", GetCh(fp));
         PrintF("'\n");
         break;
      case 0x07 :
         x = GetDeltaTime();
         PrintF("Cue Point='");
         for (z=0; z<x; z++)
            PrintF("%c", GetCh(fp));
         PrintF("'\n");
         break;
      case 0x20 :
         i=GetCh(fp);
         i=GetCh(fp);
         PrintF("MIDI Channel=%d\n", i);
         break;
      case 0x21 :
         i=GetCh(fp);
         i=GetCh(fp);
         PrintF("MIDI Port=%d\n", i);
         break;
      case 0x2f :
         i=GetCh(fp);
         PrintF("End of Track\n");
         break;
      case 0x51 :
         i=GetCh(fp);
         x=GetCh(fp);
         j=GetCh(fp);
         k=GetCh(fp);
         z=(x<<16)+(j<<8)+k;
         PrintF("Tempo : uSec per Quarter Note=%ld\n", z);
         break;
      case 0x54 :
         i=GetCh(fp);
         i=GetCh(fp);
         i=GetCh(fp);
         i=GetCh(fp);
         i=GetCh(fp);
         i=GetCh(fp);
         PrintF("SMPTE Offset\n");
         break;
      case 0x58 :
         i=GetCh(fp);
         i=GetCh(fp);
         j=GetCh(fp);
         k=GetCh(fp);
         m=GetCh(fp);
         denom = 1;
         for (y=0; y<j; y++)
            denom *=2;
         PrintF("Time Signature %d/%d : Value1=%d : Value2=%d\n", i, denom, k, m);
         break;
      case 0x59 :
         i=GetCh(fp);
         i=GetCh(fp);
         j=GetCh(fp);
         if (i>127) i=i-256;
         PrintF("Key Signature : sf=%d,mi=%d\n", i,j);
         break;
      case 0x7f :
         x = GetDeltaTime();
         PrintF("Proprietary Event : length = %ld\n", x);
         for (z=0; z<x; z++)
            (void) GetCh(fp);
         break;
      default:
         PrintF("Unknown event - FF %X\n", i);
         dt = GetDeltaTime ();
         for (z=0; z<dt; z++)
            (void) GetCh(fp);
         break;
      }
   }

void PrintEvent (void)
   {
   int i,j;
   long k,bl;

   PrintF(" ");
   i = GetCh(fp);
   if (i < 0x80)
      {
      j = i;
      i = RunningStatus;
      }
   else
      {
      RunningStatus = i;
      if(i < 0xf0)
         {
         j = GetCh(fp);
         }
      }

   switch (i & 0xf0)
      {
      case 0x80 :
         PrintF("Note Off : Chnl=%d : Note=%d : Vel=%d\n",(i&0xf),j,GetCh(fp));
         break;
      case 0x90 :
         PrintF("Note On : Chnl=%d : Note=%d : Vel=%d\n",(i&0xf),j,GetCh(fp));
         break;
      case 0xa0 :
         PrintF("AfterTouch : Chnl=%d : Note=%d : Pres=%d\n",(i&0xf),j,GetCh(fp));
         break;
      case 0xb0 :
         PrintF("Ctrl Change : Chnl=%d : Ctrl=%d : Value=%d\n",(i&0xf),j,GetCh(fp));
         break;
      case 0xc0 :
         PrintF("Prgm Change : Chnl=%d : Value=%d\n",(i&0xf),j);
         break;
      case 0xd0 :
         PrintF("Chnl Pressure : Chnl=%d : Value=%d\n",(i&0xf),j);
         break;
      case 0xe0 :
         PrintF("Pitch Wheel : Chnl=%d : Value=%d\n",(i&0xf),((GetCh(fp)<<7)+j));
         break;
      case 0xf0 :
         switch(i & 0xf)
            {
            case 0 :
               bl = BlockLen();
               PrintF("SYSEX Message : length = %ld\n", bl);
               for (k=0; k<bl; k++)
                  (void) GetCh(fp);
               break;
            case 1 :
               i=GetCh(fp);
               PrintF("MTC Quarter Frame Message=%d\n", i);
               break;
            case 2 :
               j = GetCh(fp);
               PrintF("Song Position Pointer=%d\n",((GetCh(fp)<<7)+j));
               break;
            case 3 :
               i=GetCh(fp);
               PrintF("Song Select=%d\n", i);
               break;
            case 6 :
               PrintF("Tune Request\n");
               break;
            case 8 :
               PrintF("MIDI Clock\n");
               break;
            case 10 :
               PrintF("MIDI Start\n");
               break;
            case 11 :
               PrintF("MIDI Continue\n");
               break;
            case 12 :
               PrintF("MIDI Stop\n");
               break;
            case 14 :
               PrintF("Active Sense\n");
               break;
            case 15 :
               PrintEventFF();
               break;
            default:
               PrintF("Error, unknown event - %X\n", i);
            }
         break;
      default :
         PrintF("Error, unknown event - %X\n", i);
         break;
      }
   }

void PrintTrackInfo (long len)
   {
   int c;
   long i = 0;
   long dt;

   tpos = 0;
   while (tpos < len)
      {
      dt = GetDeltaTime();
      PrintF(" Delta Time = %ld\n", dt);
      PrintEvent();
      }
   PrintF("\n");
   }

void ShowData (void)
   {
   char a[4];
   int c,i,j,tn;
   long bl,k;

   /* Ignore MThd & 0 0 0 6 */
   for(i=0; i<4; i++)
      {
      c=GetCh(fp);
      PrintF("%c",c);
      }
   PrintF(" : length = %ld\n", BlockLen());

   MidiFormat = GetCh(fp) * 256;
   MidiFormat += GetCh(fp);

   PrintF(" Midi Format = %d\n", MidiFormat);

   NumTracks = GetCh(fp) * 256;
   NumTracks += GetCh(fp);

   PrintF(" Number of Tracks = %d\n", NumTracks);

   PPQN = GetCh(fp) * 256;
   PPQN += GetCh(fp);

   PrintF(" Pulses Per Quarter Note (PPQN) = %d\n", PPQN);

   PrintF("\n");

//   NumTracks = 1;

   for (tn=0; tn<NumTracks; tn++)
      {
      /* Display next chunk header */
      for(i=0; i<4; i++)
         {
         a[i] = GetCh(fp);
         PrintF("%c", a[i]);
         }
      bl = BlockLen();
      PrintF(" : length = %ld\n", bl);

      /* If nonstandard chunk of data then ignore */

      if (!( (a[0] == 0x4d) &&
             (a[1] == 0x54) &&
             (a[2] == 0x72) &&
             (a[3] == 0x6b) ) )
         {
         long i;

         PrintF(" Nonstandard chunk\n");

         for (k=0; k<bl; k++)
            (void) GetCh(fp);

         /* Ignore next chunk header */
         for(i=0; i<4; i++)
            PrintF("%c", GetCh(fp));
         bl = BlockLen();
         PrintF(" : length = %ld\n", bl);
         }

      /* Ignore track info*/
      PrintTrackInfo (bl);
      }
   }

void PrintNote (int i)
   {
   int j=0;
   while (i>11)
      {
      i=i-12;
      j++;
      }
   switch (i)
      {
      case 0:  PrintF("C_"); break;
      case 1:  PrintF("C#"); break;
      case 2:  PrintF("D_"); break;
      case 3:  PrintF("D#"); break;
      case 4:  PrintF("E_"); break;
      case 5:  PrintF("F_"); break;
      case 6:  PrintF("F#"); break;
      case 7:  PrintF("G_"); break;
      case 8:  PrintF("G#"); break;
      case 9:  PrintF("A_"); break;
      case 10: PrintF("A#"); break;
      case 11: PrintF("B_"); break;
      }
   PrintF("%c", j+48);
   }

int GetTime (void)
   {
   int i,j;
   i=GetCh(fp);
   if (i>0x7f)
      {
      j = GetCh(fp);
      if (j>0x7f)
         {
         PrintF("Number too large!\n");
         ErrorExit();
         }
      i = ((i & 0x7f) << 7) + j;
      }
   return(i);
   }

int GetCh (FILE *f)
   {
   tpos++;
   return(fgetc(f));
   }

void Usage (void)
   {
   PrintF(" Usage: middsp infile[.mid]\n");
   PrintF("\n");
   }

void main(int argc, char **argv)
   {
   int arg;
   int argp = 0;

   ShortestNote = 2;

   PrintF("MIDI file display V1.1, by Jeff Frohwein, 7-Mar-98\n\n");

   for (arg = 1; arg < argc; arg++)
      {

      /* process command args */
      if (argv[arg][0] == '-')
         {
         argp++;
         switch (argv[arg][1])
            {
            case 'n':
            case 'N':
               /* Get shortest note */
               ShortestNote = atoi(argv[++arg]);
               argp++;
               break;
            default:
               Usage();
               exit(1);
            }
         }
      }

   FilePos = 0;
   count = 0;
   OpenFile(argc, argv, argp);
//   SkipHeader();
   ShowData();
   CloseFile();
   PrintF("Done.\n");

   exit(0);
   }
