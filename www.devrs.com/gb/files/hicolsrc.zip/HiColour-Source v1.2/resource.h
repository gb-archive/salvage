//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by hicolour.rc
//
#define IDD_DIALOG1                     103
#define IDC_OUTPUT                      1000
#define IDC_CONVERT                     1001
#define IDC_ORIGINAL                    1002
#define IDC_FILE                        1003
#define IDC_SAVE                        1004
#define IDC_EXIT                        1005
#define IDC_RADIO1                      1006
#define IDC_VIEW_ATTRIBS                1006
#define IDC_RADIO2                      1007
#define IDC_RADIO3                      1008
#define IDC_SAVE2                       1009
#define IDC_FORMAT                      1010
#define IDC_PROGRESS                    1011
#define IDC_EXPORT                      1012
#define IDC_COMBO1                      1021
#define IDC_CONVERTLEFT                 1021
#define IDC_CONVERTRIGHT                1022
#define IDC_BUTTON1                     1023
#define IDC_INFO                        1023
#define IDC_SLIDER1                     1036
#define IDC_SLIDER2                     1037
#define IDC_SLIDER3                     1038
#define IDC_RADIO5                      1043
#define IDC_RADIO6                      1044
#define IDC_CHECK1                      1045
#define IDC_TRUE_GBC                    1045
#define IDC_CONVERTTYPE                 1046
#define IDM_FILE_OPEN                   40001
#define IDM_SHOW_NORMAL                 40002
#define IDM_SHOW_CENTER                 40003
#define IDM_SHOW_STRETCH                40004
#define IDM_SHOW_ISOSTRETCH             40005
#define IDM_FILE_PRINT                  40006
#define IDM_EDIT_COPY                   40007
#define IDM_EDIT_CUT                    40008
#define IDM_EDIT_DELETE                 40009
#define IDM_FILE_SAVE                   40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1047
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
