

#ifndef __defines_h__
#define __defines_h__


#define u8	unsigned char
#define u16	unsigned short
#define u32 unsigned int
#define s8	signed char
#define s16	signed short
#define	s32	signed int

#endif
