
/* Return a interleaved subset of data from an input file */

/* Compiled with DJGPP for DOS & GCC for Linux */

// v1.0  - Original version
// v1.1  - Added support for stdin/stdout streams

// To compile on DOS use the makefile.
//
// To compile on *nix do the following:
//   cc b2x.c -o b2x

#include <stdio.h>
#include <string.h>
//#include <conio.h>

#ifdef __MSDOS__
#include <io.h>
#include <fcntl.h>
#endif

// Casting couch
long strtol(const char *nptr, char **endptr, int base);

// Main program
int main(int argc, char **argv)
   {
//   FILE *fpi, *fpo;
   char c1; //c2;
//   char fname[20];
   long start = 0;
   long length = 0;
   long geton = 0;
   long getoff = 0;
   long datacount = 0;
   long setcount = 0;
   long position = 0;
   char *stopstring;

#ifdef __MSDOS__
   // Needed by DOS to force binary STDIN & STDOUT modes
   (void) setmode(fileno(stdin), O_BINARY);
   (void) setmode(fileno(stdout), O_BINARY);
#endif

   /* Get start position from command line */

   if (argc > 1)
      {
      if (argv[1][0] == '$')
         {
         start = strtol(argv[1]+1, &stopstring, 16);
         }
      else
         {
         start = strtol(argv[1], &stopstring, 10);
         }

      fprintf(stderr, "Start offset=%ld($%lx) ", start, start);
      }

   /* Get length for interleave */

   if (argc > 2)
      {
      if (argv[2][0] == '$')
         {
         length = strtol(argv[2]+1, &stopstring, 16);
         }
      else
         {
         length = strtol(argv[2], &stopstring, 10);
         }
      if (length == 0)
         {
         fprintf(stderr, ": Length = 0(Remainder of input file) ");
         }
      else
         {
         fprintf(stderr, ": Length=%ld($%lx) ", length, length);
         }
      }

   /* Get length for get bytes  */

   if (argc > 3)
      {
      if (argv[3][0] == '$')
         {
         geton = strtol(argv[3]+1, &stopstring, 16);
         }
      else
         {
         geton = strtol(argv[3], &stopstring, 10);
         }

      if (geton == 0)
         {
         fprintf(stderr, "\nError: Parameter 3 must be non-zero.\n");
         exit(1);
         }
      else
         fprintf(stderr, ": get=%ld($%lx) ", geton, geton);
      }

   /* Get length for no get bytes  */

   if (argc > 4)
      {
      if (argv[4][0] == '$')
         {
         getoff = strtol(argv[4]+1, &stopstring, 16);
         }
      else
         {
         getoff = strtol(argv[4], &stopstring, 10);
         }

      if (getoff == 0)
         {
         fprintf(stderr, "\nError: Parameter 4 must be non-zero.\n");
         exit(1);
         }
      else
         fprintf(stderr, ": no get=%ld($%lx) ", getoff, getoff);
      }

   fprintf(stderr, "\n");

   if (argc != 5)
      {
      fprintf(stderr, "** ileave v1.1 **, by jeff@devrs.com, 00-Sept-15\n");
      fprintf(stderr, "  - Return a range of interleaved data from an input file.\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "Usage: subset start# length# get# noget# < in_file > out_file\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "       start  = starting location offset (0 = first byte of input file)\n");
      fprintf(stderr, "       length = number of interleaves to get (0 = remainder of input file)\n");
      fprintf(stderr, "       get    = number of bytes to get\n");
      fprintf(stderr, "       noget  = number of bytes to skip over\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "       [ If number starts with $ it's hex, otherwise decimal. ]\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "Description:\n");
      fprintf(stderr, "\n");
      fprintf(stderr, " This utility allows you to return a subset of data from an input\n");
      fprintf(stderr, "file starting at an offset [first parameter]. You can then get some\n");
      fprintf(stderr, "bytes [parameter 3] and skip over some bytes [parameter 4]. After\n");
      fprintf(stderr, "skipping over bytes you can then get more bytes. The number of times\n");
      fprintf(stderr, "that getting bytes/skipping bytes occurs is determined by the length\n");
      fprintf(stderr, "[parameter 2].\n");

      exit(1);
      }

   /* Skip over any leading unwanted bytes */

   while ( (feof(stdin) == 0) &&
           (position != start) )
      {
      (void) fgetc(stdin);
      position++;
      }

   /* Copy the desired get bytes */

   c1 = fgetc(stdin);

   while ( (feof(stdin) == 0) &&
           ((setcount < length) || (length == 0)) )
      {
      datacount = 0;

      while ( (feof(stdin) == 0) &&
              (datacount < geton) )
         {
         fputc(c1, stdout);
         datacount++;
         c1 = fgetc(stdin);
         }

      datacount = 0;

      while ( (feof(stdin) == 0) &&
              (datacount < getoff) )
         {
         c1 = fgetc(stdin);
         datacount++;
         }

      setcount++;
      }

   exit(0);
   }