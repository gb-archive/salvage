/* lklex.c */

/*
 * (C) Copyright 1989,1990
 * All Rights Reserved
 *
 * Alan R. Baldwin
 * 721 Berkeley St.
 * Kent, Ohio  44240
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "aslink.h"

VOID getid(char *id, register int c)
{
	register char *p;

	if (c < 0) {
		c = getnb();
	}
	p = id;
	do {
		if (p < &id[NCPS])
			*p++ = c;
	} while (ctype[c=get()] & (LETTER|DIGIT));
	unget(c);
	while (p < &id[NCPS])
		*p++ = 0;
}

char getnb()
{
	register c;

	while ((c=get())==' ' || c=='\t')
		;
	return (c);
}

VOID skip(register int c)
{
	if (c < 0)
		c = getnb();
	while (ctype[c=get()] & (LETTER|DIGIT)) { ; }
	unget(c);
}

char get()
{
	register c;

	if ((c = *ip) != 0)
		++ip;
	return (c);
}

VOID unget(register int c)
{
	if (c != 0)
		--ip;
}

int getmap(register int d)
{
	register c, n, v;

	if ((c = get()) == '\0')
		return (-1);
	if (c == d)
		return (-1);
	if (c == '\\') {
		c = get();
		switch (c) {

		case 'b':
			c = '\b';
			break;

		case 'f':
			c = '\f';
			break;

		case 'n':
			c = '\n';
			break;

		case 'r':
			c = '\r';
			break;

		case 't':
			c = '\t';
			break;

		case '0':
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
			n = 0;
			v = 0;
			while (++n<=3 && c>='0' && c<='7') {
				v = (v<<3) + c - '0';
				c = get();
			}
			unget(c);
			c = v;
			break;
		}
	}
	return (c);
}

char *fgetstring(char *s, int n, FILE *stream)
{
register int c, i = 0;

	if(feof(stream))
		return(NULL);
	while(i < n) {
		c = fgetc(stream);
		if(c  == EOF && i == 0)
			return(NULL);
		if(c  == EOF || c  == '\n' || c  == '\r') {
			s[i] = '\0';
			return(s);
		}
		s[i++] = c;
	}
	s[n-1] = '\0';
	return(s);
}

int getline()
{
	register i, ftype;
	register char *fid;

loop:
	if (sfp == NULL || fgetstring(ib, sizeof ib, sfp) == NULL) {
		if (sfp != NULL)
			fclose(sfp);
		if (cfp == NULL) {
			cfp = filep;
		} else {
			cfp = cfp->f_flp;
		}
		if (cfp) {
			ftype = cfp->f_type;
			fid = cfp->f_idp;
			if (ftype == F_REL) {
				sfp = afile(fid, "rel", 0);
			} else {
				fprintf(stderr, "Invalid file type\n");
				exit(1);
			}
			goto loop;
		} else {
			filep = NULL;
			return(0);
		}
	}
	i = strlen(ib) - 1;
	if (ib[i] == '\n')
		ib[i] = 0;
	return (1);
}

int more()
{
	register c;

	c = getnb();
	unget(c);
	return( (c == '\0' || c == ';') ? 0 : 1 );
}

char endline()
{
	register c;

	c = getnb();
	return( (c == '\0' || c == ';') ? 0 : c );
}

