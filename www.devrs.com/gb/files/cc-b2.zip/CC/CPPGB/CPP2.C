/*
 *				C P P 2 . C
 *
 *			   Process #control lines
 *
 * Edit history
 * 13-Nov-84	MM	Split from cpp1.c
 */

#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<ctype.h>
#include	"cppdef.h"
#include	"cpp.h"

/*
 * Generate (by hand-inspection) a set of unique values for each control
 * operator.  Note that this is not guaranteed to work for non-Ascii
 * machines.  CPP won't compile if there are hash conflicts.
 */

#define	L_asm		('a' + 's' + 'm')
#define	L_assert	('a' + 's' + 's' + 'e' + 'r' + 't')
#define	L_define	('d' + 'e' + 'f' + 'i' + 'n' + 'e')
#define	L_easm		('e' + 'a' + 's' + 'm')
#define	L_elif		('e' + 'l' + 'i' + 'f')
#define	L_else		('e' + 'l' + 's' + 'e')
#define	L_endif		('e' + 'n' + 'd' + 'i' + 'f')
#define	L_if		('i' + 'f')
#define	L_ifdef		('i' + 'f' + 'd' + 'e' + 'f')
#define	L_ifndef	('i' + 'f' + 'n' + 'd' + 'e' + 'f')
#define	L_include	('i' + 'n' + 'c' + 'l' + 'u' + 'd' + 'e')
#define	L_line		('l' + 'i' + 'n' + 'e')
#define	L_nogood	(EOS)					/* To catch #i	*/
#define	L_pragma	('p' + 'r' + 'a' + 'g' + 'm' + 'a')
#define L_undef		('u' + 'n' + 'd' + 'e' + 'f')
#if DEBUG
#define	L_debug		('d' + 'e' + 'b' + 'u' + 'g')	/* #debug		*/
#define	L_nodebug	('n' + 'o' + 'd' + 'e' + 'b' + 'u' + 'g')	/* #nodebug		*/
#endif

int control(int counter)
/*
 * Process #control lines.  Simple commands are processed inline,
 * while complex commands have their own subroutines.
 *
 * The counter is used to force out a newline before #line, and
 * #pragma commands.  This prevents these commands from ending up at
 * the end of the previous line if cpp is invoked with the -C option.
 */
{
	register int		c;
	register char		*tp;
	register int		hash;
	char			*ep;

	c = skipws();
	if (c == '\n' || c == '\r' || c == EOF_CHAR)
	    return (counter + 1);
	if (!isdigit(c))
	    scanid(c);			/* Get #word to token[]		*/
	else {
	    unget();			/* Hack -- allow #123 as a	*/
	    strcpy(token, "line");	/* synonym for #line 123	*/
	}
	if(token[1] == EOS)
		hash = L_nogood;
	else {
		hash = c = 0;
		while(token[c] != EOS)
			hash += token[c++];
	}

	switch (hash) {
	case L_assert:	tp = "assert";		break;
	case L_define:	tp = "define";		break;
	case L_elif:	tp = "elif";		break;
	case L_else:	tp = "else";		break;
	case L_endif:	tp = "endif";		break;
	case L_if:	tp = "if";		break;
	case L_ifdef:	tp = "ifdef";		break;
	case L_ifndef:	tp = "ifndef";		break;
	case L_include:	tp = "include";		break;
	case L_line:	tp = "line";		break;
	case L_pragma:	tp = "pragma";		break;
	case L_asm:	tp = "asm";		break;
	case L_easm:	tp = "easm";		break;
	case L_undef:	tp = "undef";		break;
#if DEBUG
	case L_debug:	tp = "debug";		break;
	case L_nodebug:	tp = "nodebug";		break;
#endif
	default:	hash = L_nogood;
	case L_nogood:	tp = "";		break;
	}
	if (!streq(tp, token))
	    hash = L_nogood;
	/*
	 * hash is set to a unique value corresponding to the
	 * control keyword (or L_nogood if we think it's nonsense).
	 */
	if (infile->fp == NULL)
	    cwarn("Control line \"%s\" within macro expansion", token);
	if (!compiling) {			/* Not compiling now	*/
	    switch (hash) {
	    case L_if:				/* These can't turn	*/
	    case L_ifdef:			/*  compilation on, but	*/
	    case L_ifndef:			/*   we must nest #if's	*/
		if (++ifptr >= &ifstack[BLK_NEST])
		    goto if_nest_err;
		*ifptr = 0;			/* !WAS_COMPILING	*/
	    case L_line:			/* Many			*/
	    /*
	     * Are pragma's always processed?
	     */
	    case L_asm:
	    case L_easm:
	    case L_pragma:			/*  options		*/
	    case L_include:			/*   are uninteresting	*/
	    case L_define:			/*    if we		*/
	    case L_undef:			/*     aren't		*/
	    case L_assert:			/*      compiling.	*/
dump_line:	skipnl();			/* Ignore rest of line	*/
		return (counter + 1);
	    }
	}
	/*
	 * Make sure that #line and #pragma are output on a fresh line.
	 */
	if (counter > 0 && (hash == L_line || hash == L_pragma ||
		hash == L_asm)) {
	    putchar('\n');
	    counter--;
	}
	if(skipping && hash != L_easm) {
	  while ((c = get()) != '\n' && c != '\r' && c != EOF_CHAR)
	    cput(c);
	  unget();
	  return (counter + 1);
	}
	switch (hash) {
	case L_line:
	    /*
	     * Parse the line to update the line number and "progname"
	     * field and line number for the next input line.
	     * Set wrongline to force it out later.
	     */
	    c = skipws();
	    workp = work;			/* Save name in work	*/
	    while (c != '\n' && c != '\r' && c != EOF_CHAR) {
		save(c);
		c = get();
	    }
	    unget();
	    save(EOS);
	    /*
	     * Split #line argument into <line-number> and <name>
	     * We subtract 1 as we want the number of the next line.
	     */
	    line = atoi(work) - 1;		/* Reset line number	*/
	    for (tp = work; isdigit(*tp) || type[(int)*tp] == SPA; tp++)
		;				/* Skip over digits	*/
	    if (*tp != EOS) {			/* Got a filename, so:	*/
		if (*tp == '"' && (ep = strrchr(tp + 1, '"')) != NULL) {
		    tp++;			/* Skip over left quote	*/
		    *ep = EOS;			/* And ignore right one	*/
		}
		if (infile->progname != NULL)	/* Give up the old name	*/
		    free(infile->progname);	/* if it's allocated.	*/
	        infile->progname = savestring(tp);
	    }
	    wrongline = TRUE;			/* Force output later	*/
	    break;

	case L_include:
	    doinclude();
	    break;

	case L_define:
	    dodefine();
	    break;

	case L_undef:
	    doundef();
	    break;

	case L_else:
	    if (ifptr == &ifstack[0])
		goto nest_err;
	    else if ((*ifptr & ELSE_SEEN) != 0)
		goto else_seen_err;
	    *ifptr |= ELSE_SEEN;
	    if ((*ifptr & WAS_COMPILING) != 0) {
		if (compiling || (*ifptr & TRUE_SEEN) != 0)
		    compiling = FALSE;
		else {
		    compiling = TRUE;
		}
	    }
	    break;

	case L_elif:
	    if (ifptr == &ifstack[0])
		goto nest_err;
	    else if ((*ifptr & ELSE_SEEN) != 0) {
else_seen_err:	cerror("#%s may not follow #else", token);
		goto dump_line;
	    }
	    if ((*ifptr & (WAS_COMPILING | TRUE_SEEN)) != WAS_COMPILING) {
		compiling = FALSE;		/* Done compiling stuff	*/
		goto dump_line;			/* Skip this clause	*/
	    }
	    doif(L_if);
	    break;

	case L_if:
	case L_ifdef:
	case L_ifndef:
	    if (++ifptr >= &ifstack[BLK_NEST])
if_nest_err:	cfatal("Too many nested #%s statements", token);
	    *ifptr = WAS_COMPILING;
	    doif(hash);
	    break;

	case L_endif:
	    if (ifptr == &ifstack[0]) {
nest_err:	cerror("#%s must be in an #if", token);
		goto dump_line;
	    }
	    if (!compiling && (*ifptr & WAS_COMPILING) != 0)
		wrongline = TRUE;
	    compiling = ((*ifptr & WAS_COMPILING) != 0);
	    --ifptr;
	    break;

	case L_assert:
	    if (eval() == 0)
		cerror("Preprocessor assertion failure", NULLST);
	    break;

	case L_pragma:
	    /*
	     * #pragma is provided to pass "options" to later
	     * passes of the compiler.  cpp doesn't have any yet.
	     */
	    printf("#pragma ");
	    while ((c = get()) != '\n' && c != '\r' && c != EOF_CHAR)
		cput(c);
	    unget();
	    break;

	case L_asm:
	    skipping = TRUE;
	    printf("#asm\n");
	    /* Skip until EOL */
	    while ((c = get()) != '\n' && c != '\r' && c != EOF_CHAR)
	      ;
	    return(counter);

	case L_easm:
	    skipping = FALSE;
	    printf("#easm\n");
	    /* Skip until EOL */
	    while ((c = get()) != '\n' && c != '\r' && c != EOF_CHAR)
	      ;
	    return(counter);
 
#if DEBUG
	case L_debug:
	    if (debug == 0)
		dumpdef("debug set on");
	    debug++;
	    break;

	case L_nodebug:
	    debug--;
	    break;
#endif

	default:
	    /*
	     * Undefined #control keyword.
	     * Note: the correct behavior may be to warn and
	     * pass the line to a subsequent compiler pass.
	     * This would allow #asm or similar extensions.
	     */
	    cerror("Illegal # command \"%s\"", token);
	    break;
	}
	if (hash != L_include) {
#if OLD_PREPROCESSOR
	    /*
	     * Ignore the rest of the #control line so you can write
	     *		#if	foo
	     *		#endif	foo
	     */
	    goto dump_line;			/* Take common exit	*/
#else
	    if ((c = skipws()) != '\n' && c != '\r') {
		cwarn("Unexpected text in #control line ignored", NULLST);
		skipnl();
	    }
#endif
	}
	return (counter + 1);
}

void doif(int hash)
/*
 * Process an #if, #ifdef, or #ifndef.  The latter two are straightforward,
 * while #if needs a subroutine of its own to evaluate the expression.
 *
 * doif() is called only if compiling is TRUE.  If false, compilation
 * is always supressed, so we don't need to evaluate anything.  This
 * supresses unnecessary warnings.
 */
{
	register int		c;
	register int		found;

	if ((c = skipws()) == '\n' || c == '\r' || c == EOF_CHAR) {
	    unget();
	    goto badif;
	}
	if (hash == L_if) {
	    unget();
	    found = (eval() != 0);	/* Evaluate expr, != 0 is  TRUE	*/
	    hash = L_ifdef;		/* #if is now like #ifdef	*/
	}
	else {
	    if (type[c] != LET)		/* Next non-blank isn't letter	*/
		goto badif;		/* ... is an error		*/
	    found = (lookid(c) != NULL); /* Look for it in symbol table	*/
	}
	if (found == (hash == L_ifdef)) {
	    compiling = TRUE;
	    *ifptr |= TRUE_SEEN;
	}
	else {
	    compiling = FALSE;
	}
	return;

badif:	cerror("#if, #ifdef, or #ifndef without an argument", NULLST);
#if !OLD_PREPROCESSOR
	skipnl();				/* Prevent an extra	*/
	unget();				/* Error message	*/
#endif
	return;
}

void doinclude()
/*
 * Process the #include control line.
 * There are three variations:
 *	#include "file"		search somewhere relative to the
 *				current source file, if not found,
 *				treat as #include <file>.
 *	#include <file>		Search in an implementation-dependent
 *				list of places.
 *	#include token		Expand the token, it must be one of
 *				"file" or <file>, process as such.
 *
 * Note: the November 12 draft forbids '>' in the #include <file> format.
 * This restriction is unnecessary and not implemented.
 */
{
	register int		c;
	register int		delim;

	delim = macroid(skipws());
	if (delim != '<' && delim != '"')
	    goto incerr;
	if (delim == '<')
	    delim = '>';
	workp = work;
	instring = TRUE;		/* Accept all characters	*/
#ifdef CONTROL_COMMENTS_NOT_ALLOWED
	while ((c = get()) != '\n' && c != '\r' && c != EOF_CHAR)
	    save(c);			/* Put it away.			*/
	unget();			/* Force nl after includee	*/
	/*
	 * The draft is unclear if the following should be done.
	 */
	while (--workp >= work && *workp == ' ')
	    ;				/* Trim blanks from filename	*/
	if (*workp != delim)
	    goto incerr;
#else
	while ((c = get()) != delim && c != EOF_CHAR)
	    save(c);
#endif
	*workp = EOS;			/* Terminate filename		*/
	instring = FALSE;
	if (openinclude(work, (delim == '"')))
	    return;
	/*
	 * No sense continuing if #include file isn't there.
	 */
	cfatal("Cannot open include file \"%s\"", work);

incerr:	cerror("#include syntax error", NULLST);
	return;
}

int openinclude(char *filename, int searchlocal)
/*
 * Actually open an include file.  This routine is only called from
 * doinclude() above, but was written as a separate subroutine for
 * programmer convenience.  It searches the list of directories
 * and actually opens the file, linking it into the list of
 * active files.  Returns TRUE if the file was opened, FALSE
 * if openinclude() fails.  No error message is printed.
 */
{
	register char		**incptr;
	char			tmpname[NWORK];	/* Filename work area	*/

	if (searchlocal) {
	    /*
	     * Look in local directory first
	     */
#if HOST == SYS_UNIX
	    /*
	     * Try to open filename relative to the directory of the current
	     * source file (as opposed to the current directory). (ARF, SCK).
	     */
	    if (filename[0] != '/'
	     && hasdirectory(infile->filename, tmpname))
		strcat(tmpname, filename);
	    else {
		strcpy(tmpname, filename);
	    }
#else
	    if (!hasdirectory(filename, tmpname)
	     && hasdirectory(infile->filename, tmpname))
		strcat(tmpname, filename);
	    else {
		strcpy(tmpname, filename);
	    }
#endif
	    if (openfile(tmpname))
		return (TRUE);
	}
	/*
	 * Look in any directories specified by -I command line
	 * arguments, then in the builtin search list.
	 */
	for (incptr = incdir; incptr < incend; incptr++) {
	    if (strlen(*incptr) + strlen(filename) >= (NWORK - 1))
		cfatal("Filename work buffer overflow", NULLST);
	    else {
#if HOST == SYS_UNIX
		if (filename[0] == '/')
		    strcpy(tmpname, filename);
		else {
		    sprintf(tmpname, "%s/%s", *incptr, filename);
		}
#else
		if (!hasdirectory(filename, tmpname))
		    sprintf(tmpname, "%s%s", *incptr, filename);
#endif
		if (openfile(tmpname))
		    return (TRUE);
	    }
	}
	return (FALSE);
}

int hasdirectory(char *source, char *result)
/*
 * If a device or directory is found in the source filename string, the
 * node/device/directory part of the string is copied to result and
 * hasdirectory returns TRUE.  Else, nothing is copied and it returns FALSE.
 */
{
#if HOST == SYS_UNIX
	register char		*tp;

	if ((tp = strrchr(source, '/')) == NULL)
	    return (FALSE);
	else {
	    strncpy(result, source, tp - source + 1);
	    result[tp - source + 1] = EOS;
	    return (TRUE);
	}
#endif
#if (HOST == SYS_DOS) || (HOST == SYS_ATARI)
	register char		*tp;

	if ((tp = strrchr(source, '\\')) == NULL)
	    return (FALSE);
	else {
	    strncpy(result, source, tp - source + 1);
	    result[tp - source + 1] = EOS;
	    return (TRUE);
	}
#endif
#if HOST == SYS_MAC
	register char		*tp;

	if ((tp = strrchr(source, ':')) == NULL)
	    return (FALSE);
	else {
	    strncpy(result, source, tp - source + 1);
	    result[tp - source + 1] = EOS;
	    return (TRUE);
	}
#endif
	return (FALSE);
}


