#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define CARTSIZE (32L*1024L)
#define NBSEG 8L
#define SEGSIZE (CARTSIZE/NBSEG)

#ifdef __MWERKS__
#include <console.h>
#endif

void main(int argc, char *argv[])
{
	FILE *ifp, *ofp;
	int size, err, byte, i;
	unsigned int pos, chk;
	unsigned char *cart[NBSEG];

#ifdef __MWERKS__
	argc = ccommand(&argv);
#endif

	if(argc != 3) {
		printf("Usage: %s outfile file.ihx\n", argv[0]);
		exit(1);
	}

	err = 0;
	if(!(ofp = fopen(argv[1],"wb"))) {
		printf("%s: Can't open file %s\n", argv[0], argv[1]);
		exit(1);
	}
	if(!(ifp = fopen(argv[2],"r"))) {
		printf("%s: Can't open file %s\n", argv[0], argv[2]);
		fclose(ofp);
		exit(1);
	}
	for(i = 0; i < NBSEG; i++) {
		if((cart[i] = malloc(SEGSIZE)) == NULL) {
			printf("%s: Can't allocate %dth segment of memory (%d bytes)\n", argv[0], i, (int)SEGSIZE);
			fclose(ofp);
			fclose(ifp);
			exit(1);
		}
		memset(cart[i], 0, SEGSIZE);
	}
	while(!feof(ifp)) {
		fscanf(ifp, ":%02X", &size);		/* nb of bytes */
		if(size == 0x00)
			break;
		chk = size;
		fscanf(ifp, "%02X", &i);			/* position (1st byte) */
		chk += i;
		fscanf(ifp, "%02X", &pos);			/* position (2nd byte) */
		chk += pos;
		pos = pos | (i<<8);
		fscanf(ifp, "%02X", &i);			/* always 0x00 */
		for(i = 0; i < size; i++) {
			fscanf(ifp, "%02X", &byte);
			chk += byte;
			if(pos < CARTSIZE)
			  cart[pos/SEGSIZE][pos%SEGSIZE] = byte;
			pos++;
		}
		fscanf(ifp, "%02X\n", &i);			/* checksum */
		if(i != ((-chk)&0xFF)) {
			printf("%s: Wrong checksum\n", argv[0]);
			err++;
			goto error;
		}
	}
	if(feof(ifp))
		err++;
	if(!err)
		fscanf(ifp, "%02X", &i);
	if(!err && i == 0x00)
		fscanf(ifp, "%02X", &i);
	else
		err++;
	if(!err && i == 0x00)
		fscanf(ifp, "%02X", &i);
	else
		err++;
	if(!err && i == 0x01)
		fscanf(ifp, "%02X", &i);
	else
		err++;
	if(!err && i == 0xFF)
		fscanf(ifp, "%02X", &i);
	else
		err++;

	if(err) {
		printf("%s: Garbage at end of file\n", argv[0]);
		goto error;
	}

	/* update checksum */
	chk = 0;
	cart[0x014E/SEGSIZE][0x014E%SEGSIZE] = 0;
	cart[0x014F/SEGSIZE][0x014F%SEGSIZE] = 0;
	for(i = 0; i < NBSEG; i++) {
		for(pos = 0; pos < SEGSIZE; pos++) {
			chk += cart[i][pos];
		}
	}
	cart[0x014E/SEGSIZE][0x014E%SEGSIZE] = (chk>>8)&0xFF;
	cart[0x014F/SEGSIZE][0x014F%SEGSIZE] = chk&0xFF;

	for(i = 0; i < NBSEG; i++)
		fwrite(cart[i], 1, SEGSIZE, ofp);
error:
	fclose(ofp);
	fclose(ifp);
	exit(err ? 1 : 0);
}
