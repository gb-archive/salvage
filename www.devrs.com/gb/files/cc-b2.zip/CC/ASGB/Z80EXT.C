/* z80ext.c */

/*
 * (C) Copyright 1989,1990
 * All Rights Reserve
 *
 * Alan R. Baldwin
 * 721 Berkeley St.
 * Kent, Ohio  44240
 */

#include <stdio.h>
#include <setjmp.h>
#include "asm.h"
#include "z80.h"

char	*cpu	= "GameBoy Z80-like CPU";
int	hilo	= 0;
char	*dsft	= "ASM";
