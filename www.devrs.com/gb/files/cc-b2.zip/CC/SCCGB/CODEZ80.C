#include <stdio.h>
#include <ctype.h>
#include "defs.h"
#include "data.h"
#include "decls.h"

/*	Define ASNM and LDNM to the names of the assembler and linker
	respectively */

/*
 *	Some predefinitions:
 *
 *	INTSIZE is the size of an integer in the target machine
 *	BYTEOFF is the offset of an byte within an integer on the
 *		target machine. (ie: 8080,pdp11 = 0, 6809 = 1,
 *		360 = 3)
 *	This compiler assumes that an integer is the SAME length as
 *	a pointer - in fact, the compiler uses INTSIZE for both.
 */
#define	INTSIZE	2
#define	BYTEOFF	0

/*
 *	print all assembler info before any code is generated
 *
 */
void header(char *name)
{
  char title[0x10];
  int i;

  i = strlen(name) - 1;
  while(i >= 0 && (isalnum(name[i]) || name[i] == '_' || name[i] == '.'))
    i--;
  name = &name[i + 1];
  for(i = 0; i < 0xF && name[i] != '\0' && name[i] != '.'; i++)
    title[i] = name[i];
  title[i] = '\0';

  ol ("; Small C Z80 for GameBoy.");
  ol ("; Coder   : ");
  ol ("; Version : ");
  ol ("; Date    : ");
  nl ();
  ol ("; Standard subroutines.");
  nl ();
  ol (".globl\t.gchar,.gint,.pchar,.pint,.bool");
  ol (".globl\t.sxt");
  ol (".globl\t.or,.and,.xor");
  ol (".globl\t.eq,.ne,.gt,.le,.ge,.lt,.uge,.ult,.ugt,.ule");
  ol (".globl\t.asr,.asl");
  ol (".globl\t.sub,.neg,.com,.lneg,.mul,.div");
  ol (".globl\t.case");
  nl ();
  outstr ("\t.title\t");
  outstr (title);
  nl ();
  outstr ("\t.module\t");
  outstr (title);
  nl ();
  nl ();
}

void nl()
{
  outbyte (EOL);
}

int galign(int t)
{
  return(t);
}

/*
 * return size of an integer
 */
int intsize()
{
  return(INTSIZE);
}

/*
 * return offset of ls byte within word
 * (ie: 8080 & pdp11 is 0, 6809 is 1, 360 is 3)
 */
int byteoff()
{
  return(BYTEOFF);
}

/*
 * Output internal generated label prefix
 */
void olprfix()
{
  outstr(".");
}

/*
 * Output a label definition terminator
 */
void col()
{
  outstr (":\n");
}

/*
 * begin a comment line for the assembler
 */
void comment()
{
  outstr ("; ");
}

/*
 * Emit user label prefix
 */
void prefix()
{
  outstr("_");
}


/*
 * print any assembler stuff needed after all code
 */
void trailer()
{
}

/*
 * function prologue
 */
void prologue()
{
}

/*
 * text (code) segment
 */
void gtext()
{
  ol (".area\t_CODE");
}

/*
 *	data segment
 */
void gdata()
{
  ol (".area\t_DATA");
}

/*
 *  Output the variable symbol at scptr as an extrn or a public
 */
void ppubext(sym_t *scptr)
{
  if (scptr->storage == STATIC) return;
  ot (".globl\t");
  prefix ();
  outstr (scptr->name);
  nl();
}

/*
 * Output the function symbol at scptr as an extrn or a public
 */
void fpubext(sym_t *scptr)
{
  if (scptr->storage == STATIC) return;
  ot (".globl\t");
  prefix ();
  outstr (scptr->name);
  nl ();
}

/*
 *  Output a decimal number to the assembler file
 */
void onum(int num)
{
  outdec(num);
}


/*
 * fetch a static memory cell into the primary register
 */
void getmem(sym_t *sym)
{
  if ((sym->ident != POINTER) && (sym->type == CCHAR)) {
    ot ("\tLD\tA,(");
    outstr (sym->name);
    outbyte(')');
    nl ();
    stdcall (".sxt");
  } else {
    ot ("\tLD\tHL,(");
    outstr (sym->name);
    outbyte(')');
    nl ();
  }
}

/*
 * fetch the address of the specified symbol into the primary register
 */
void getloc(sym_t *sym)
{
  immed ();
  if (sym->storage == LSTATIC) {
    printlabel(glint(sym));
    nl();
  } else {
    outdec (glint(sym) - stkp);
    nl ();
    ol ("ADD\tHL,SP");
  }
}

/*
 * store the primary register into the specified static memory cell
 */
void putmem(sym_t *sym)
{
  if ((sym->ident != POINTER) && (sym->type == CCHAR)) {
    ol ("LD\tA,L");
    ot ("LD\t(");
    outstr (sym->name);
    outstr ("),A");
  } else {
    ot ("LD\t(");
    outstr (sym->name);
    outstr ("),HL");
  }
  nl ();
}

/*
 * store the specified object type in the primary register
 * at the address on the top of the stack
 */
void putstk(char typeobj)
{
  gpop ();
  if (typeobj == CCHAR)
    stdcall (".pchar");
  else
    stdcall (".pint");
}

/*
 * fetch the specified object type indirect through the primary
 * register into the primary register
 */
void indirect(char typeobj)
{
  if (typeobj == CCHAR)
    stdcall (".gchar");
  else
    stdcall (".gint");
}

/*
 * swap the primary and secondary registers
 */
void swap()
{
  ol ("PUSH\tHL");
  ol ("PUSH\tDE");
  ol ("POP\tHL");
  ol ("POP\tDE");
}

/*
 * print partial instruction to get an immediate value into
 * the primary register
 */
void immed()
{
  ot ("LD\tHL,#");
}

/*
 * push the primary register onto the stack
 */
void gpush()
{
  ol ("PUSH\tHL");
  stkp = stkp - INTSIZE;
}

/*
 * pop the top of the stack into the secondary register
 */
void gpop()
{
  ol ("POP\tDE");
  stkp = stkp + INTSIZE;
}

/*
 * swap the primary register and the top of the stack
 */
void swapstk()
{
  ol ("EX\t(SP),HL");
}

/*
 * call the specified subroutine name
 */
void gcall(char *sname)
{
  ot ("CALL\t");
  prefix ();
  outstr (sname);
  nl ();
}

/*
 * call a standard subroutine
 */
void stdcall(char *sname)
{
  ot ("CALL\t");
  outstr (sname);
  nl ();
}

/*
 * return from subroutine
 */
void gret()
{
  ol ("RET");
}

/*
 * perform subroutine call to value on top of stack
 */
void callstk()
{
  immed ();
  outstr ("$+5");
  nl ();
  swapstk ();
  ol ("JP\t(HL)");
  stkp = stkp + INTSIZE;
}

/*
 * jump to specified internal label number
 */
void jump(int label)
{
  ot ("JP\t");
  printlabel (label);
  nl ();
}

/*
 * test the primary register and jump if false to label
 */
void testjump(int label, int ft)
{
  ol ("LD\tA,H");
  ol ("OR\tL");
  if (ft)
    ot ("JP\tNZ,");
  else
    ot ("JP\tZ,");
  printlabel (label);
  nl ();
}

/*
 * print pseudo-op  to define a byte
 */
void defbyte()
{
  ot (".db\t");
}

/*
 * print pseudo-op to define storage
 */
void defstorage()
{
  ot (".ds\t");
}

/*
 * print pseudo-op to define a word
 */
void defword()
{
  ot (".dw\t");
}

/*
 * modify the stack pointer to the new value indicated
 */
int modstk(int newstkp)
{
  int k;

  k = galign(newstkp - stkp);
  if (k == 0)
    return (newstkp);
  ot ("LDA\tSP,");
  outdec (k);
  outstr ("(SP)");
  nl ();
  return (newstkp);
}

/*
 * multiply the primary register by INTSIZE
 */
void gaslint()
{
  ol ("ADD\tHL,HL");
}

/*
 * divide the primary register by INTSIZE
 */
void gasrint()
{
  ol ("OR\tA");	/* clear the C flag */
  ol ("RR\tH");
  ol ("RR\tL");
}

/*
 * Case jump instruction
 */
void gjcase()
{
  ot ("JP\t.case");
  nl ();
}

/*
 * add the primary and secondary registers
 * if lval2 is int pointer and lval is not, scale lval
 */
void gadd(lval_t *lval, lval_t *lval2)
{
  gpop ();
  if (dbltest (lval2, lval)) {
    swap ();
    gaslint ();
    swap ();
  }
  ol ("ADD\tHL,DE");
}

/*
 * subtract the primary register from the secondary
 */
void gsub()
{
  gpop ();
  stdcall (".sub");
}

/*
 * multiply the primary and secondary registers
 * (result in primary)
 */
void gmult()
{
  gpop();
  stdcall (".mul");
}

/*
 * divide the secondary register by the primary
 * (quotient in primary, remainder in secondary)
 */
void gdiv()
{
  gpop();
  stdcall (".div");
}

/*
 * compute the remainder (mod) of the secondary register
 * divided by the primary register
 * (remainder in primary, quotient in secondary)
 */
void gmod()
{
  gdiv ();
  swap ();
}

/*
 * inclusive 'or' the primary and secondary registers
 */
void gor()
{
  gpop();
  stdcall (".or");
}

/*
 * exclusive 'or' the primary and secondary registers
 */
void gxor()
{
  gpop();
  stdcall (".xor");
}

/*
 * 'and' the primary and secondary registers
 */
void gand()
{
  gpop();
  stdcall (".and");
}

/*
 * arithmetic shift right the secondary register the number of
 * times in the primary register
 * (results in primary register)
 */
void gasr()
{
  gpop();
  stdcall (".asr");
}

/*
 * arithmetic shift left the secondary register the number of
 * times in the primary register
 * (results in primary register)
 */
void gasl()
{
  gpop ();
  stdcall (".asl");
}

/*
 * two's complement of primary register
 */
void gneg()
{
  stdcall (".neg");
}

/*
 * logical complement of primary register
 */
void glneg()
{
  stdcall (".lneg");
}

/*
 * one's complement of primary register
 */
void gcom()
{
  stdcall (".com");
}

/*
 * Convert primary value into logical value (0 if 0, 1 otherwise)
 */
void gbool()
{
  stdcall (".bool");
}

/*
 * increment the primary register by 1 if char, INTSIZE if int
 */
void ginc(lval_t *lval)
{
  ol ("INC\tHL");
  if (lval->type == CINT)
    ol ("INC\tHL");
}

/*
 * decrement the primary register by one if char, INTSIZE if int
 */
void gdec(lval_t *lval)
{
  ol ("DEC\tHL");
  if (lval->type == CINT)
    ol("DEC\tHL");
}

/*
 * following are the conditional operators.
 * they compare the secondary register against the primary register
 * and put a literl 1 in the primary if the condition is true,
 * otherwise they clear the primary register
 */

/*
 * equal
 */
void geq()
{
  gpop();
  stdcall (".eq");
}

/*
 * not equal
 */
void gne()
{
  gpop();
  stdcall (".ne");
}

/*
 * less than (signed)
 */
void glt()
{
  gpop();
  stdcall (".lt");
}

/*
 * less than or equal (signed)
 */
void gle()
{
  gpop();
  stdcall (".le");
}

/*
 * greater than (signed)
 */
void ggt()
{
  gpop();
  stdcall (".gt");
}

/*
 * greater than or equal (signed)
 */
void gge()
{
  gpop();
  stdcall (".ge");
}

/*
 * less than (unsigned)
 */
void gult()
{
  gpop();
  stdcall (".ult");
}

/*
 * less than or equal (unsigned)
 */
void gule()
{
  gpop();
  stdcall (".ule");
}

/*
 * greater than (unsigned)
 */
void gugt()
{
  gpop();
  stdcall (".ugt");
}

/*
 * greater than or equal (unsigned)
 */
void guge()
{
  gpop();
  stdcall (".uge");
}

/*
 * Squirrel away argument count in a register that modstk
 * doesn't touch.
*/

void gnargs(int d)
{
  ot ("LD\tA,#");
  onum(d);
  nl ();
}
