#include <stdio.h>
#include <string.h>
#include "defs.h"
#include "data.h"
#include "decls.h"

/*
 *	declare a static variable
 */
int declglb(int typ, int stor)
{
  sym_t *ptr;
  int k, j;
  char sname[NAMESIZE];

  if(ansi_c) {
    if (endst ())
      return(1);
    k = 1;
    if (match ("*"))
      j = POINTER;
    else
      j = VARIABLE;
    if (!symname (sname))
      illname ();
    if (match ("(")) {
      if ((ptr = findglb (sname))) {
        if (ptr->ident != FUNCTION)
          multidef (sname);
        else if (ptr->offset == FUNCTION)
          multidef (sname);
        else {
	  ptr->ident = FUNCTION;
	  ptr->type = CINT;
	  ptr->storage = PUBLIC;
          ptr->offset = FUNCTION;
	  newansifunc(sname);
	  return(0);
	}
      } else {
        addglb (sname, FUNCTION, CINT, FUNCTION, PUBLIC);
        newansifunc(sname);
        return(0);
      }
    } else {
      if (findglb (sname))
        multidef (sname);
      else {
        if (match ("[")) {
          k = needsub ();
          if (k || stor == EXTERN)
            j = ARRAY;
          else
            j = POINTER;
        }
        addglb (sname, j, typ, k, stor);
      }
      if (!match (","))
        return(1);
    }
  }

  FOREVER {
    FOREVER {
      if (endst ())
        return(1);
      k = 1;
      if (match ("*"))
        j = POINTER;
      else
        j = VARIABLE;
      if (!symname (sname))
        illname ();
      if (findglb (sname))
        multidef (sname);
      if (match ("[")) {
        k = needsub ();
        if (k || stor == EXTERN)
          j = ARRAY;
        else
          j = POINTER;
      }
      addglb (sname, j, typ, k, stor);
      break;
    }
    if (!match (","))
      return(1);
  }
  return(1);
}

/*
 *	declare local variables
 *
 *	works just like "declglb", but modifies machine stack and adds
 *	symbol table entry with appropriate stack offset to find it again
 */

void declloc(int typ, int stclass)
{
  int k, j;
  char sname[NAMESIZE];

  FOREVER {
    FOREVER {
      if (endst ())
	return;
      if (match ("*"))
	j = POINTER;
      else
	j = VARIABLE;
      if (!symname (sname))
	illname ();
      if (findloc (sname))
	multidef (sname);
      if (match ("[")) {
	k = needsub ();
	if (k) {
	  j = ARRAY;
	  if (typ == CINT)
	    k = k * intsize();
	} else {
	  j = POINTER;
	  k = intsize();
	}
      } else
	if ((typ == CCHAR) && (j != POINTER))
	  k = 1;
	else
	  k = intsize();
      if (stclass != LSTATIC) {
	k = galign(k);
	stkp = modstk (stkp - k);
	addloc (sname, j, typ, stkp, AUTO);
      } else
	addloc( sname, j, typ, k, LSTATIC);
      break;
    }
    if (!match (","))
      return;
  }
}

/*
void declloc(int typ, int stclass)
{
  int k, j, mod, orgstkp;
  char sname[NAMESIZE];

  mod = 0;
  orgstkp = stkp;
  FOREVER {
    FOREVER {
      if (endst ())
        goto correct;
      if (match ("*"))
        j = POINTER;
      else
        j = VARIABLE;
      if (!symname (sname))
        illname ();
      if (findloc (sname))
        multidef (sname);
      if (match ("[")) {
        k = needsub ();
        if (k) {
          j = ARRAY;
          if (typ == CINT)
          k = k * intsize();
        } else {
          j = POINTER;
          k = intsize();
        }
      } else if ((typ == CCHAR) && (j != POINTER))
        k = 1;
      else
        k = intsize();
      if (stclass != LSTATIC) {
        k = galign(k);
        mod += k;
        stkp -= k;
        addloc (sname, j, typ, stkp, AUTO);
      } else
        addloc( sname, j, typ, k, LSTATIC);
      break;
    }
    if (!match (","))
      goto correct;
  }
correct:
  if(k != 0) {
    stkp = orgstkp;
    stkp = modstk (stkp - mod);
  }
}
*/

/*
 *	get required array size
 */
int needsub()
{
  int num[1];

  if (match ("]"))
    return (0);
  if (!number (num)) {
    error ("must be constant");
    num[0] = 1;
  }
  if (num[0] < 0) {
    error ("negative size illegal");
    num[0] = (-num[0]);
  }
  needbrack ("]");
  return (num[0]);
}

sym_t *findglb(char *sname)
{
  sym_t *ptr;

  ptr = STARTGLB;
  while (ptr != glbptr) {
    if (astreq (sname, ptr->name, NAMEMAX))
      return (ptr);
    ptr++;
  }
  return (0);
}

sym_t *findloc(char *sname)
{
  sym_t *ptr;

  ptr = locptr;
  while (ptr != STARTLOC) {
    ptr--;
    if (astreq (sname, ptr->name, NAMEMAX))
      return (ptr);
  }
  return (0);
}

sym_t *addglb(char *sname, char id, char typ, int value, int stor)
{
  if ((cptr = findglb (sname)))
    return (cptr);
  if (glbptr >= ENDGLB) {
    error ("global symbol table overflow");
    return (0);
  }
  cptr = glbptr;
  strcpy(cptr->name, sname);
  cptr->ident = id;
  cptr->type = typ;
  cptr->storage = stor;
  cptr->offset = value;
  glbptr++;
  return (cptr);
}

sym_t *addloc(char *sname, char id, char typ, int value, int stclass)
{
  int k;

  if ((cptr = findloc (sname)))
    return (cptr);
  if (locptr >= ENDLOC) {
    error ("local symbol table overflow");
    return (0);
  }
  cptr = locptr;
  strcpy(cptr->name, sname);
  cptr->ident = id;
  cptr->type = typ;
  cptr->storage = stclass;
  if (stclass == LSTATIC) {
    gdata();
    printlabel(k = getlabel());
    col();
    defstorage();
    onum(value);
    nl();
    gtext();
    value = k;
  } else
    value = galign(value);
  cptr->offset = value;
  locptr++;
  return (cptr);
}

/*
 *	test if next input string is legal symbol name
 *
 */
int symname(char *sname)
{
  int k;

  blanks ();
  if (!alpha (ch ()))
    return (0);
  k = 0;
  while (an (ch ()))
    sname[k++] = gch ();
  sname[k] = 0;
  return (1);
}

void illname()
{
  error ("illegal symbol name");
}

void multidef(char *sname)
{
  error ("already defined");
  comment ();
  outstr (sname);
  nl ();
}

int glint(sym_t *syment)
{
  return(syment->offset);
}
