#include <stdio.h>
#include "defs.h"
#include "data.h"
#include "decls.h"

/*
 *	return next available internal label number
 *
 */
int getlabel()
{
  return (nxtlab++);
}

/*
 *	print specified number as label
 */
void printlabel(int label)
{
  olprfix ();
  outdec (label);
}

/*
 *	glabel - generate label
 */
void glabel(char *lab)
{
  prefix ();
  outstr (lab);
  col ();
  nl ();
}

/*
 *	gnlabel - generate numeric label
 */
void gnlabel(int nlab)
{
  printlabel (nlab);
  col ();
  nl ();
}

int outbyte(char c)
{
  if (c == 0)
    return (0);
  fputc (c, output);
  return (c);
}

void outstr(char *ptr)
{
  int	k;

  k = 0;
  while (outbyte (ptr[k++]));
}


void tab()
{
  outbyte (9);
}

void ol (char *ptr)
{
  ot (ptr);
  nl ();
}

void ot(char *ptr)
{
  tab ();
  outstr (ptr);
}

void outdec(int number)
{
  int k, zs;
  char c;

  if (number == -32768) {
    outstr ("-32768");
    return;
  }
  zs = 0;
  k = 10000;
  if (number < 0) {
    number = (-number);
    outbyte ('-');
  }
  while (k >= 1) {
    c = number / k + '0';
    if ((c != '0' || (k == 1) || zs)) {
      zs = 1;
      outbyte (c);
    }
    number = number % k;
    k = k / 10;
  }
}

void store(lval_t *lval)
{
  if (lval->what == 0)
    putmem (lval->addr);
  else
    putstk ((int)lval->what);
}

void rvalue (lval_t *lval)
{
  if ((lval->addr != 0) && (lval->what == 0))
    getmem (lval->addr);
  else
    indirect ((int)lval->what);
}

void test(int label, int ft)
{
  needbrack ("(");
  expression (YES);
  needbrack (")");
  testjump (label, ft);
}
