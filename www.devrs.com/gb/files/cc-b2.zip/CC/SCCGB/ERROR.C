#include <stdio.h>
#include "defs.h"
#include "data.h"
#include "decls.h"

void error(char *ptr)
{
  FILE *tempfile;

  tempfile = output;
  output = stdout;
  doerror(ptr);
  output = tempfile;
  doerror(ptr);
  errcnt++;
}

void doerror(char *ptr)
{
  int k;
  comment ();
  outstr (line);
  nl ();
  comment ();
  k = 0;
  while (k < lptr) {
    if (line[k] == 9)
      tab ();
    else
      outbyte (' ');
    k++;
  }
  outbyte ('^');
  nl ();
  comment ();
  outstr ("******  ");
  outstr (ptr);
  outstr ("  ******");
  nl ();
}
