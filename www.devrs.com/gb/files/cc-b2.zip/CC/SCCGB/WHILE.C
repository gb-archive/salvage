#include <stdio.h>
#include "defs.h"
#include "data.h"
#include "decls.h"

void addwhile(ws_t *ptr)
{
  int k;

  if (wsptr == WSMAX) {
    error ("too many active whiles");
    return;
  }
  k = 0;
  *wsptr++ = *ptr;
}

void delwhile()
{
  if (readwhile ())
    wsptr--;
}

ws_t *readwhile()
{
  if (wsptr == ws) {
    error ("no active do/for/while/switch");
    return (0);
  } else
    return (wsptr-1);
}

ws_t *findwhile()
{
  ws_t *ptr;

  for (ptr = wsptr; ptr != ws;) {
    ptr--;
    if (ptr->type != WSSWITCH)
      return (ptr);
  }
  error ("no active do/for/while");
  return (0);
}

ws_t *readswitch()
{
  ws_t *ptr;

  if ((ptr = readwhile ()))
    if (ptr->type == WSSWITCH)
      return (ptr);
  return (0);
}

void addcase(int val)
{
  int lab;

  if (swstp == SWSTSZ)
    error ("too many case labels");
  else {
    swstcase[swstp] = val;
    swstlab[swstp++] = lab = getlabel ();
    printlabel (lab);
    col ();
    nl ();
  }
}
