#include <stdio.h>
#include "defs.h"
#include "data.h"
#include "decls.h"

/*
 *	begin a function
 *
 *	called from "parse", this routine tries to make a function out
 *	of what follows
 *	modified version.  p.l. woods
 *
 */
int argtop;

void newfunc()
{
  char n[NAMESIZE];
  sym_t *ptr;

  fexitlab = getlabel();
  if (!symname (n) ) {
    error ("illegal function or declaration");
    kill ();
    return;
  }
  if ((ptr = findglb (n))) {
    if (ptr->ident != FUNCTION)
      multidef (n);
    else if (ptr->offset == FUNCTION)
      multidef (n);
    else
      ptr->offset = FUNCTION;
  } else
    addglb (n, FUNCTION, CINT, FUNCTION, PUBLIC);
  prologue ();
  if (!match ("("))
    error ("missing open paren");
  prefix ();
  outstr (n);
  col ();
  nl ();
  locptr = STARTLOC;
  argstk = 0;
  while (!match (")")) {
    if (symname (n)) {
      if (findloc (n))
        multidef (n);
      else {
        addloc (n, 0, 0, argstk, AUTO);
        argstk = argstk + intsize();
      }
    } else {
      error ("illegal argument name");
      junk ();
    }
    blanks ();
    if (!streq (line + lptr, ")")) {
      if (!match (","))
        error ("expected comma");
    }
    if (endst ())
      break;
  }
  stkp = 0;
  argtop = argstk;
  while (argstk) {
    if (amatch ("register", 8)) {
      if (amatch("char", 4)) 
        getarg(CCHAR);
      else if (amatch ("int", 3))
        getarg(CINT);
      else
        getarg(CINT);
      ns();
    } else if (amatch ("char", 4)) {
      getarg (CCHAR);
      ns ();
    } else if (amatch ("int", 3)) {
      getarg (CINT);
      ns ();
    } else {
      error ("wrong number args");
      break;
    }
  }
  statement(YES);
  printlabel(fexitlab);
  col();
  nl();
  modstk (0);
  gret ();
  stkp = 0;
  locptr = STARTLOC;
}

void newansifunc(char *n)
{
  int address;
  sym_t *startptr;

  fexitlab = getlabel();

  prologue ();
  prefix ();
  outstr (n);
  col ();
  nl ();
  locptr = STARTLOC;
  argstk = 0;
  startptr = locptr;
  if (!match (")")) {
    FOREVER {
      if (amatch ("register", 8)) {
        if (amatch("char", 4)) 
          getansiarg(CCHAR);
        else if (amatch ("int", 3))
          getansiarg(CINT);
        else
          getansiarg(CINT);
      } else if (amatch ("char", 4)) {
        getansiarg (CCHAR);
      } else if (amatch ("int", 3)) {
        getansiarg (CINT);
      } else {
        error ("illegal argument type");
        junk ();
        break;
      }
      if (match (")"))
        break;
      if (!match (","))
        error ("expected comma");
    }
  }
  stkp = 0;
  argtop = argstk;
  while (argstk) {
    address = argtop - glint(startptr);
    if (startptr->type == CCHAR && startptr->ident == VARIABLE)
      address = address + byteoff();
    startptr->offset = address;
    argstk = argstk - intsize();
    startptr++;
  }
  statement(YES);
  printlabel(fexitlab);
  col();
  nl();
  modstk (0);
  gret ();
  stkp = 0;
  locptr = STARTLOC;
}

/*
 *	declare argument types
 *
 *	called from "newfunc", this routine add an entry in the local
 *	symbol table for each named argument
 *	completely rewritten version.  p.l. woods
 *
 */
void getarg(int t)
{
  int j, legalname, address;
  char n[NAMESIZE];
  sym_t *argptr;

  FOREVER {
    if (argstk == 0)
      return;
    if (match ("*"))
      j = POINTER;
    else
      j = VARIABLE;
    if (!(legalname = symname (n)))
      illname ();
    if (match ("[")) {
      while (inpbyte () != ']')
        if (endst ())
          break;
      j = POINTER;
    }
    if (legalname) {
      if ((argptr = findloc (n))) {
        argptr->ident = j;
        argptr->type = t;
        address = argtop - glint(argptr);
        if (t == CCHAR && j == VARIABLE)
          address = address + byteoff();
        argptr->offset = address;
      } else
        error ("expecting argument name");
    }
    argstk = argstk - intsize();
    if (endst ())
      return;
    if (!match (","))
      error ("expected comma");
  }
}

void getansiarg(int t)
{
  int j, legalname;
  char n[NAMESIZE];

  if (match ("*"))
    j = POINTER;
  else
    j = VARIABLE;
  if (!(legalname = symname (n)))
    illname ();
  if (match ("[")) {
    while (inpbyte () != ']')
      if (endst ())
        break;
    j = POINTER;
  }
  if (legalname) {
    if (findloc (n))
      multidef (n);
    else {
      addloc (n, j, t, argstk, AUTO);
      argstk = argstk + intsize();
    }
  }
}
