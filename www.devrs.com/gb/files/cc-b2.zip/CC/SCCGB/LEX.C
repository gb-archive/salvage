#include <stdio.h>
#include <ctype.h>
#include "defs.h"
#include "data.h"
#include "decls.h"

/*
 *	semicolon enforcer
 *
 *	called whenever syntax requires a semicolon
 *
 */
void ns()
{
  if (!match (";")) {
    error ("missing semicolon");
    kill ();
  }
}

void junk()
{
  if (an (inpbyte ()))
    while (an (ch ()))
      gch ();
  else
    while (an (ch ())) {
      if (ch () == 0)
	break;
      gch ();
    }
  blanks ();
}

int endst()
{
  blanks ();
  return ((streq (line + lptr, ";") || (ch () == 0)));
}

void needbrack(char *str)
{
  if (!match (str)) {
    error ("missing bracket");
    comment ();
    outstr (str);
    nl ();
  }
}

/*
 *	test if given character is alpha
 *
 */
int alpha(char c)
{
  return (isalpha(c) || (c == '_'));
}

/*
 *	test if given character is alphanumeric
 *
 */
int an(char c)
{
  return (alpha (c) || isdigit (c));
}

int sstreq(char *str1)
{
  return (streq(line + lptr, str1));
}

int streq(char *str1, char *str2)
{
  int k;

  k = 0;
  while (str2[k]) {
    if ((str1[k] != str2[k]))
      return (0);
    k++;
  }
  return (k);
}

int astreq(char *str1, char *str2, int len)
{
  int k;

  k = 0;
  while (k < len) {
    if ((str1[k] != str2[k]))
      break;
    if (str1[k] == 0)
      break;
    if (str2[k] == 0)
      break;
    k++;
  }
  if (an (str1[k]))
    return (0);
  if (an (str2[k]))
    return (0);
  return (k);
}

int match(char *lit)
{
  int k;

  blanks ();
  if ((k = streq (line + lptr, lit))) {
    lptr = lptr + k;
    return (1);
  }
  return (0);
}

int amatch(char *lit, int len)
{
  int k;

  blanks ();
  if ((k = astreq (line + lptr, lit, len))) {
    lptr = lptr + k;
    while (an (ch ()))
      inpbyte ();
    return (1);
  }
  return (0);
}

void blanks()
{
  FOREVER {
    while (ch () == 0) {
      inpline();
      if (feof (input))
      break;
    }
    if (ch () == ' ')
      gch ();
    else if (ch () == '\t')
      gch ();
    else
      return;
  }
}
