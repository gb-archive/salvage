#include <stdio.h>
#include "defs.h"
#include "data.h"
#include "decls.h"

/*
 *	statement parser
 *
 *	called whenever syntax requires a statement.  this routine
 *	performs that statement and returns a number telling which one
 *
 *	'func' is true if we require a "function_statement", which
 *	must be compound, and must contain "statement_list" (even if
 *	"declaration_list" is omitted)
 */

int statement(int func)
{
  if ((ch () == 0) & feof (input))
    return (0);
  lastst = 0;
  if (func)
    if (match ("{")) {
      compnd (YES);
      return (lastst);
    } else
      error ("function requires compound statement");
  if (match ("{"))
    compnd (NO);
  else
    stst ();
  return (lastst);
}

/*
 *	declaration
 */
int stdecl()
{
  if (amatch("register", 8))
    doldcls(DEFAUTO);
  else if (amatch("auto", 4))
    doldcls(DEFAUTO);
  else if (amatch("static", 6))
    doldcls(LSTATIC);
  else if (doldcls(AUTO))
    ;
  else
    return (NO);
  return (YES);
}

int doldcls(int stclass)
{
  blanks();
  if (amatch("char", 4))
    declloc(CCHAR, stclass);
  else if (amatch("int", 3))
    declloc(CINT, stclass);
  else if (stclass == LSTATIC || stclass == DEFAUTO)
    declloc(CINT, stclass);
  else
    return(0);
  ns();
  return(1);
}


/*
 *	non-declaration statement
 */
void stst()
{
  if (amatch ("if", 2)) {
    doif ();
    lastst = STIF;
  } else if (amatch ("while", 5)) {
    dowhile ();
    lastst = STWHILE;
  } else if (amatch ("switch", 6)) {
    doswitch ();
    lastst = STSWITCH;
  } else if (amatch ("do", 2)) {
    dodo ();
    ns ();
    lastst = STDO;
  } else if (amatch ("for", 3)) {
    dofor ();
    lastst = STFOR;
  } else if (amatch ("return", 6)) {
    doreturn ();
    ns ();
    lastst = STRETURN;
  } else if (amatch ("break", 5)) {
    dobreak ();
    ns ();
    lastst = STBREAK;
  } else if (amatch ("continue", 8)) {
    docont ();
    ns ();
    lastst = STCONT;
  } else if (match (";"))
    ;
  else if (amatch ("case", 4)) {
    docase ();
    lastst = statement (NO);
  } else if (amatch ("default", 7)) {
    dodefault ();
    lastst = statement (NO);
  } else if (match ("#asm")) {
    doasm ();
    lastst = STASM;
  } else if (match ("#line")) {
    inpline ();
    lastst = STASM;
  } else if (match ("{"))
    compnd (NO);
  else {
    expression (YES);
/*    if (match (":")) {
 *     dolabel ();
 *     lastst = statement (NO);
 *    } else {
 */
    ns ();
    lastst = STEXP;
/*    }
 */
  }
}

/*
 *	compound statement
 *
 *	allow any number of statements to fall between "{" and "}"
 *
 *	'func' is true if we are in a "function_statement", which
 *	must contain "statement_list"
 */
void compnd(int func)
{
  int decls;

  decls = YES;
  ncmp++;
  while (!match ("}")) {
    if (feof (input))
      return;
    if (decls) {
      if (!stdecl ())
	decls = NO;
    } else
      stst ();
  }
  ncmp--;
}

/*
 *	"if" statement
 */
void doif()
{
  int fstkp, flab1, flab2;
  sym_t *flev;

  flev = locptr;
  fstkp = stkp;
  flab1 = getlabel ();
  test (flab1, FALSE);
  statement (NO);
  stkp = modstk (fstkp);
  locptr = flev;
  if (!amatch ("else", 4)) {
    gnlabel (flab1);
    return;
  }
  jump (flab2 = getlabel ());
  gnlabel (flab1);
  statement (NO);
  stkp = modstk (fstkp);
  locptr = flev;
  gnlabel (flab2);
}

/*
 *	"while" statement
 */
void dowhile()
{
  ws_t ws;

  ws.sym = locptr;
  ws.sp = stkp;
  ws.type = WSWHILE;
  ws.test_casep = getlabel ();
  ws.exit = getlabel ();
  addwhile (&ws);
  gnlabel (ws.test_casep);
  test (ws.exit, FALSE);
  statement (NO);
  jump (ws.test_casep);
  gnlabel (ws.exit);
  locptr = ws.sym;
  stkp = modstk (ws.sp);
  delwhile ();
}

/*
 *	"do" statement
 */
void dodo()
{
  ws_t ws;

  ws.sym = locptr;
  ws.sp = stkp;
  ws.type = WSDO;
  ws.body_tab = getlabel ();
  ws.test_casep = getlabel ();
  ws.exit = getlabel ();
  addwhile (&ws);
  gnlabel (ws.body_tab);
  statement (NO);
  if (!match ("while")) {
    error ("missing while");
    return;
  }
  gnlabel (ws.test_casep);
  test (ws.body_tab, TRUE);
  gnlabel (ws.exit);
  locptr = ws.sym;
  stkp = modstk (ws.sp);
  delwhile ();
}

/*
 *	"for" statement
 */
void dofor()
{
  ws_t ws, *ptr;

  ws.sym = locptr;
  ws.sp = stkp;
  ws.type = WSFOR;
  ws.test_casep = getlabel ();
  ws.incr_def = getlabel ();
  ws.body_tab = getlabel ();
  ws.exit = getlabel ();
  addwhile (&ws);
  ptr = readwhile ();
  needbrack ("(");
  if (!match (";")) {
    expression (YES);
    ns ();
  }
  gnlabel (ptr->test_casep);
  if (!match (";")) {
    expression (YES);
    testjump (ptr->body_tab, TRUE);
    jump (ptr->exit);
    ns ();
  } else
    ptr->test_casep = ptr->body_tab;
  gnlabel (ptr->incr_def);
  if (!match (")")) {
    expression (YES);
    needbrack (")");
    jump (ptr->test_casep);
  } else
    ptr->incr_def = ptr->test_casep;
  gnlabel (ptr->body_tab);
  statement (NO);
  jump (ptr->incr_def);
  gnlabel (ptr->exit);
  locptr = ptr->sym;
  stkp = modstk (ptr->sp);
  delwhile ();
}

/*
 *	"switch" statement
 */
void doswitch()
{
  ws_t ws, *ptr;

  ws.sym = locptr;
  ws.sp = stkp;
  ws.type = WSSWITCH;
  ws.test_casep = swstp;
  ws.body_tab = getlabel ();
  ws.incr_def = ws.exit = getlabel ();
  addwhile (&ws);
  immed ();
  printlabel (ws.body_tab);
  nl ();
  gpush ();
  needbrack ("(");
  expression (YES);
  needbrack (")");
  stkp = stkp + intsize();  /* '?case' will adjust the stack */
  gjcase ();
  statement (NO);
  ptr = readswitch ();
  jump (ptr->exit);
  dumpsw (ptr);
  gnlabel (ptr->exit);
  locptr = ptr->sym;
  stkp = modstk (ptr->sp);
  swstp = ptr->test_casep;
  delwhile ();
}

/*
 *	"case" label
 */
void docase()
{
  int val;

  val = 0;
  if (readswitch ()) {
    if (!number (&val))
      if (!pstr (&val))
	error ("bad case label");
    addcase (val);
    if (!match (":"))
      error ("missing colon");
  } else
    error ("no active switch");
}

/*
 *	"default" label
 */
void dodefault()
{
  ws_t *ptr;
  int lab;

  if ((ptr = readswitch ())) {
    ptr->incr_def = lab = getlabel ();
    gnlabel (lab);
    if (!match (":"))
      error ("missing colon");
  } else
    error ("no active switch");
}

/*
 *	"return" statement
 */
void doreturn()
{
  if (endst () == 0)
    expression (YES);
  jump(fexitlab);
}

/*
 *	"break" statement
 */
void dobreak()
{
  ws_t *ptr;

  if ((ptr = readwhile ()) == 0)
    return;
  modstk (ptr->sp);
  jump (ptr->exit);
}

/*
 *	"continue" statement
 */
void docont()
{
  ws_t *ptr;

  if ((ptr = findwhile ()) == 0)
    return;
  modstk (ptr->sp);
  if (ptr->type == WSFOR)
    jump (ptr->incr_def);
  else
    jump (ptr->test_casep);
}

/*
 *	dump switch table
 */
void dumpsw(ws_t *ws)
{
  int i,j;

  gdata ();
  gnlabel (ws->body_tab);
  if (ws->test_casep != swstp) {
    j = ws->test_casep;
    while (j < swstp) {
      defword ();
      i = 4;
      while (i--) {
	onum (swstcase[j]);
	outbyte (',');
	printlabel (swstlab[j++]);
	if ((i == 0) || (j >= swstp)) {
	  nl ();
	  break;
	}
	outbyte (',');
      }
    }
  }
  defword ();
  printlabel (ws->incr_def);
  outstr (",0");
  nl ();
  gtext ();
}
