#include <stdio.h>
#include <string.h>
#include "defs.h"
#include "data.h"
#include "decls.h"

/*
 *	open input file
 */
int openin(char *p)
{
  strcpy(fname, p);
  fixname(fname);
  if (!checkname (fname))
    return (NO);
  input = fopen (fname, "r");
  if (input == NULL) {
    puts("Open failure");
    return (NO);
  }
  kill ();
  return (YES);
}

/*
 *	open output file
 */
int openout()
{
  changefname(fname);
  output = fopen (fname, "w");
  if (output == NULL) {
    puts("Open failure");
    return (NO);
  }
  kill ();
  return (YES);
}

/*
 *	change input filename to output filename
 */
void changefname(char *s)
{
  while (*s && *s != '.')
    s++;
  if(*s != '.')
    *++s = '.';
  *++s = 's';
  *++s = '\0';
}

/*
 *	remove NL from filenames and change extension
 *
 */
void fixname(char *s)
{
  while (*s && *s++ != EOL);
  if (!*s) return;
  *(--s) = 0;
}

/*
 *	check that filename is "*.c" or "*.cpp"
 */
int checkname(char *s)
{
  while (*s)
    s++;
  --s;
  if (*s != 'c' && !(*s == 'p' && *--s == 'p' && *--s == 'c'))
    return (NO);
  if (*--s != '.')
    return (NO);
  return (YES);
}

void kill()
{
  lptr = 0;
  line[lptr] = 0;
}

void inpline()
{
  int	k;
  FILE	*unit;

  FOREVER {
    if (feof (input))
      return;
    unit = input;
    kill ();
    while ((k = fgetc (unit)) != EOF) {
      if ((k == EOL) || (k == CR) || (lptr >= LINEMAX))
      break;
      line[lptr++] = k;
    }
    line[lptr] = 0;
    if (lptr) {
      if ((ctext) && (cmode)) {
        comment ();
        outstr (line);
        nl ();
      }
      lptr = 0;
      return;
    }
  }
}

int inpbyte()
{
  while (ch () == 0) {
    if (feof (input))
      return (0);
    inpline();
  }
  return (gch ());
}

int inpchar()
{
  if (ch () == 0)
    inpline ();
  if (feof (input))
    return (0);
  return (gch ());
}

int gch()
{
  if (ch () == 0)
    return (0);
  else
    return (line[lptr++] & 127);
}

int nch()
{
  if (ch () == 0)
    return (0);
  else
    return (line[lptr + 1] & 127);
}

int ch()
{
  return (line[lptr] & 127);
}

void doasm()
{
  cmode = 0;
  FOREVER {
    inpline ();
    if (match ("#easm"))
      break;
    if (feof (input))
      break;
    outstr (line);
    nl ();
  }
  cmode = 1;
}
