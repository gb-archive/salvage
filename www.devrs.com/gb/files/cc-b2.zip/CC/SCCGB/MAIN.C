#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "defs.h"
#include "data.h"
#include "decls.h"

#ifdef __MWERKS__
#include <console.h>
#endif

void main(int argc, char *argv[])
{
  char *p, **files;
  int arg, nbfiles;

#ifdef __MWERKS__
  argc = ccommand(&argv);
#endif

  if(argc < 2)
    usage();

  ctext = 0;
  arg = 1;
  errs = 0;
  aflag = 1;
  ansi_c = 1;
  while(arg < argc) {
    p = argv[arg];
    if (*p == '-') {
      arg++;
      while (*++p)
	switch(*p)
	  {
	  case 't': case 'T':
	    ctext = 1;
	    break;
	  case 'a': case 'A':
	    aflag = 0;
	    break;
	  case 'f': case 'F':
	    ansi_c = 0;
	    break;
	  default:
	    usage();
	  }
    }
    else break;
  }

  if(arg == argc)
    usage();
  files = &argv[arg];
  nbfiles = argc - arg;
  while(arg < argc) {
    p = argv[arg++];
    errfile = 0;
    if(type(p) == 'c') {
      glbptr = STARTGLB;
      locptr = STARTLOC;
      wsptr = ws;
      swstp =
      litptr =
      stkp =
      errcnt =
      ncmp =
      lastst =
      quote[1] =
      0;
      quote[0] = '"';
      cmode = 1;
      glbflag = 1;
      nxtlab = 0;
      litlab = getlabel ();
      addglb("memory", ARRAY, CCHAR, 0, EXTERN);
      addglb("stack", ARRAY, CCHAR, 0, EXTERN);
      rglbptr = glbptr;
      /*
       *	compiler body
       */
      printf("Compiling %s...\n", p);
      if (!openin (p))
	return;
      if (!openout ())
	return;
      header (p);
      gtext ();
      parse ();
      fclose (input);
      gdata ();
      dumplits ();
      dumpglbs ();
      errorsummary ();
      trailer ();
      fclose (output);
      errs = errs || errfile;
    }
  }
  exit(errs != 0);
}

void FEvers()
{
  outstr("\tsccGB Front End v1.0");
}

void usage()
{
  fputs("usage: sccGB [-tar] files\n", stderr);
  fputs("  t    keep commented C source code in assembly code\n", stderr);
  fputs("  a    put the nb of arg in reg A before a function call\n", stderr);
  fputs("  f    old parameter style in function calls\n", stderr);
  exit(1);
}

/*
 *	process all input text
 *
 *	at this level, only static declarations, defines, includes,
 *	and function definitions are legal.
 *
 */
void parse()
{
  while (!feof (input)) {
    if (amatch ("extern", 6))
      dodcls(EXTERN);
    else if (amatch ("static",6))
      dodcls(STATIC);
    else if (match ("#asm"))
      doasm();
    else if (match ("#line")) 
      inpline ();
    else if (dodcls(PUBLIC))
      ;
    else if (!ansi_c)
      newfunc ();
    else {
      error ("missing return type for function call");
      dodcls(STATIC);
    }
    blanks ();
  }
}

/*
 *		parse top level declarations
 */

int dodcls(int stclass)
{
  int k;

  blanks();
  if (amatch("char", 4))
    k = declglb(CCHAR, stclass);
  else if (amatch("int", 3))
    k = declglb(CINT, stclass);
  else if (amatch("void", 4))
    k = declglb(CINT, stclass);
  else if (stclass == PUBLIC)
    return(0);
  else
    k = declglb(CINT, stclass);
  if(k)
    ns ();
  return(1);
}


/*
 *	dump the literal pool
 */
void dumplits()
{
  int j, k;

  if (litptr == 0)
    return;
  printlabel (litlab);
  col ();
  k = 0;
  while (k < litptr) {
    defbyte ();
    j = 8;
    while (j--) {
      onum (litq[k++] & 127);
      if ((j == 0) || (k >= litptr)) {
	nl ();
	break;
      }
      outbyte (',');
    }
  }
}

/*
 *	dump all static variables
 */
void dumpglbs()
{
  int j;

  if (!glbflag)
    return;
  cptr = rglbptr;
  while (cptr < glbptr) {
    if (cptr->ident != FUNCTION) {
      ppubext(cptr);
      if (cptr->storage != EXTERN) {
	prefix ();
	outstr (cptr->name);
	col ();
	defstorage ();
	j = glint(cptr);
	if ((cptr->type == CINT) ||
	    (cptr->ident == POINTER))
	  j = j * intsize();
	onum (j);
	nl ();
      }
    } else {
      fpubext(cptr);
    }
    cptr++;
  }
}

/*
 *	report errors
 */
void errorsummary()
{
  if (ncmp)
    error ("missing closing bracket");
  nl ();
  comment ();
  outdec (errcnt);
  if (errcnt) errfile = YES;
  outstr (" error(s) in compilation");
  nl ();
  comment();
  outstr("literal pool : ");
  outdec(litptr);
  nl();
  comment();
  outstr("global pool : ");
  outdec((glbptr-rglbptr) * sizeof(sym_t));
  nl();
  if(errcnt)
    printf("%d Error(s)\n", errcnt);
  else
    puts("No errors");
}

int type(char *s)
{
  s += strlen(s) - 2;
  if (*s == '.')
    return(*(s+1));
  s -= 2;
  if (*s == '.')
    return(*(s+1));
  return(' ');
}
