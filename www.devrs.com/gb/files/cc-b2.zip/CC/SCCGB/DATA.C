#include <stdio.h>
#include "defs.h"

/* storage words */

sym_t	symtab[SYMTBSZ];
sym_t	*glbptr, *rglbptr, *locptr;
ws_t	ws[WSTABSZ];
ws_t	*wsptr;
int	swstcase[SWSTSZ];
int	swstlab[SWSTSZ];
int	swstp;
char	litq[LITABSZ];
int	litptr;
char	line[LINESIZE];
int	lptr;

/* miscellaneous storage */

int	nxtlab,
	litlab,
	stkp,
	argstk,
	ncmp,
	errcnt,
	glbflag,
	ctext,
	cmode,
	lastst;

FILE	*input, *output;
char	fname[20];

char	quote[2];
sym_t	*cptr;
int	fexitlab;
int	errfile;
int	errs;
int	aflag;
int ansi_c;
