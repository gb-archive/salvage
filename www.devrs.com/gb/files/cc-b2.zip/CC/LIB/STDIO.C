#include <stdio.h>

/* ************************************************************ */

int atoi(char *s)
{
  int i, n, sign;

  for(i = 0; (s[i] == ' ') || (s[i] == EOL) || (s[i] == '\t'); ++i)
    ;
  sign = 1;
  switch(s[i])
    {
    case '-':
      sign = -1;
      /* and fall through */
    case '+':
      ++i;
      break;
    }
  for(n = 0; isdigit(s[i]); ++i)
    n = 10 * n + s[i] - '0';
  return(sign * n);
}

/* ************************************************************ */

int abs(int num)
{
  if(num < 0)
    return(-num);
  else
    return(num);
}

/* ************************************************************ */

/* Binary search for string word in table[0] .. table[n-1] */

int binary(char *word, int table[], int n)
{
  int low, high, mid, cond;

  low = 0;
  high = n - 1;
  while(low <= high){
    mid = (low + high) / 2;
    if((cond = strcmp(word, table[mid])) < 0)
      high = mid - 1;
    else if(cond > 0)
      low = mid + 1;
    else
      return(mid);
  }
  return(-1);
}

/* ************************************************************ */

int isalpha(char c)
{
  if((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
    return(1);
  else
    return(0);
}

int isupper(char c)
{
  if(c >= 'A' && c <= 'Z')
    return(1);
  else
    return(0);
}

int islower(char c)
{
  if(c >= 'a' && c <= 'z')
    return(1);
  else
    return(0);
}

int isdigit(char c)
{
  if(c >= '0' && c <= '9')
    return(1);
  else
    return(0);
}

int isspace(char c)
{
  if(c == ' ' || c == '\t' || c == '\n')
    return(1);
  else
    return(0);
}

int toupper(char c)
{
  return((c >= 'a' && c <= 'z') ? c - 32: c);
}

int tolower(char c)
{
  return((c >= 'A' && c <= 'Z') ? c + 32: c);
}


/* ************************************************************ */

/* Index - find index of string t in s */

int index(char *s, char *t)
{
  int i, j, k;

  for(i = 0; s[i] != EOS; i++) {
    k = 0;
    for(j = i; t[k] != EOS && s[j] == t[k]; i++)
      j++;
    if (t[k] == EOS)
      return(i);
  }
  return(-1);
}

/* ************************************************************ */

char *itoa(int n, char *s)
{
  int i, sign;

  if((sign = n) < 0)
    n = -n;
  i = 0;
  do {
    s[i++] = n % 10 + '0';
  } while((n = n/10) > 0);
  if(sign < 0) s[i++] = '-';
  s[i] = EOS;
  reverse(s);
  return(s);
}

/* ************************************************************ */

/* Print a number in any radix */

#define DIGARR "0123456789ABCDEF"

void printn(int number, int radix)
{
  int i;
  char *digitreps;

  if(number < 0 && radix == 10) {
    putchar('-');
    number = -number;
  }
  if((i = number / radix) != 0)
    printn(i, radix); 
  digitreps = DIGARR;
  putchar(digitreps[number % radix]);
}

/* ************************************************************ */

/* Reverse a character string */

char *reverse(char *s)
{
  int i, j;
  char c;

  i = 0;
  j = strlen(s) - 1;
  while(i < j) {
    c = s[i];
    s[i] = s[j];
    s[j] = c;
    i++;
    j--;
  }
  return(s);
}

/* ************************************************************ */

/* Shell sort of string v[0] .... v[n-1] into increasing order */
/* 'int v[]' is actually 'char *v[]' */

void shellsort(int v[], int n)
{
  int gap, i, j;
  char *temp;

  for(gap = n/2; gap > 0; gap = gap / 2)
    for(i = gap; i < n; i++)
      for (j = i - gap; j >= 0; j = j - gap) {
	if(strcmp(v[j], v[j+gap]) <= 0)
	  break;
	temp = v[j];
	v[j] = v[j + gap];
	v[j + gap] = temp;
      }
}

/* ************************************************************ */

/*
 * Concatenate s2 on the end of s1. s1 must be large enough.
 * Return s1.
 */

char *strcat(char *s1, char *s2)
{
  char *os1;

  os1 = s1;
  while(*s1++)
    ;
  *--s1;
  while(*s1++ = *s2++)
    ;
  return(os1);
}

/* ************************************************************ */

/*
 * Compare strings:
 *  s1>s2: >0
 *  s1==s2: 0
 *  s1<s2: <0
 */

int strcmp(char *s1, char *s2)
{
  while(*s1 == *s2++)
    if(*s1++=='\0')
      return(0);
  return(*s1 - *--s2);
}

/* ************************************************************ */

/*
 * Copy string s2 to s1. s1 must be large enough.
 * Return s1
 */

char *strcpy(char *s1, char *s2)
{
  char *os1;

  os1 = s1;
  while(*s1++ = *s2++)
    ;
  return(os1);
}

/* ************************************************************ */

/* Return length of string */

int strlen(char *s)
{
  int i;

  i = 0;
  while(*s++)
    i++;
  return(i);
}

/* ************************************************************ */

/*
 * Concatenate s2 on the end of s1. s1 must be large enough.
 * At most n characters are moved.
 * Return s1.
 */

char *strncat(char *s1, char *s2, int n)
{
  char *os1;

  os1 = s1;
  while(*s1++)
    ;
  --s1;
  while(*s1++ = *s2++)
    if(--n < 0) {
      *--s1 = '\0';
      break;
    }
  return(os1);
}

/* ************************************************************ */

/*
 * Compare strings (at most n bytes):
 *  s1>s2: >0
 *  s1==s2: 0
 *  s1<s2: <0
 */

int strncmp(char *s1, char *s2, int n)
{
  while(--n >= 0 && *s1 == *s2++)
    if (*s1++ == '\0')
      return(0);
  return(n < 0 ? 0 : *s1 - *--s2);
}

/* ************************************************************ */

/*
 * Copy s2 to s1, truncating or null-padding to always copy n bytes.
 * Return s1.
 */

char *strncpy(char *s1, char *s2, int n)
{
  int i;
  char *os1;

  os1 = s1;
  for(i = 0; i < n; i++)
    if((*s1++ = *s2++) == '\0') {
      while(++i < n)
	*s1++ = '\0';
      return(os1);
    }
  return(os1);
}

/* ************************************************************ */

void putchar(char c)
{
#asm
	.globl	.outchar

	LD	HL,#2
	ADD	HL,SP
	LD	A,(HL)
	CALL	.outchar
#easm
}

void puts(char *str)
{
  while (*str)
    putchar(*str++);
  putchar(EOL);
}

void print(char *str)
{
  while (*str)
    putchar(*str++);
}

/* ************************************************************ */

char getchar()
{
}

/* Read a string from the user. s must be long enough! */

char *gets(char *s)
{
#asm
	.globl	.getline

	LD	HL,#2
	ADD	HL,SP
	CALL	.gint
	CALL	.getline		; HL contains the address of s
	LD	HL,#2			; Return the address of s
	ADD	HL,SP
	CALL	.gint
#easm
}
