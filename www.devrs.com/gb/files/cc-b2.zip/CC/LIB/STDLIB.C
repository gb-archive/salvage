#include <stdlib.h>

/* ************************************************************ */

void mode(int m)
{
#asm
	.globl	.setmode

	LD	HL,#2
	ADD	HL,SP
	CALL	.gint		; HL contains m

	CALL	.setmode
#easm
}

/* ************************************************************ */

void delay(int d)
{
#asm
	.globl	.delay_ns

	LD	HL,#2
	ADD	HL,SP
	CALL	.gint		; HL contains d
	LD	B,H
	LD	C,L

	CALL	.delay_ns
#easm
}

void pause(int p)
{
#asm
	.globl	.delay_ms

	LD	HL,#2
	ADD	HL,SP
	CALL	.gint		; HL contains p
	LD	B,H
	LD	C,L

	CALL	.delay_ms
#easm
}

/* ************************************************************ */

int joypad()
{
#asm
	.globl	.jpad

	CALL	.jpad
	LD	H,#0x00		; Return result in HL
	LD	L,A
#easm
}

int waitpad(int mask)
{
#asm
	.globl	.waitpad

	LD	HL,#2
	ADD	HL,SP
	CALL	.gint		; HL contains status
	LD	B,L
	CALL	.waitpad
	LD	H,#0x00		; Return result in HL
	LD	L,A
#easm
}

void waitpadup()
{
#asm
	.globl	.padup

	CALL	.padup
#easm
}

/* ************************************************************ */

void show_bkg()
{
#asm
	LDH		A,(0x40)
	OR		#0x01
	LDH		(0x40),A
#easm
}

void hide_bkg()
{
#asm
	LDH		A,(0x40)
	AND		#0xFF-0x01
	LDH		(0x40),A
#easm
}

/*
 * -128 <= first_tile <= 127
 * -128 <= first_tile+nb_tiles <= 127
 * nb_tiles >= 1
 */
void set_bkg_data(int first_tile, int nb_tiles, char *data)
{
#asm
	.globl	.mv_tiles

	LD	HL,#2
	ADD	HL,SP
	CALL	.gint		; HL contains data
	LD	B,H
	LD	C,L

	LD	HL,#4
	ADD	HL,SP
	CALL	.gint		; HL contains nb_tiles
	ADD	HL,HL		; HL *= 16
	ADD	HL,HL
	ADD	HL,HL
	ADD	HL,HL
	LD	D,H
	LD	E,L

	LD	HL,#6
	ADD	HL,SP
	CALL	.gint		; HL contains first_tile
	ADD	HL,HL		; HL *= 16
	ADD	HL,HL
	ADD	HL,HL
	ADD	HL,HL

	PUSH	BC
	LD	BC,#0x9000
	ADD	HL,BC
	POP	BC
	CALL	.mv_tiles
#easm
}

/*
 * 0 <= x <= 31
 * 0 <= y <= 31
 * 1 <= w <= 32-x
 * 1 <= h <= 32-y
 */
void set_bkg_tiles(int x, int y, int w, int h, char *tilelist)
{
#asm
	.globl	.set_xy_btt

	LD	HL,#8
	ADD	HL,SP
	CALL	.gint		; HL contains y
	LD	E,L

	LD	HL,#10
	ADD	HL,SP
	CALL	.gint		; HL contains x
	LD	D,L

	LD	HL,#4
	ADD	HL,SP
	CALL	.gint		; HL contains h
	LD	C,L

	LD	HL,#6
	ADD	HL,SP
	CALL	.gint		; HL contains w
	LD	B,L

	LD	HL,#2
	ADD	HL,SP
	CALL	.gint		; HL contains tilelist
	PUSH	BC
	LD	B,H
	LD	C,L
	POP	HL

	CALL	.set_xy_btt
#easm
}

void scroll_bkg(int x, int y)
{
#asm
	LD	HL,#2
	ADD	HL,SP
	CALL	.gint		; HL contains y
	LD	A,L
	CP	#0x00
	JR	Z,1$

	LD	B,L
	LDH	A,(0x42)
	ADD	B
	LDH	(0x42),A
1$:
	LD	HL,#4
	ADD	HL,SP
	CALL	.gint		; HL contains x
	LD	D,L
	CP	#0x00
	JR	Z,2$

	LD	B,L
	LDH	A,(0x43)
	ADD	B
	LDH	(0x43),A
2$:
#easm
}

/* ************************************************************ */

void show_sprites()
{
#asm
	LDH		A,(0x40)
	OR		#0x02
	LDH		(0x40),A
#easm
}

void hide_sprites()
{
#asm
	LDH		A,(0x40)
	AND		#0xFF-0x02
	LDH		(0x40),A
#easm
}

void sprites8x8()
{
#asm
	LDH		A,(0x40)
	AND		#0xFF-0x04
	LDH		(0x40),A
#easm
}

void sprites8x16()
{
#asm
	LDH		A,(0x40)
	OR		#0x04
	LDH		(0x40),A
#easm
}

/*
 * 0 <= first_tile <= 255
 * 0 <= first_tile+nb_tiles <= 255
 * nb_tiles >= 1
 */
void set_sprite_data(int first_tile, int nb_tiles, char *data)
{
#asm
	.globl	.mv_tiles

	LD	HL,#2
	ADD	HL,SP
	CALL	.gint		; HL contains data
	LD	B,H
	LD	C,L

	LD	HL,#4
	ADD	HL,SP
	CALL	.gint		; HL contains nb_tiles
	ADD	HL,HL		; HL *= 16
	ADD	HL,HL
	ADD	HL,HL
	ADD	HL,HL
	LD	D,H
	LD	E,L

	LD	HL,#6
	ADD	HL,SP
	CALL	.gint		; HL contains first_tile
	ADD	HL,HL		; HL *= 16
	ADD	HL,HL
	ADD	HL,HL
	ADD	HL,HL

	PUSH	BC
	LD	BC,#0x8000
	ADD	HL,BC
	POP	BC
	CALL	.mv_tiles
#easm
}

/*
 * 0 <= nb <= 39
 * 0 <= tile <= 255
 */
void set_sprite_tile(int nb, int tile)
{
#asm
	.globl	.set_sprite

	LD	HL,#2
	ADD	HL,SP
	CALL	.gint		; HL contains tile
	LD	D,L

	LD	HL,#4
	ADD	HL,SP
	CALL	.gint		; HL contains nb
	LD	C,L

	CALL	.set_sprite
#easm
}

/*
 * 0 <= nb <= 39
 */
void set_sprite_prop(int nb, int prop)
{
#asm
	.globl	.prop_sprite

	LD	HL,#2
	ADD	HL,SP
	CALL	.gint		; HL contains prop
	LD	D,L

	LD	HL,#4
	ADD	HL,SP
	CALL	.gint		; HL contains nb
	LD	C,L

	CALL	.prop_sprite
#easm
}

/*
 * 0 <= nb <= 39
 * 0 <= x <= 255
 * 0 <= y <= 255
 */
void move_sprite(int nb, int x, int y)
{
#asm
	.globl	.mv_sprite

	LD	HL,#2
	ADD	HL,SP
	CALL	.gint		; HL contains y
	LD	E,L

	LD	HL,#4
	ADD	HL,SP
	CALL	.gint		; HL contains x
	LD	D,L

	LD	HL,#6
	ADD	HL,SP
	CALL	.gint		; HL contains nb
	LD	C,L

	CALL	.mv_sprite
#easm
}
