#include <graphics.h>

/* ************************************************************ */

void plot(int x, int y, int color, int mode)
{
#asm
	.globl	.plot

	LD	HL,#2
	ADD	HL,SP
	CALL	.gint		; HL contains mode
	LD	E,L
	LD	HL,#4
	ADD	HL,SP
	CALL	.gint		; HL contains color
	LD	D,L
	LD	HL,#6
	ADD	HL,SP
	CALL	.gint		; HL contains y
	LD	C,L
	LD	HL,#8
	ADD	HL,SP
	CALL	.gint		; HL contains x
	LD	B,L
	CALL	.plot
#easm
}
