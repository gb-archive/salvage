#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#ifndef dos
#ifndef atari
#ifndef unix
#define unix
#endif
#endif
#endif

#ifdef unix
#define CPP "bin/cppGB"
#define SCC "bin/sccGB"
#define AS "bin/asGB"
#define LINK "bin/linkGB"
#define IMG "bin/imgGB"

#define LINK_LIBS " lib/gbrtime.rel"
#endif

#ifdef dos
#define CPP "bin\\cppGB"
#define SCC "bin\\sccGB"
#define AS "bin\\asGB"
#define LINK "bin\\linkGB"
#define IMG "bin\\imgGB"

#define LINK_LIBS " lib\\gbrtime.rel"
#endif

#ifdef atari
#define CPP "bin\\cppGB"
#define SCC "bin\\sccGB"
#define AS "bin\\asGB"
#define LINK "bin\\linkGB"
#define IMG "bin\\imgGB"

#define LINK_LIBS " lib\\gbrtime.rel"
#endif

#define CPP_PARAMS " "
#define SCC_PARAMS " "
#define AS_PARAMS " -lo "
#define LINK_PARAMS " -im -b_CODE=0x200 -b_BSS=0xC000 "
#define IMG_PARAMS " "

#define LINK_LIST "link.lst"

enum {
  UNKNOWN,
  C_FILE,
  CPP_FILE,
  S_FILE,
  REL_FILE,
  IHX_FILE
};

int filetype(char *s);
void usage(char *name);

void main(int argc, char *argv[])
{
  int arg, t;
  char filename[64];
  char command[255];
  char linkcommand[255];
  char imgcommand[255];
  int cflag, sflag;
  FILE *fp;

  if(argc < 2)
    usage(argv[0]);

  strcpy(filename, "cart");
  arg = 1;

  fp = NULL;
  cflag = sflag = 0;
  while(arg < argc && argv[arg][0] == '-') {
    for(t = 1; argv[arg][t] != '\0'; t++) {
      switch(argv[arg][t])
	{
	case 'c':
	case 'C':
	  cflag++;
	  break;

	case 's':
	case 'S':
	  sflag++;
	  break;

	case 'o':
	case 'O':
	  if(++arg >= argc)
	    usage(argv[0]);
	  strcpy(filename, argv[arg]);
	  /* remove extension */
	  filetype(filename);
	  t = strlen(argv[arg]) - 1;
	  break;

	default:
	  usage(argv[0]);
	}
    }
    arg++;
  }

  if(!cflag && !sflag) {
    strcpy(linkcommand, LINK);
    strcat(linkcommand, LINK_PARAMS);
    strcat(linkcommand, filename);
    strcat(linkcommand, ".ihx");
    strcat(linkcommand, LINK_LIBS);

    strcpy(imgcommand, IMG);
    strcat(imgcommand, IMG_PARAMS);
    strcat(imgcommand, filename);
    strcat(imgcommand, ".gb ");
    strcat(imgcommand, filename);
    strcat(imgcommand, ".ihx");
  }

  if(arg >= argc)
    usage(argv[0]);

  arg--;
  while(++arg < argc) {
    strcpy(filename, argv[arg]);
    t = filetype(filename);
    if(t != UNKNOWN) {
      /* PREPROCESS */
      if(t == C_FILE) {
	strcpy(command, CPP);
	strcat(command, CPP_PARAMS);
	strcat(command, filename);
	strcat(command, ".c ");
	strcat(command, filename);
	strcat(command, ".cpp");
	printf("\n-----> %s\n", command);
	if(system(command)) {
	  printf("Error while preprocessing %s\n", argv[arg]);
	  continue;
	}
	t = CPP_FILE;
      }

      /* COMPILE */
      if(t == CPP_FILE) {
	strcpy(command, SCC);
	strcat(command, SCC_PARAMS);
	strcat(command, filename);
	strcat(command, ".cpp");
	printf("\n-----> %s\n", command);
	if(system(command)) {
	  printf("Error while compiling %s\n", argv[arg]);
	  continue;
	}
	t = S_FILE;
      }

      /* ASSEMBLE */
      if(!cflag && t == S_FILE) {
	strcpy(command, AS);
	strcat(command, AS_PARAMS);
	strcat(command, filename);
	strcat(command, ".s");
	printf("\n-----> %s\n", command);
	if(system(command)) {
	  printf("Error while assembling %s\n", argv[arg]);
	  continue;
	}
	t = REL_FILE;
      }

      /* LINK */
      if(!cflag && !sflag && t == REL_FILE) {
	/* Use temporary file since COMMAND.COM doesn't support */
	/* commands bigger than 128 characters! */
	if(fp == NULL) {
	  if((fp = fopen(LINK_LIST, "w")) == NULL) {
	    fprintf(stderr, "Cannot open file "LINK_LIST"\n");
	    exit(1);
	  }
	  strcat(linkcommand, " @"LINK_LIST);
	}
	fprintf(fp, "%s.rel\n", filename);
	t = UNKNOWN;
      }
    } else {
      printf("Unknown file type: %s\n", argv[arg]);
    }
  }

  if(fp != NULL)
    fclose(fp);
  if(!cflag && !sflag) {
    /* LINK */
    printf("\n-----> %s\n", linkcommand);
    if(system(linkcommand)) {
      printf("Error while linking\n");
      exit(1);
    }

    /* IMAGE */
    printf("\n-----> %s\n", imgcommand);
    if(system(imgcommand)) {
      printf("Error while building image\n");
      exit(1);
    }
  }

  exit(0);
}

void usage(char *name)
{
  printf("Usage: %s [-cs] [-o outfile] files...\n", name);
  printf("\t-c\tCompile without assembling\n");
  printf("\t-s\tAssemble without linking\n");
  exit(1);
}

int filetype(char *s)
{
  register int i;
  int t = UNKNOWN;

  i = strlen(s) - 1;
  while(i && s[i] != '.')
    i--;
  if(i++) {
    if(toupper(s[i]) == 'C' && s[i+1] == '\0')
      t = C_FILE;
    else if(toupper(s[i]) == 'C' && toupper(s[i+1]) == 'P' &&
	    toupper(s[i+2]) == 'P' && s[i+3] == '\0')
      t = CPP_FILE;
    else if(toupper(s[i]) == 'S' && s[i+1] == '\0')
      t = S_FILE;
    else if(toupper(s[i]) == 'A' && toupper(s[i+1]) == 'S' &&
	    toupper(s[i+2]) == 'M' && s[i+3] == '\0')
      t = S_FILE;
    else if(toupper(s[i]) == 'R' && toupper(s[i+1]) == 'E' &&
	    toupper(s[i+2]) == 'L' && s[i+3] == '\0')
      t = REL_FILE;
    else if(toupper(s[i]) == 'I' && toupper(s[i+1]) == 'H' &&
	    toupper(s[i+2]) == 'X' && s[i+3] == '\0')
      t = IHX_FILE;
    s[--i] = '\0';
  }
  return(t);
}
