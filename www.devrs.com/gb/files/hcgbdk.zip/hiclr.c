
/* ---  HiClrGBDK v1.1  ---          */
/*                                   */
/* Original RGBDS code by Glen Cook. */
/* Ported to GBDK by Anonymous.      */
/*                                   */
/* Compiled with GBDK v2.1.5         */

#include <gb.h>
#include "highclr.h"

void main()
   {

   if (!CurrentSpeed())
      SwitchSpeed(); // double speed!

   while (1)
      {
      /* First CHAR parameter is the bank number. */
      /* Second CHAR parameter is the button or buttons to continue. */
      DisplayHiclr(1, J_A|J_B);
      DisplayHiclr(2, J_A|J_B);
      }

   }
