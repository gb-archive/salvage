/*
  GBBconv V1.21C - Originally by Micah Dowty (Updated for GBB V1.21 by J.F.)

		This program will convert between binary
		images of Jeff Frohwein's GBbasic's
		battery backed SRAM and a normal text
		file with the program in it.

		Command line switches:

			 GBBCONV operation infile outfile [/A]

			 /A to create autorun file

			 operation =
				 t = convert bin to text (autodetects ssc header)
				 b = convert text to bin without ssc header
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Table of all tokens
#include "tokens.h"

FILE *infile;
FILE *outfile;
struct {
    char id[2];
    char version;
	unsigned int crc;     // Checksum NOT including the header
	unsigned int length;  // Length NOT including the header
}gbbHeader;

int autorun;

#define FILEVERSION '0'   // Functions for version 0
#define REVISION    3
#define MAXPROGSIZE (7680-sizeof(gbbHeader))
			  // So far, max program size is 7.5K- This define
			  // does NOT include header size

void bin2txt(void);   // Binary to text conversion
void txt2bin(void);   // Text to binary conversion

// ***************** MAIN()
void main(int argc, char *argv[]) {

	// good syntax?
	if (argc<4) {
        printf("\n     GBBconv V1.21C, Originally by Micah Dowty, Updated by J.F.\n");
		puts("GBBCONV operation infile outfile [/A]");
		puts("   operation =");
		puts("   t = convert bin to text (autodetects ssc header)");
		puts("   b = convert text to bin without ssc header");
		puts("     /A creates autorun file");
		puts("          If you need a ssc header, use ADDHDR");
		printf( "             Supports format Version %c\n",FILEVERSION);
		exit(1);
	}

	// Flag?
      if (argc>4) {
	switch ((argv[4])[1]) {
	   case 'A':
	     autorun = 1;
	     break;
	   default:
	     puts("Illegal switch!");
	     exit(1);
	}
      }


	// What do we want to do?
	switch (*argv[1]) {
	 case 't':
	 case 'T':
		infile = fopen(argv[2],"rb");
		if (!infile) {
			puts("Error opening input file");
			exit(1);
		}
		outfile = fopen(argv[3],"wt");
		if (!outfile) {
			puts("Error opening output file");
			fclose(infile);
			exit(1);
		}
		bin2txt();
		break;
	 case 'b':
	 case 'B':
		infile = fopen(argv[2],"rt");
		if (!infile) {
			puts("Error opening input file");
			exit(1);
		}
		outfile = fopen(argv[3],"wb");
		if (!outfile) {
			puts("Error opening output file");
			fclose(infile);
			exit(1);
		}
		txt2bin();
		break;
	 default:
		puts("Illegal operation!");
		exit(1);
	}

	fclose(infile);
	fclose(outfile);
}

void bin2txt() {
	long fillength;
	unsigned long i;
	long oldpos;
	unsigned char c;
	int j;
	int done;
	int tokdone;
	int foundit;
	unsigned long crccheck;

	// Is there a ssc header?
	fseek(infile, 0L, SEEK_END);
	fillength = ftell(infile);
	rewind(infile);
	if ((fillength % 8192) == 512)
		// There IS a ssc header- skip it
		fseek(infile, 512L, SEEK_SET);

    /* For some reason the following doesn't work *
     * correctly in Microsoft C/C++ V6.0          */

    //fread(&gbbHeader,sizeof(gbbHeader),1,infile);

    /* The following has to be used instead. */

    fread(&gbbHeader.id[0],1,1,infile);
    fread(&gbbHeader.id[1],1,1,infile);
    fread(&gbbHeader.version,1,1,infile);
    fread(&gbbHeader.crc,2,1,infile);
    fread(&gbbHeader.length,2,1,infile);

	// If any, get rid of autorun flag
	gbbHeader.length &= 0x7FFF;

	// ID ok?
	if (gbbHeader.id[0]!='B' || gbbHeader.id[1]!='F') {
		puts("This is not a GBbasic binary file!");
		return;
	}

	// Verrsion ok?
    if (gbbHeader.version!=FILEVERSION) {
		printf("This GBbasic binary file is version %c! This decoder\n",
                                                    gbbHeader.version);
		printf("is version %c.  Please use the correct decoder.\n",FILEVERSION);
		return;
	}

	// Check CRC
	oldpos = ftell(infile);
	crccheck = 0L;
	for (i=0;i<gbbHeader.length;i++)
		crccheck += getc(infile);
	fseek(infile,oldpos,SEEK_SET);
	if (crccheck!=gbbHeader.crc) {
		puts("This GBbasic binary file has a bad CRC!");
		return;
	}

	// start decoding line by line
	done = 0;
	do {
		if (getc(infile)==1) {done = 1;} // If done, it's End Of program (1),
												  // otherwise it's line length. Don't
												  // need that.

	  else
		{
			// Read the line number
			c = getc(infile);
			i = c+(getc(infile)<<8);

			// Write out the line number
			fprintf(outfile,"%u  ",i);

			// Start decoding token by token
			tokdone = 0;
			do {
				c = getc(infile);
				// Is it a compressed number?
				switch (c) {
				  case 0x0E:
					c = getc(infile);
					i = c+(getc(infile)<<8);
					fprintf(outfile,"%u",i);
					break;
				  case 0x0D:
					// end of line
					tokdone = 1;
					break;
				  default:
					// Can we find the token in the token table?
					foundit = 0;
					for (j=0;j<NUMTOKENS;j++)
						if (tokens[j].value==c) {
							foundit = 1;
							fprintf(outfile,"%s",tokens[j].name);
						}
					if (!foundit)
						putc(c,outfile);  // Not in the table,
												// must be literal
				}
			} while (!tokdone);
			fprintf(outfile,"\n");
		}
	} while (!done);
	puts("Decodeing sucessful!");
}

void txt2bin(void) {
	unsigned char *encodebuf;
	unsigned char linecodbuf[256];  // Buffer for encoding line
	unsigned char linbufdata[300];
	unsigned char *linebuf;
	unsigned char *tempbufptr;
	unsigned int linenum;
	unsigned char nonlit;       // Last non-literal token encoded
	unsigned int bufptr;        // pointer into above buffer
	unsigned int linebufptr;
	unsigned int done,tokdone;
	unsigned int foundit;
	unsigned int bigbufptr;
	unsigned int i,j,k;
	unsigned char c;

	linebuf = linbufdata;
	bigbufptr = nonlit = 0;

	encodebuf = malloc(MAXPROGSIZE);
	if (!encodebuf) {
		printf("Error allocating %d byte encoding buffer!\n",MAXPROGSIZE);
		return;
	}

	done = 0;
	// Encode a line
	while (!done) {
	     if (!fgets(linebuf,299,infile))
	       { done = 1; }
	      else
	       {
		// Separate into line number and the rest.
		linenum = atoi(linebuf);
		linebuf = strchr(linebuf,32);
		// Get rid of excess spaces
		while (*linebuf==32)
			linebuf++;
		// Get rid of /n
                linebuf[strlen(linebuf)-1] = 0;
		// Conv to lowercase- GBBasic programs can only be lowercase
		for (k=0;k<strlen(linebuf);k++)
			linebuf[k] = tolower(linebuf[k]);

		// skip empty lines
               if (*linebuf!=0 && linebuf!=0) {

		//Encode tokens
		linebufptr = bufptr = tokdone = 0;
		nonlit = 0x00;
		do {
			foundit = 0;
			for (i=0;i<NUMTOKENS && (!foundit);i++)
				if (strstr(linebuf+linebufptr,tokens[i].name)==
								linebuf+linebufptr) {
					foundit = 1;
					linebufptr += strlen(tokens[i].name);
					nonlit = tokens[i].value;
					linecodbuf[bufptr++] = tokens[i].value;
				}
			if (foundit==0) {
				c = linebuf[linebufptr++];
				if (c>='0' && c<='9')
					switch (nonlit) {
					  // If there's a number after a...
					  case 0x83:     // GOTO
					  case 0x84:     // GOSUB
					  case 0x8E:     // RESTORE
					  case 0xB2:     // or a THEN...
						// Compress the number
						j = atoi(linebuf+(--linebufptr));
						tempbufptr = strchr(linebuf+linebufptr,32);
						linebufptr = tempbufptr-linebuf;
						if (tempbufptr==NULL) tokdone = 1;
						linecodbuf[bufptr++] = 0x0E;
						linecodbuf[bufptr++] = j;
						linecodbuf[bufptr++] = j>>8;
						break;
					  default:
						linecodbuf[bufptr++] = c;
					}
				  else
					linecodbuf[bufptr++] = c;
			}
		} while (!(tokdone || linebufptr>=strlen(linebuf)));
		// Write out a line to big buffer
		// Are we running out of room?
		if (bigbufptr>(MAXPROGSIZE-(5+bufptr))) {
			puts("Program is too long!");
			return;
		}
		encodebuf[bigbufptr++] = bufptr+4; // Length+4 for header & end
		encodebuf[bigbufptr++] = linenum;
		encodebuf[bigbufptr++] = linenum>>8;
		for (i=0;i<bufptr;i++)
			encodebuf[bigbufptr++] = linecodbuf[i];
		// End-of-line
		encodebuf[bigbufptr++] = 0x0D;
	     } }
	}

	// Write the header
	gbbHeader.id[0] = 'B';
	gbbHeader.id[1] = 'F';
    gbbHeader.version = FILEVERSION;
	gbbHeader.length = bigbufptr+1;  // +1 is to account for end-of-prog.
	if (autorun) gbbHeader.length |= 0x8000;
	gbbHeader.crc = 0;
	for (i=0;i<bigbufptr;i++)
		gbbHeader.crc += encodebuf[i];
	gbbHeader.crc++;                 // End-of-program

    /* For some reason the following doesn't work *
     * correctly in Microsoft C/C++ V6.0          */

    fwrite(&gbbHeader,sizeof(gbbHeader),1,outfile);

    /* The following has to be used instead. */

//    fwrite(&gbbHeader.id[0],1,1,outfile);
//    fwrite(&gbbHeader.id[1],1,1,outfile);
//    fwrite(&gbbHeader.version,1,1,outfile);
//    fwrite(&gbbHeader.crc,2,1,outfile);
//    fwrite(&gbbHeader.length,2,1,outfile);


	// Write the program
	fwrite(encodebuf,bigbufptr,1,outfile);
	putc(1,outfile);  // End-of-program
	for (i=0;i<(8192-(bigbufptr+1)-sizeof(gbbHeader));i++)
		putc(0,outfile);

	printf("Encoding sucessful! %u bytes used.\n",bigbufptr+1);
}
