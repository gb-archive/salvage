

/* Convert a .tga file to GBC format */
/*  By Jeff Frohwein 99-Aug-5 */

/* Compiled with DJGPP. */
/* Allegro graphics library used as well. */

// v1.0 - Original version
// v1.1 - Fixed bug with Y flipped TGA files
// v1.2 - Fixed skewed image on PC screen.
// v1.3 - Added support for 4 color cells

// Color mapping Theory:

//  The method used here by which the GBC is able
// to update the color palettes allows for a screen
// "cell" that is 16 pixels wide by 2 pixels high.
// There are 512 cells on the screen and each cell
// can have 4 unique colors which gives you 2048
// simultaneous colors.

//Method 4
//
//  This particular conversion method divides each
// cell by 8 parts. This leaves 2x2pixel mini-cells.
// The 4 colors in each minicell are averaged and
// the resulting average color is stored in a color
// array.
//
//  The next step is to test all 8 "average" colors
// of each cell and pick the 4 colors out of these
// 8 that are best able to reproduce the original
// picture with the lowest level of error.
//
//  The last step once the 4 ideal colors of each cell
// are known is to render the final picture using
// these colors using a closest color color reduction
// method. No error diffusion is used in this process.

//  When you have several colors in a palette and you
// are trying to figure out which palette color is
// closest to the pixel you are trying to render you
// need to visualize each color as having a position
// in a 3D space. Red value being the X value (as
// an example), green content being the Y value, and
// blue content being the Z value. Colors that are
// most similar to each other will have a minimum
// physical distance between each other in this 3D
// space. So to figure out how close one color is
// to another you just use the 3D distance formula:

// D=sqrt( (abs(x1-x2))^2 + (abs(y2-y1))^2 (abs(z2-z1))^2 )

#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <math.h>
#include <allegro.h>

unsigned char pic[128][128][3];
unsigned char out[128][128];
int avgr,avgg,avgb;
int Pal[8][64][8][3];
int IdealPal[8][64][4][3];
int ShowPic = 0;
char fname[20];
char fname2[20];
int p1,p2,p3,p4;

void WriteData (void)
   {

   FILE *fpo;
   int ch = '.';

   /* Remove any extension from the output file name */
   if (strchr(fname,ch) != NULL)
      fname[strlen(fname)-4] = 0;

   strcpy(fname2,fname);
   strcat(fname2, ".til");

   if ((fpo = fopen(fname2, "wb")) == NULL)
      {
      printf("Error writing to file.\n");
      }
   else
      {
      unsigned char c,c1,c2;
      int x,y,dx,dy;

      for (y=0; y<128; y=y+8)
         {
         for (x=0; x<128; x=x+8)
            {
            for (dy=0; dy<8; dy++)
               {
               c1 = 0;
               c2 = 0;
               for (dx=0; dx<8; dx++)
                  {
                  c1 = c1 * 2;
                  c2 = c2 * 2;
                  c = out[x+dx][y+dy];
                  if (c & 2) c1++;
                  if (c & 1) c2++;
                  }

               fputc(c2,fpo);
               fputc(c1,fpo);
//               fputc(c2,fpo);
               }
            }
         }

      (void) fclose(fpo);
      }

   strcpy(fname2,fname);
   strcat(fname2, ".pal");

   if ((fpo = fopen(fname2, "wb")) == NULL)
      {
      printf("Error writing to file.\n");
      }
   else
      {
      int x,y,r,g,b,v;

      for(y=0; y<128; y=y+2)
         {
         for(x=0; x<128; x=x+4)
            {
            r = IdealPal[x/16][y/2][(x/4)&3][0];
            g = IdealPal[x/16][y/2][(x/4)&3][1];
            b = IdealPal[x/16][y/2][(x/4)&3][2];

            v = ((b/8)*32*32) + ((g/8)*32) + (r/8);

            fputc(v&255,fpo);
            fputc(v/256,fpo);
            }
         }

      // Write out another 16 colors for last left line.
      // These extra colors are needed due to the color
      // interleave needed by the GBC.

      y--;

      for(x=0; x<64; x=x+4)
         {
         r = IdealPal[x/16][y/2][(x/4)&3][0];
         g = IdealPal[x/16][y/2][(x/4)&3][1];
         b = IdealPal[x/16][y/2][(x/4)&3][2];

         v = ((b/8)*32*32) + ((g/8)*32) + (r/8);

         fputc(v&255,fpo);
         fputc(v/256,fpo);
         }

      (void) fclose(fpo);
      }

   }

void AddPixels (int xs, int ys, int width, int height)
   {
   int cnt = 0;
   int x,y;
   int offset = 0;
   int h = height;

   // Only add one row of pixels if in the
   // upper left corner. This is due to the
   // color interleave on the GB.

//   if (xs<64)
//      {
//      offset = 1;
//      if (ys == 0)
//         {
//         h = 1;
//         offset = 0;
//         }
//      }


   avgr = avgg = avgb = 0;

   for (y=0; y<h; y++)
      {
      for(x=0; x<width; x++)
         {
         avgr += pic[xs+x][ys+y-offset][0];
         avgg += pic[xs+x][ys+y-offset][1];
         avgb += pic[xs+x][ys+y-offset][2];
         cnt++;
         }
      }

   avgr /= cnt;
   avgg /= cnt;
   avgb /= cnt;
   }

#define YPOS 25
#define XPOS 25

void Method1 (void)
   {
   int x,y;

   for (y=0; y<128; y=y+2)
      {
      for(x=0; x<128; x=x+4)
         {
         AddPixels(x,y,4,2);

         rectfill(screen, XPOS+x+2+143,   YPOS+y+2,
                          XPOS+x+2+143+3, YPOS+y+3, makecol(avgr,avgg,avgb));
         }
//      putpixel (screen, XPOS+x+2+143, YPOS+y+2, makecol(r,g,b));
      }
   }

void Method2 (void)
   {
   int x,y;

   // Generate the palette
   for (y=0; y<128; y=y+2)
      {
      for(x=0; x<128; x=x+2)
         {
         AddPixels(x,y,2,2);
         Pal[x/16][y/2][(x/8)&7][0] = avgr;
         Pal[x/16][y/2][(x/8)&7][1] = avgg;
         Pal[x/16][y/2][(x/8)&7][2] = avgb;
         rectfill(screen, XPOS+x+2+143,   YPOS+y+2,
                          XPOS+x+2+143+1, YPOS+y+3, makecol(avgr,avgg,avgb));
         }
//      putpixel (screen, XPOS+x+2+143, YPOS+y+2, makecol(r,g,b));
      }
   }

void Method3 (void)
   {
   int closest,pick;
   int a1,b1,c1,d1,r,g,b,x,y;

   // Generate the palette
   for (y=0; y<128; y=y+2)
      {
      for(x=0; x<128; x=x+4)
         {
         AddPixels(x,y,4,2);
         Pal[x/16][y/2][(x/4)&3][0] = avgr;
         Pal[x/16][y/2][(x/4)&3][1] = avgg;
         Pal[x/16][y/2][(x/4)&3][2] = avgb;
//         rectfill(screen, XPOS+x+2+143,   YPOS+y+2,
//                          XPOS+x+2+143+3, YPOS+y+3, makecol(avgr,avgg,avgb));
         }
//      putpixel (screen, XPOS+x+2+143, YPOS+y+2, makecol(r,g,b));
      }

   // Closest color render using palettes
   for (y=0; y<128; y++)
      {
      for(x=0; x<128; x++)
         {

  a1=sqrt( (fabs(Pal[x/16][y/2][0][0]-(int)pic[x][y][0]) * fabs(Pal[x/16][y/2][0][0]-(int)pic[x][y][0])) +
           (fabs(Pal[x/16][y/2][0][1]-(int)pic[x][y][1]) * fabs(Pal[x/16][y/2][0][1]-(int)pic[x][y][1])) +
           (fabs(Pal[x/16][y/2][0][2]-(int)pic[x][y][2]) * fabs(Pal[x/16][y/2][0][2]-(int)pic[x][y][2])) );

  b1=sqrt( (fabs(Pal[x/16][y/2][1][0]-(int)pic[x][y][0]) * fabs(Pal[x/16][y/2][1][0]-(int)pic[x][y][0])) +
           (fabs(Pal[x/16][y/2][1][1]-(int)pic[x][y][1]) * fabs(Pal[x/16][y/2][1][1]-(int)pic[x][y][1])) +
           (fabs(Pal[x/16][y/2][1][2]-(int)pic[x][y][2]) * fabs(Pal[x/16][y/2][1][2]-(int)pic[x][y][2])) );

  c1=sqrt( (fabs(Pal[x/16][y/2][2][0]-(int)pic[x][y][0]) * fabs(Pal[x/16][y/2][2][0]-(int)pic[x][y][0])) +
           (fabs(Pal[x/16][y/2][2][1]-(int)pic[x][y][1]) * fabs(Pal[x/16][y/2][2][1]-(int)pic[x][y][1])) +
           (fabs(Pal[x/16][y/2][2][2]-(int)pic[x][y][2]) * fabs(Pal[x/16][y/2][2][2]-(int)pic[x][y][2])) );

  d1=sqrt( (fabs(Pal[x/16][y/2][3][0]-(int)pic[x][y][0]) * fabs(Pal[x/16][y/2][3][0]-(int)pic[x][y][0])) +
           (fabs(Pal[x/16][y/2][3][1]-(int)pic[x][y][1]) * fabs(Pal[x/16][y/2][3][1]-(int)pic[x][y][1])) +
           (fabs(Pal[x/16][y/2][3][2]-(int)pic[x][y][2]) * fabs(Pal[x/16][y/2][3][2]-(int)pic[x][y][2])) );

         closest = d1;
         pick = 3;

         if (c1 < closest)
            {
            closest = c1;
            pick = 2;
            }

         if (b1 < closest)
            {
            closest = b1;
            pick = 1;
            }

         if (a1 < closest)
            {
            closest = a1;
            pick = 0;
            }

         r = Pal[x/16][y/2][pick][0];
         g = Pal[x/16][y/2][pick][1];
         b = Pal[x/16][y/2][pick][2];

         putpixel (screen, XPOS+x+2+143, YPOS+y+2, makecol(r,g,b));
         }
      }
   }

   // Closest color render using palettes.
   // Reduce 8 colors to 4 in each palette.
   // Using the 4 colors that produce the smallest
   //  error in the resulting pixels.

void Reduce8to4 (int x, int y, int os)
   {
   int closest,pick;
   int SmallestError = 0xffffff;  //pick a large number
   int a1,b1,c1,d1;
   int m1,m2,m3,m4;
   int dx,dy,cx,cy;

   int x2 = x/16;
   int y2 = y/2;

   for(m4=0; m4<8; m4++)
      for(m3=0; m3<8; m3++)
         for(m2=0; m2<8; m2++)
            for(m1=0; m1<8; m1++)
               if ( (m4 > m3) &&
                    (m3 > m2) &&
                    (m2 > m1) )
                  {
                  int ErrorTerm = 0;

                  for(dy=0; dy<2; dy++)
                     {
                     for(dx=0; dx<16; dx++)
                        {

                        cx = x+dx;
                        cy = y-os+dy;

//           if (pic[cx][cy][0] != 0)
//              printf("%d,%d,%d\n",pic[cx][cy][0],
//                               Pal[x2][y2][m1][1],
//                               Pal[x2][y2][m1][2]);

  a1=sqrt( (fabs(Pal[x2][y2][m1][0]-(int)pic[cx][cy][0]) * fabs(Pal[x2][y2][m1][0]-(int)pic[cx][cy][0])) +
           (fabs(Pal[x2][y2][m1][1]-(int)pic[cx][cy][1]) * fabs(Pal[x2][y2][m1][1]-(int)pic[cx][cy][1])) +
           (fabs(Pal[x2][y2][m1][2]-(int)pic[cx][cy][2]) * fabs(Pal[x2][y2][m1][2]-(int)pic[cx][cy][2])) );

  b1=sqrt( (fabs(Pal[x2][y2][m2][0]-(int)pic[cx][cy][0]) * fabs(Pal[x2][y2][m2][0]-(int)pic[cx][cy][0])) +
           (fabs(Pal[x2][y2][m2][1]-(int)pic[cx][cy][1]) * fabs(Pal[x2][y2][m2][1]-(int)pic[cx][cy][1])) +
           (fabs(Pal[x2][y2][m2][2]-(int)pic[cx][cy][2]) * fabs(Pal[x2][y2][m2][2]-(int)pic[cx][cy][2])) );

  c1=sqrt( (fabs(Pal[x2][y2][m3][0]-(int)pic[cx][cy][0]) * fabs(Pal[x2][y2][m3][0]-(int)pic[cx][cy][0])) +
           (fabs(Pal[x2][y2][m3][1]-(int)pic[cx][cy][1]) * fabs(Pal[x2][y2][m3][1]-(int)pic[cx][cy][1])) +
           (fabs(Pal[x2][y2][m3][2]-(int)pic[cx][cy][2]) * fabs(Pal[x2][y2][m3][2]-(int)pic[cx][cy][2])) );

  d1=sqrt( (fabs(Pal[x2][y2][m4][0]-(int)pic[cx][cy][0]) * fabs(Pal[x2][y2][m4][0]-(int)pic[cx][cy][0])) +
           (fabs(Pal[x2][y2][m4][1]-(int)pic[cx][cy][1]) * fabs(Pal[x2][y2][m4][1]-(int)pic[cx][cy][1])) +
           (fabs(Pal[x2][y2][m4][2]-(int)pic[cx][cy][2]) * fabs(Pal[x2][y2][m4][2]-(int)pic[cx][cy][2])) );

                        closest = d1;
                        pick = 3;

                        if (c1 < closest)
                           {
                           closest = c1;
                           pick = 2;
                           }

                        if (b1 < closest)
                           {
                           closest = b1;
                           pick = 1;
                           }

                        if (a1 < closest)
                           {
                           closest = a1;
                           pick = 0;
                           }

                        ErrorTerm += closest;

                        }
                     }

                  if (ErrorTerm < SmallestError)
                     {
                     SmallestError = ErrorTerm;
                     p1 = m1;
                     p2 = m2;
                     p3 = m3;
                     p4 = m4;
                     }
                  }

   IdealPal[x2][y2][0][0] = Pal[x2][y2][p1][0];
   IdealPal[x2][y2][0][1] = Pal[x2][y2][p1][1];
   IdealPal[x2][y2][0][2] = Pal[x2][y2][p1][2];

   IdealPal[x2][y2][1][0] = Pal[x2][y2][p2][0];
   IdealPal[x2][y2][1][1] = Pal[x2][y2][p2][1];
   IdealPal[x2][y2][1][2] = Pal[x2][y2][p2][2];

   IdealPal[x2][y2][2][0] = Pal[x2][y2][p3][0];
   IdealPal[x2][y2][2][1] = Pal[x2][y2][p3][1];
   IdealPal[x2][y2][2][2] = Pal[x2][y2][p3][2];

   IdealPal[x2][y2][3][0] = Pal[x2][y2][p4][0];
   IdealPal[x2][y2][3][1] = Pal[x2][y2][p4][1];
   IdealPal[x2][y2][3][2] = Pal[x2][y2][p4][2];

   }

int CountColorsInCell(int x, int y, int os)
   {
   int c,cx,cy,dx,dy;
   int count = 0;
   int found;
   int t[33][3];

   for (dy=0; dy<2; dy++)
      {
      for (dx=0; dx<16; dx++)
         {
         cx = x+dx;
         cy = y-os+dy;

         found = 0;

         for (c=0; c<count; c++)
            {
            if ( (pic[cx][cy][0] == t[c][0]) &&
                 (pic[cx][cy][1] == t[c][1]) &&
                 (pic[cx][cy][2] == t[c][2]) )
               found = 1;
            }

         if (found == 0)
            {
            t[count][0] = pic[cx][cy][0];
            t[count][1] = pic[cx][cy][1];
            t[count][2] = pic[cx][cy][2];
            count++;
            }

         }
      }

//   printf("%d ",count);

   return(count);
   }

void GetFourColors (int x, int y, int os)
   {
   int cx,cy,dx,dy;
   int state = 0;
   int x2 = x/16;
   int y2 = y/2;

   for(dy=0; dy<2; dy++)
      {
      for(dx=0; dx<16; dx++)
         {
         cx = x+dx;
         cy = y-os+dy;

         switch (state)
            {
            case 0 :
               // Get color #1
               IdealPal[x2][y2][0][0] = pic[cx][cy][0];
               IdealPal[x2][y2][0][1] = pic[cx][cy][1];
               IdealPal[x2][y2][0][2] = pic[cx][cy][2];
               state++;
               break;
            case 1 :
               // Get color #2
               if ( (pic[cx][cy][0] != IdealPal[x2][y2][0][0]) ||
                    (pic[cx][cy][1] != IdealPal[x2][y2][0][1]) ||
                    (pic[cx][cy][2] != IdealPal[x2][y2][0][2]) )
                  {
                  IdealPal[x2][y2][1][0] = pic[cx][cy][0];
                  IdealPal[x2][y2][1][1] = pic[cx][cy][1];
                  IdealPal[x2][y2][1][2] = pic[cx][cy][2];
                  state++;
                  }
               break;
            case 2 :
               // Get color #3
               if (( (pic[cx][cy][0] != IdealPal[x2][y2][0][0]) ||
                     (pic[cx][cy][1] != IdealPal[x2][y2][0][1]) ||
                     (pic[cx][cy][2] != IdealPal[x2][y2][0][2]) ) &&

                   ( (pic[cx][cy][0] != IdealPal[x2][y2][1][0]) ||
                     (pic[cx][cy][1] != IdealPal[x2][y2][1][1]) ||
                     (pic[cx][cy][2] != IdealPal[x2][y2][1][2]) ))
                  {
                  IdealPal[x2][y2][2][0] = pic[cx][cy][0];
                  IdealPal[x2][y2][2][1] = pic[cx][cy][1];
                  IdealPal[x2][y2][2][2] = pic[cx][cy][2];
                  state++;
                  }
               break;
            case 3 :
               // Get color #4
               if (( (pic[cx][cy][0] != IdealPal[x2][y2][0][0]) ||
                     (pic[cx][cy][1] != IdealPal[x2][y2][0][1]) ||
                     (pic[cx][cy][2] != IdealPal[x2][y2][0][2]) ) &&

                   ( (pic[cx][cy][0] != IdealPal[x2][y2][1][0]) ||
                     (pic[cx][cy][1] != IdealPal[x2][y2][1][1]) ||
                     (pic[cx][cy][2] != IdealPal[x2][y2][1][2]) ) &&

                   ( (pic[cx][cy][0] != IdealPal[x2][y2][2][0]) ||
                     (pic[cx][cy][1] != IdealPal[x2][y2][2][1]) ||
                     (pic[cx][cy][2] != IdealPal[x2][y2][2][2]) ))
                  {
                  IdealPal[x2][y2][3][0] = pic[cx][cy][0];
                  IdealPal[x2][y2][3][1] = pic[cx][cy][1];
                  IdealPal[x2][y2][3][2] = pic[cx][cy][2];
                  state++;
                  }
               break;
            }
         }
      }
   }

void Method4 (void)
   {
   int closest;  //,pick;
   int a1,b1,c1,d1,r,g,b,x,y,dx,dy;
   int cx,cy,x2,y2;

   // Generate the palette
   for (y=0; y<128; y=y+2)
      {
      for(x=0; x<128; x=x+2)
         {
         AddPixels(x,y,2,2);
         Pal[x/16][y/2][(x/2)&7][0] = avgr;
         Pal[x/16][y/2][(x/2)&7][1] = avgg;
         Pal[x/16][y/2][(x/2)&7][2] = avgb;
//         rectfill(screen, XPOS+x+2+143,   YPOS+y+2,
//                          XPOS+x+2+143+3, YPOS+y+3, makecol(avgr,avgg,avgb));
         }
//      putpixel (screen, XPOS+x+2+143, YPOS+y+2, makecol(r,g,b));
      }

   // Closest color render using palettes.
   // Reduce 8 colors to 4 in each palette.
   // Using the 4 colors that produce the smallest
   //  error in the resulting pixels.

   for (y=0; y<128; y=y+2)
      {
      for(x=0; x<128; x=x+16)
         {
         int os = 0;

         p1 = 0;
         p2 = 0;
         p3 = 0;
         p4 = 0;

         if (x<64) os=1;

         x2 = x/16;
         y2 = y/2;

         if (CountColorsInCell(x,y,os) > 4)
            Reduce8to4(x,y,os);
         else
            GetFourColors(x,y,os);

         // We now have the 4 ideal colors in our palette.
         // Now closest color render this cell using this
         // ideal palette.

         for(dy=0; dy<2; dy++)
            {
            for(dx=0; dx<16; dx++)
               {
               unsigned char gbcolor;

               cx = x+dx;
               cy = y-os+dy;

  a1=sqrt( (fabs(IdealPal[x2][y2][0][0]-(int)pic[cx][cy][0]) * fabs(IdealPal[x2][y2][0][0]-(int)pic[cx][cy][0])) +
           (fabs(IdealPal[x2][y2][0][1]-(int)pic[cx][cy][1]) * fabs(IdealPal[x2][y2][0][1]-(int)pic[cx][cy][1])) +
           (fabs(IdealPal[x2][y2][0][2]-(int)pic[cx][cy][2]) * fabs(IdealPal[x2][y2][0][2]-(int)pic[cx][cy][2])) );

  b1=sqrt( (fabs(IdealPal[x2][y2][1][0]-(int)pic[cx][cy][0]) * fabs(IdealPal[x2][y2][1][0]-(int)pic[cx][cy][0])) +
           (fabs(IdealPal[x2][y2][1][1]-(int)pic[cx][cy][1]) * fabs(IdealPal[x2][y2][1][1]-(int)pic[cx][cy][1])) +
           (fabs(IdealPal[x2][y2][1][2]-(int)pic[cx][cy][2]) * fabs(IdealPal[x2][y2][1][2]-(int)pic[cx][cy][2])) );

  c1=sqrt( (fabs(IdealPal[x2][y2][2][0]-(int)pic[cx][cy][0]) * fabs(IdealPal[x2][y2][2][0]-(int)pic[cx][cy][0])) +
           (fabs(IdealPal[x2][y2][2][1]-(int)pic[cx][cy][1]) * fabs(IdealPal[x2][y2][2][1]-(int)pic[cx][cy][1])) +
           (fabs(IdealPal[x2][y2][2][2]-(int)pic[cx][cy][2]) * fabs(IdealPal[x2][y2][2][2]-(int)pic[cx][cy][2])) );

  d1=sqrt( (fabs(IdealPal[x2][y2][3][0]-(int)pic[cx][cy][0]) * fabs(IdealPal[x2][y2][3][0]-(int)pic[cx][cy][0])) +
           (fabs(IdealPal[x2][y2][3][1]-(int)pic[cx][cy][1]) * fabs(IdealPal[x2][y2][3][1]-(int)pic[cx][cy][1])) +
           (fabs(IdealPal[x2][y2][3][2]-(int)pic[cx][cy][2]) * fabs(IdealPal[x2][y2][3][2]-(int)pic[cx][cy][2])) );

               closest = d1;
//               pick = p4;
               gbcolor = 3;

               if (c1 < closest)
                  {
                  closest = c1;
//                  pick = p3;
                  gbcolor = 2;
                  }

               if (b1 < closest)
                  {
                  closest = b1;
//                  pick = p2;
                  gbcolor = 1;
                  }

               if (a1 < closest)
                  {
                  closest = a1;
//                  pick = p1;
                  gbcolor = 0;
                  }

               r = IdealPal[x2][y2][gbcolor][0];
               g = IdealPal[x2][y2][gbcolor][1];
               b = IdealPal[x2][y2][gbcolor][2];

               if ((ShowPic) && (((y+dy) !=0) || (x>63)))
                  {
                  putpixel (screen, XPOS+x+dx+2+143, YPOS+y-os+dy+2, makecol(r,g,b));

                  if ((x<64)  && (y == 126))
                     putpixel (screen, XPOS+x+dx+2+143, YPOS+y-os+dy+3, makecol(r,g,b));

                  }

               if ((y-os+dy) >= 0)
                  out[x+dx][y-os+dy] = gbcolor;

               }
            }

         }
      }
   WriteData();
   }

void Render (int i)
   {
   switch (i)
      {
      case 0x31 :
         Method1();
         break;
      case 0x32 :
         Method2();
         break;
      case 0x33 :
         Method3();
         break;

      default:
         Method4();
      }
   }

void main (int argc, char **argv)
   {
   FILE *fpi;
   char c1;

   char OrigStr[] = "Original";
   char GBCStr[] = "GBC Version";
   char DoneStr[] = "Press ESC to exit.";

   int i,x,y,r,g,b;
   int cnt = 0;
   int XSize, YSize, BitDepth, FileType;
   int yflip = 0;

   /* Get start position from command line */

   if ( argc > 1)
      {
      if (argv[1][0] == 0x2d)
         strcpy(fname, argv[2]);
      else
        {
        strcpy(fname, argv[1]);
        ShowPic = 1;
        }
      }
   else
      {
      printf("** tga2gbc v1.3 **, by Jeff F., 99-Aug-5\n");
      printf("  - Convert a .tga file to GBC format.\n");
      printf("\n");
      printf("Input file must be a 24 bit uncompressed tga.\n");
      printf("\n");
      printf("Usage: tga2gbc [options] infile\n");
      printf("\n");
      printf("  Options:\n");
      printf("   -t    Text mode (No VESA graphics display.)\n");
      printf("\n");
      printf("NOTE: To use in non-text mode your video card must support\n");
      printf("      24 bit graphics using VESA video bios.\n");


      exit(1);
      }

   if ((fpi = fopen(fname, "rb")) == NULL)
      {
      printf("Error opening file '%s'\n", fname);
      exit(1);
      }
   else
      printf("Reading from file '%s'\n", fname);

   c1 = fgetc(fpi);
   c1 = fgetc(fpi);
   FileType = fgetc(fpi);

   /* Skip over any leading unwanted bytes */

   while ( (feof(fpi) == 0) &&
            (cnt < 9) )
      {
      c1 = fgetc(fpi);
      cnt++;
//      printf("%x ",c1);
      }

   XSize = fgetc(fpi);
   XSize += (fgetc(fpi) * 256);

   YSize = fgetc(fpi);
   YSize += (fgetc(fpi) * 256);

   BitDepth = fgetc(fpi);
   c1 = (fgetc(fpi));

   if (c1 & 0x20)
      yflip = 1;

   if ( (FileType != 2) ||
        (XSize != 128) ||
        (YSize != 128) ||
        (BitDepth != 24) )
      {
      if (FileType != 2)
         {
         if (FileType == 10)
            printf("File must be uncompressed!\n");
         else
            {
            printf("This file is not a tga file!\n");
            exit(1);
            }
         }
      if (XSize != 128)
         printf("X width of tga file must be 128!\n");
      if (YSize != 128)
         printf("Y height of tga file must be 128!\n");
      if (BitDepth != 24)
         printf("Color depth of file must be 24 bit!\n");

      exit(1);
      }

   if (ShowPic)
      {
      set_color_depth(24);

      set_gfx_mode (GFX_AUTODETECT, 320, 200, 0, 0);

      // Draw left box & fill it

      rect(screen, XPOS, YPOS, XPOS+131, YPOS+131, makecol(128,128,128) );
      }

   for (y=0; y<128; y++)
      {
      for (x=0; x<128; x++)
         {
         int y1 = 127-y;

         b=fgetc(fpi);
         g=fgetc(fpi);
         r=fgetc(fpi);
         if (yflip)
            y1 = y;
         pic[x][y1][0] = r & 0xf8;
         pic[x][y1][1] = g & 0xf8;
         pic[x][y1][2] = b & 0xf8;

         if (ShowPic)
            putpixel (screen, XPOS+x+2, YPOS+2+y1, makecol(r,g,b));

         }
      }

   if (ShowPic)
      {
      textout(screen, font, OrigStr, 60, 160, makecol(128,128,128));

      // Draw right box

      rect(screen, XPOS+143, YPOS, XPOS+143+131, YPOS+131, makecol(128,128,128) );

      textout(screen, font, GBCStr, 190, 160, makecol(128,128,128));
      }



   i=0x34;

   do
      {
      Render(i);

      if (ShowPic)
         {
         textout(screen, font, DoneStr, 100, 185, makecol(128,128,128));

         i=getch();
         }
      }
   while ((i!=27) && (ShowPic));

   fclose(fpi);

   if (ShowPic)
      allegro_exit();

   exit(0);
   }