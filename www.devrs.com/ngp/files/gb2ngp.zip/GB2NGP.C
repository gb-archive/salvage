
/* Convert GameBoy tiles to/from NeoGeo Pocket format */

/* Compiled/tested with DJGPP for DOS & GCC for Linux */

// v1.0 - 00-May-26 - Original version
// v1.1 - 00-May-26 - Now provides warning for non-16 byte boundary input files

#include <stdio.h>
#include <string.h>
//#include <conio.h>

#ifdef __MSDOS__
#include <io.h>
#include <fcntl.h>
#endif

// cast
int atoi (const char *);


void gb2ngp (FILE *fpi,
             FILE *fpo,
             int filesize)
   {
   int i, j, c1, c2;
   unsigned int val;
   int clr;

   for (i=0; i < filesize; i+=2)
      {
      // handle 2 bytes at a time
      c1 = getc(fpi);
      c2 = getc(fpi);
      val = 0;

      for (j=0; j<8; j++)
         {
         if (c1 & 0x80) clr=1; else clr=0;
         if (c2 & 0x80) clr+=2;

         val <<= 2;
         val +=clr;

         c1 <<= 1;
         c2 <<= 1;
         }

      putc(val & 0xff, fpo);
      putc(val >> 8, fpo);

      }
   }

void ngp2gb (FILE *fpi,
             FILE *fpo,
             int filesize)
   {
   int i, j, c1, c2;
   unsigned int val = 0;
   int clr;
   int out1;
   int out2;

   for (i=0; i < filesize; i+=2)
      {
      // handle 2 bytes at a time
      c1 = getc(fpi);
      c2 = getc(fpi);
      val = ((c2 & 0xff) <<8) + (c1 & 0xff);

      out1 = 0;
      out2 = 0;

      for (j=0; j<8; j++)
         {
         clr = val >> 14;

         val <<= 2;
         out1 <<= 1;
         out2 <<= 1;

         if (clr & 1) out1++;
         if (clr & 2) out2++;
         }

      putc(out1, fpo);
      putc(out2, fpo);
      }
   }

void usage (int ExitCode)
   {
   fprintf(stderr, "** gb2ngp v1.1 **, by jeff@devrs.com, 00-May-26\n");
   fprintf(stderr, "  - Convert raw GameBoy <-> NeoGeo Pocket tile data.\n");
   fprintf(stderr, "\n");
   fprintf(stderr, " Usage: b2x [-h] [-n] < in_file > out_file\n\n");
   fprintf(stderr, " Options:\n");
   fprintf(stderr, "  -h = This help screen\n");
   fprintf(stderr, "  -n = Convert ngp2gb (default=gb2ngp)\n");

   exit (ExitCode);
   }

int main(int argc, char **argv)
   {
   int datacount = 0;
   int c; //,peek;
   int arg;
   int n2g = 0;

#ifdef __MSDOS__
   // Needed by DOS to force binary STDIN & STDOUT mode
//   _fmode = O_BINARY;
   (void) setmode(fileno(stdin), O_BINARY);
   (void) setmode(fileno(stdout), O_BINARY);
#endif

   for (arg = 1; arg < (argc); arg++)    //-2
      {

      /* If invalid command line character then exit */
      if ( (argv[arg][0] != '-') ||
           (strlen(argv[arg]) != 2 ) )
         usage(1);

      switch (argv[arg][1])
         {
         case 'h':
         case 'H':
            usage(1);
            break;
         case 'n':
            n2g = 1;
            break;

//         case 'z':
//            strcpy(id, argv[++arg]);
//            break;

         default:
            usage(1);
         }
      }

   /* Get file length */
   while ((c = getc (stdin)) != EOF)
      datacount++;
//      while (feof(stdin)==0)
//         {
//         (void) fgetc(stdin);
//         datacount++;
//         }
//      datacount--;

   rewind (stdin);

   // If odd sized file then give warning
   if (datacount & 0xf)
      fprintf(stderr, "gb2ngp warning: Input stream/file should be multiple of 16 bytes\n");


   if (n2g)
      ngp2gb (stdin,stdout,datacount);
   else
      gb2ngp (stdin,stdout,datacount);

   exit(0);
   }