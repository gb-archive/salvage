//  Term.h
//
//  Main module of the application.
//

#ifndef __STP_H__
#define __STP_H__

#include "CyWin.h"
#include "Cybiko.h"
#include "comport.h"

#define CURSOR_CHAR  0x5f               // Underscore

struct module_t main_module;           //  Main module of the application.
struct cDialog player_dialog;          //  CyWin dialog object.
//struct score_t high_scores[1];         //  High scores of the game.
//struct DirectKeyboard* ptr_direct_keyboard;
struct Font TermFont;
int FontSize;

bool ExitTerminal;                //  TRUE if ready to exit.

int ScrnBuf[80][25];
com_t SerialPort;
struct COMMConfig SerialConfig;
struct COMMConfig SaveSerialConfig;
char sz_menu_text2[7][10];

bool clicks_state;

int CursorX,CursorY;
int ScreenWidth, ScreenHeight;
int FontWidth, FontHeight;
char HandShake;                          // 0 = None, 1 = CTS, 2 =XON/OFF
int LocalEcho;
char EscapeState;

void CheckSerialIn (void);
void DisplayChar (int);
void ProcessChar (int);
void RedrawScreen (void);
void OpenSession (void);
void CloseSession (void);
void SendChar (int);
void OptionsScreen (void);
void SetTermFont (void);
void WriteConfigFile (void);
int ProcessShift (int, int);
void ShowCursor (void);
void InitSerial (void);

#endif