
//  Main form of the application.
struct cFrameForm* ptr_main_form;

//  Main menu of the application.
struct cList* ptr_main_menu;

///////////////////////////////////////////////////////
//               Shows main form of                  //
//                the application                    //
///////////////////////////////////////////////////////
int cMainForm_ShowModal(struct cFrameForm* ptr_form);

///////////////////////////////////////////////////////
//            Processes messages of the              //
//                   main form.                      //
///////////////////////////////////////////////////////
bool cMainForm_proc(struct cFrameForm* ptr_form, struct Message* ptr_message);

///////////////////////////////////////////////////////
//              Creates main menu of                 //
//                the application.                   //
///////////////////////////////////////////////////////
struct cList* cMenuList_ctor(struct cList* ptr_menu, int width);

void cMyApp_dtor(struct cWinApp* ptr_win_app);

///////////////////////////////////////////////////////
//          Initializes application's                //
//                   objects.                        //
///////////////////////////////////////////////////////
struct cWinApp* cMyApp_ctor(struct cWinApp* ptr_win_app)
{
//  bitmap_x = 0;
//  bitmap_y = 0;

  //  Initializes music sequence from the file "cybiko.mus".
//  MSequence_ctor(&cybiko_music, "cybiko.mus");

  //  Creates the application's main form
  //  with the "Graphics Tutorial" caption.
  ptr_main_form = malloc(sizeof(struct cFrameForm));
  cFrameForm_ctor(ptr_main_form, "Terminal Settings", ptr_win_app);

  //  Creates main menu of the application.
  ptr_main_menu = (struct cList*)malloc(sizeof(struct cList));
  cMenuList_ctor(ptr_main_menu, 160-4);

  //  Adds menu to the main form.
  cFrameForm_AddObj(ptr_main_form, ptr_main_menu, 0, 0);

  return ptr_win_app;
}

///////////////////////////////////////////////////////
//            Processes application's                //
//                   messages.                       //
///////////////////////////////////////////////////////
void cMyApp_apprun(struct cWinApp* ptr_win_app)
{
  struct Message* ptr_message;
  struct DirectKeyboard* ptr_keyboard;
  bool clicks_enabled;
  int effect_type;
  int Quit = 0;

  //  Initializes direct keyboard object.
  ptr_keyboard = DirectKeyboard_get_instance();

  //  Stores in the "clicks_enabled" variable keyboard clicks state.
  clicks_enabled = get_clicks_enabled();

  while (!Quit)     //(ptr_main_form->ModalResult != mrQuit)
  {
    //  Turns on the keyboard clicks.
    set_clicks_enabled(FALSE);

    cMyApp_ctor(ptr_win_app);

    //  Selects effect.
    cMainForm_ShowModal(ptr_main_form);
    cFrameForm_Hide(ptr_main_form);
    effect_type = cList_Sel(ptr_main_menu);

    //  Sets 1.help as a help file.
    ptr_win_app->HelpContext = 1;

    //  Turns off the keyboard clicks.
//    set_clicks_enabled(FALSE);

    //  Clears screen.
    cWinApp_clear_screen();

    //while(ptr_main_form->ModalResult == mrOk)
    if (ptr_main_form->ModalResult == mrOk)
    {
      ptr_message = cWinApp_get_message(ptr_win_app, 5, 1, MSG_USER);

      //  If our process does not have a focus - do nothing.
      if(cWinApp_has_focus(ptr_win_app))
      {
        switch(effect_type)
        {
          case 0: //  baud rate
	    if (SerialConfig.baud_rate++ == COMM_BAUD_115200)
	       SerialConfig.baud_rate = COMM_BAUD_110;
            break;
          case 1: //  data bits
	    if (SerialConfig.data_bits++ == COMM_DATABITS_8)
	       SerialConfig.data_bits = COMM_DATABITS_5;
            break;
          case 2: //  stop bits
	    if (SerialConfig.stop_bits++ == COMM_STOPBITS_20)
	       SerialConfig.stop_bits = COMM_STOPBITS_10;
            break;
          case 3: //  parity type
	    if (SerialConfig.parity_type++ == COMM_PARITY_SPACE)
	       SerialConfig.parity_type = COMM_PARITY_NONE;
            break;
          case 4: //  Handshake
	    if (HandShake++ == 2)
	       HandShake = 0;
            break;
          case 5:  //  Font Size
            //ptr_main_form->ModalResult = mrQuit;
	    if (FontSize++ == 2)
	       FontSize = 0;
			break;
          case 6:  //  Local Echo
            //ptr_main_form->ModalResult = mrQuit;
	    if (LocalEcho++ == 1)
	       LocalEcho = 0;
			break;
        }  //  switch(effect_type)
      }  //  if(cWinApp_has_focus(ptr_win_app))

      //  It was a real message (it was not timed out).
      if(!ptr_message)
      {
        continue;
      }

      switch(ptr_message->msgid)
      {
        case MSG_LOSTFOCUS:   //  Application lost focus.
          //MSequence_stop(&cybiko_music);
          vibrate(0);
          break;
        case MSG_GOTFOCUS:    //  Application is focused.
          cWinApp_clear_screen();
          break;
        case MSG_QUIT:        //  Processes system exit signal.
        case MSG_SHUTUP:
          ptr_main_form->ModalResult = mrQuit;
          break;
        case MSG_KEYDOWN:     //  Processes keyboard.
          if(Message_get_key_param(ptr_message)->scancode == KEY_ESC)
          {
            //vibrate(0);
            //MSequence_stop(&cybiko_music);
            ptr_main_form->ModalResult = mrCancel;
            break;
          }
        default:
          cWinApp_defproc(main_module.m_process, ptr_message);
      }  //  switch(ptr_message->msgid)

      //  Deletes the processed message.
      Message_delete(ptr_message);

    }  //  while(ptr_main_form->ModalResult == mrOk)

  Quit = (ptr_main_form->ModalResult == mrQuit);

  cMyApp_dtor(ptr_win_app);

  }  //  while(ptr_main_form->ModalResult != mrQuit)

  // Put new settings into effect
  SetTermFont();
  WriteConfigFile();

  //  Restores clicks
  set_clicks_enabled(clicks_enabled);

  //  Releases direct keyboard object.
  DirectKeyboard_dtor(ptr_keyboard, FREE_MEMORY);
}

///////////////////////////////////////////////////////
//            Releases application's                 //
//                   objects.                        //
///////////////////////////////////////////////////////
void cMyApp_dtor(struct cWinApp* ptr_win_app)
{
  // Releases all allocated objects.
  if (ptr_main_form)
  {
    cFrameForm_dtor(ptr_main_form, FREE_MEMORY);
  }

//  MSequence_dtor(&cybiko_music, LEAVE_MEMORY);
}

///////////////////////////////////////////////////////
//               Shows main form of                  //
//                the application                    //
///////////////////////////////////////////////////////
int cMainForm_ShowModal(struct cFrameForm* ptr_form)
{
  struct Message* ptr_message;

  ptr_form->HelpContext = 1;

  cFrameForm_Show(ptr_form);

  ptr_form->ModalResult = mrNone;

  while(ptr_form->ModalResult == mrNone)
  {
    ptr_message = cWinApp_get_message(ptr_form->CurrApplication,
                                      0,
                                      1,
                                      MSG_USER);

    cMainForm_proc(ptr_form, ptr_message);
    cFrameForm_update(ptr_form);

    Message_delete(ptr_message);
  }  //  while(ptr_form->ModalResult == mrNone)

  return ptr_form->ModalResult;
}

///////////////////////////////////////////////////////
//            Processes messages of the              //
//                   main form.                      //
///////////////////////////////////////////////////////
bool cMainForm_proc(struct cFrameForm* ptr_form, struct Message* ptr_message)
{
  switch(ptr_message->msgid)
  {
    case MSG_SHUTUP:    //  Processes system exit signal.
    case MSG_QUIT:
       ptr_form->ModalResult = mrQuit;
       break;
    case MSG_KEYDOWN:   //  Processes keyboard.
      switch(Message_get_key_param(ptr_message)->scancode)
      {
        case KEY_ESC:
          ptr_form->ModalResult = mrQuit;
          return TRUE;
        case KEY_ENTER:
          //  ModalResult containing selected menu item.
          ptr_form->ModalResult = mrOk;
          return TRUE;
      }  //  switch(Message_get_key_param(ptr_message)->scancode)
  }  //  switch(ptr_message->msgid)

  return cFrameForm_proc(ptr_form, ptr_message);
}

const char TXTBaudRate[13][7] = {
 "110","300","600","1200","2400","4800","7200",
 "9600","14400","19200","38400","57600","115200"};

const char TXTDataBits[4][2] = {
 "5","6","7","8"};

const char TXTStopBits[3][4] = {
 "1.0","1.5","2.0"};

const char TXTParity[5][6] = {
 "None","Odd","Even","Mark","Space"};

const char TXTHandshake[3][9] = {
 "None","CTS","Xon/Xoff"};

const char TXTFont[3][6] = {
 "3x5","4x6","5x7"};

const char TXTLocalEcho[2][4] = {
 "No","Yes"};

void GetCurrentOptions (void)
   {
   strcpy(sz_menu_text2[0], TXTBaudRate[SerialConfig.baud_rate]);
   strcpy(sz_menu_text2[1], TXTDataBits[SerialConfig.data_bits]);
   strcpy(sz_menu_text2[2], TXTStopBits[SerialConfig.stop_bits]);
   strcpy(sz_menu_text2[3], TXTParity[SerialConfig.parity_type]);
   strcpy(sz_menu_text2[4], TXTHandshake[HandShake]);
   strcpy(sz_menu_text2[5], TXTFont[FontSize]);
   strcpy(sz_menu_text2[6], TXTLocalEcho[LocalEcho]);
   }

///////////////////////////////////////////////////////
//              Creates main menu of                 //
//                the application.                   //
///////////////////////////////////////////////////////
struct cList* cMenuList_ctor(struct cList* ptr_menu, int width)
{
  int index;
  struct cItem* ptr_menu_item;
  static char* sz_menu_text[7] = {
                                   "Baud Rate",
                                   "Data Bits",
                                   "Stop Bits",
                                   "Parity",
                                   "Handshake",
                                   "Font Size",
								   "Local Echo"
                                 };
  GetCurrentOptions();

  //  Creates a main menu list.
  cList_ctor(ptr_menu, width);

  //  Fills menu with items.
  for(index = 0; index < 7; index ++)
  {
    ptr_menu_item = (struct cItem*)malloc(sizeof(struct cItem));
    cItem_ctor(ptr_menu_item, width, sz_menu_text[index], FALSE, sz_menu_text2[index], NULL);
    cList_AddItem(ptr_menu, ptr_menu_item);
  }

  return ptr_menu;
}

void ReadConfigFile (void)
   {
   char i;
   struct Input* ptr_input;

   ptr_input = Archive_open_Ex(main_module.m_process->module->archive, "config.inf");

   SerialConfig.baud_rate = (char)Input_read_byte( ptr_input );
   SerialConfig.data_bits = (char)Input_read_byte( ptr_input );
   SerialConfig.stop_bits = (char)Input_read_byte( ptr_input );
   SerialConfig.parity_type = (char)Input_read_byte( ptr_input );
   HandShake = (char)Input_read_byte( ptr_input );
   FontSize = (char)Input_read_byte( ptr_input );
   LocalEcho = (char)Input_read_byte( ptr_input );

   switch (HandShake)
      {
      case 0: i=0;                      // None
      case 1: i=COMM_FC_RTSCTS_INPUT;   // CTS
      default: i=COMM_FC_XONXOFF_INPUT | COMM_FC_XONXOFF_OUTPUT;  // Xon/Xoff
      }
   SerialConfig.flow_control = i;

   com_set_config (SerialPort, &SerialConfig);

   Input_dtor(ptr_input, FREE_MEMORY);
   }

void WriteConfigFile (void)
   {
   char i;
   struct Output* ptr_output;

   ptr_output = Archive_open_write_Ex(main_module.m_process->module->archive, "config.inf");

   Output_write_byte( ptr_output, SerialConfig.baud_rate );
   Output_write_byte( ptr_output, SerialConfig.data_bits );
   Output_write_byte( ptr_output, SerialConfig.stop_bits );
   Output_write_byte( ptr_output, SerialConfig.parity_type );
   Output_write_byte( ptr_output, HandShake );
   Output_write_byte( ptr_output, FontSize );
   Output_write_byte( ptr_output, LocalEcho );
   Output_write_byte( ptr_output, 0 );

   switch (HandShake)
      {
      case 0: i=0;                      // None
      case 1: i=COMM_FC_RTSCTS_INPUT;   // CTS
      default: i=COMM_FC_XONXOFF_INPUT | COMM_FC_XONXOFF_OUTPUT;  // Xon/Xoff
      }
   SerialConfig.flow_control = i;

   com_set_config (SerialPort, &SerialConfig);

   Output_dtor(ptr_output, FREE_MEMORY);
   }