DO NOT SEND QUESTIONS ABOUT THIS PROGRAM. THEY WILL
BE IGNORED. IT IS NO LONGER SUPPORTED!!!

This program is designed for the Cybiko Classic. It
has never been tested on any other Cybiko.

Press Select to get a menu of options to set.
Press Esc to exit the program.

 It is designed to be a VT100 Termminal emulator.
For those that don't know what that is, it takes
serial bytes from the serial port and displays
them on the screen in ascii. It takes button
presses on the keyboard and sends them out the
serial port in ascii. It doesn't do anything
else.

 No advanced features of the VT100 are supported.
This is a very basic program. If you want more
features then you have to add them yourself. If
you want it to work on something other than the
original Cybiko then you have to figure that out
yourself. You will need to be very familiar with
the Cybiko SDK (software development kit from
cybiko.com) in order to make changes to software.
