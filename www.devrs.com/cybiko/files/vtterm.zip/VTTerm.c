//  Term.c - VT100 Terminal Emulator
//
//  Main module of the application.
//
//  Written by Jeff Frohwein (jeff@devrs.com)
//   Started:   2001-Jan-12
//   Last edit: 2001-Jan-18
//
// Known bugs:
//  Scrolling bug in 3x5 font mode. Bottom of screen trash.
//
//  v1.0 - Initial release
//  v1.1 - Now doesn't crash when ComPort.dl is not installed.
//  v1.2 - Fixed a bug where bottom line doesn't always clear.

#include "VTTerm.h"
#include "options.c"

// *** VT100 Emulated Sequences ***
// 12 - Clear Screen & Home Cursor (1,1) (NOT ANSI DEFINED??)
// ESC [ row ; col H - Cursor move to row,column
//  ESC [ row H - Cursor move to row,1
//  ESC [ H - Cursor move to 1,1
// ESC [ 2 J - Clear Screen & Home Cursor (1,1)
// ESC [ f - Same as ESC [ H

#ifdef HACKS
void SaveROM(void)
{
        char filename[20];
        //output file
        struct FileOutput* pFile;
		char *ptr = 0;

		strcpy(filename, "cybiko.rom");

        //allocate output file structure
        pFile=(struct FileOutput*)malloc(sizeof(struct FileOutput));

        //construct output file
        FileOutput_ctor(pFile);

        //open output file
        FileOutput_open(pFile,filename,TRUE);

        //write the header
//        FileOutput_write_byte(pFile,0x02);//this is a pic file

        //write pixel information
        FileOutput_write(pFile,ptr,32768);

        //destroy the file struct
        FileOutput_dtor(pFile,FREE_MEMORY);
}

void DisplayStr(char* str )
  {
  int i,j;

  for( i = 0; str[ i ]; i++ )
    {
    DisplayChar(str[ i ]);
    }
  }
#endif

///////////////////////////////////////////////////////
//           Main function of the                    //
//             game application.                     //
///////////////////////////////////////////////////////
long main (int argc, char* argv[], bool start)
   {
   int i,sc;
   int temp_cursor_index;
   struct KeyParam* ptr_key_param;
   struct Message* ptr_message;
   char LinesText[40];

   char s[40];
   int x,y;
   char *ptr;

		 memcpy(DisplayGraphics_get_page_ptr(main_module.m_gfx, 0),
                ptr,
                DisplayGraphics_get_bytes_total(main_module.m_gfx));
//   asmp(nop);
//	nop;
//	{
//
//	nop
//   }

   OpenSession();

   if (File_exists( "ComPort.dl" ) )
      {
	  InitSerial();

	  ProcessChar(CURSOR_CHAR);

      while (!ExitTerminal)
         {

         if (ptr_message = cWinApp_get_message(main_module.m_process, 1, 1, MSG_USER))
            {
            switch(ptr_message->msgid)
               {
               case MSG_GOTFOCUS:  //  The process gets the focus (after invitations).
                  RedrawScreen();
                  break;
               case MSG_SHUTUP:
               case MSG_QUIT:
                  ExitTerminal = TRUE;
                  break;
               case MSG_KEYDOWN:
                  ptr_key_param = Message_get_key_param(ptr_message);
                  switch(ptr_key_param->scancode)
                     {
					 case KEY_SELECT:    OptionsScreen(); break;
					 case KEY_BACKSPACE: SendChar(8);    break;
                     case KEY_DEL:       SendChar(0x7f); break;
                     case KEY_ENTER:     SendChar(13);   break;
#ifdef HACKS
					 case KEY_TAB:
					   	//SaveROM();
						ptr = (char *)0x400000;
						for (y=0; y<8; y++)
						   {
		 				   //i = ptr[0] & 0xff;
						   sprintf(s, "%lx ",ptr);
						   DisplayStr(s);

						   for (x=0; x<8; x++)
							  {
							  i = ptr[0] & 0xff;
							  ptr++;
							  sprintf(s, "%x ",i);
							  if (i<16) DisplayChar(48);
							  DisplayStr(s);
							  }
						   DisplayChar(13);
						   DisplayChar(10);
						   }
                        DisplayGraphics_show(main_module.m_gfx);
						break;
#endif
                     case KEY_ESC:
                        //  Shows CyWin modal dialog "Do you really want to quit ?".
                        cDialog_ctor(&player_dialog,
                                     NULL,
                                     str_Really_exit,
                                     mbQuit | mbCancel,
                                     0,
                                     main_module.m_process);

                        if (cDialog_ShowModal(&player_dialog) == mrQuit)
                           ExitTerminal = TRUE;

                        cDialog_dtor(&player_dialog, LEAVE_MEMORY);

                        RedrawScreen();
                        break;

                     default:
						sc = ptr_key_param->scancode;
						if ( (sc > 31) && (sc < 128) )
						   {
						   sc = ProcessShift(ptr_key_param->mask, sc);
                           SendChar(sc);
						   }
						else

                        //  Processes unprocessed message.
                        //  Need for processing HELP key.
                        cWinApp_defproc(main_module.m_process, ptr_message);
                     }  //  switch(ptr_key_param->KeyParam_scancode)
                  break;
               default:
                  //  Processes unprocessed message.
                  cWinApp_defproc(main_module.m_process, ptr_message);
               }  //  switch(ptr_message->Message_msgid)

            //  Deletes message.
            Message_delete(ptr_message);
            }

		 // Check for incoming characters
		 CheckSerialIn();
         }  //  while(!ExitTerminal)

      }  //  while(File_exists ("Comport.dl")
   else
	  {
	  strcpy(LinesText, "File 'ComPort.dl' not found.");
      DisplayGraphics_set_color(main_module.m_gfx, CLR_BLACK);
      DisplayGraphics_set_font(main_module.m_gfx, cool_normal_font);
      DisplayGraphics_draw_text(main_module.m_gfx, LinesText, 12, 40);

	  DisplayGraphics_show(main_module.m_gfx);

      // 4 second delay
      cWinApp_pause( main_module.m_process, 4000);

	  }
   CloseSession();

   return 0;
   }

int ProcessShift (int mask, int sc)
   {
   if (mask & KEYMASK_SHIFT)
      switch (sc)
	   	{
   	    case KEY_1: sc = 33; break; //!
    	case KEY_2: sc = 64; break; //@
    	case KEY_3: sc = 35; break; //#
	   	case KEY_4: sc = 36; break; //$
		case KEY_5: sc = 37; break; //%
		case KEY_6: sc = 94; break; //^
		case KEY_7: sc = 38; break; //&
		case KEY_8: sc = 42; break; //*
		case KEY_9: sc = 40; break; //(
		case KEY_0: sc = 41; break; //)
		case KEY_MINUS: sc = 95; break; //_
		case KEY_SEMICOLON: sc = 58; break; //:
		case KEY_QUOTE: sc = 34; break; //"
		case KEY_COMMA: sc = 60; break; //<
		case KEY_PERIOD: sc = 62; break; //>
		case KEY_SLASH: sc = 63; break; //?
		case KEY_OPEN_SBRACKET: sc = 123; break; //{
		case KEY_CLOSE_SBRACKET: sc = 125; break; //}
		case KEY_BACKSLASH: sc = 124; break; //|
		case KEY_EQUAL: sc = 43; break; //+
	    default: sc -= 32;
	    }
   return sc;
   }

void OptionsScreen (void)
   {
   struct KeyParam* ptr_key_param;
   int index;
   int Exit = 0;

   // cMyApp_ctor(main_module.m_process);
    cMyApp_apprun(main_module.m_process);

   //cMyApp_dtor(main_module.m_process);
   RedrawScreen();
   }

void SendChar (int c)
   {
   if (LocalEcho)
	  {
	  DisplayChar(c);
      DisplayGraphics_show(main_module.m_gfx);
	  }
   com_write( SerialPort, c, 0 );
   }

void CheckSerialIn (void)
   {
   int found = 0;
   int data;

   while ((data = com_read( SerialPort, 1)) >= 0)
	  {
	  found = 1;
	  DisplayChar(data);
	  }

   if (found)
      DisplayGraphics_show(main_module.m_gfx);
   }

void ClearScreen (void)
   {
   int x,y;

   TGraph_fill_screen( main_module.m_gfx, CLR_WHITE );

   // Fill Screen Buffer with spaces
   for (y=0; y<25; y++)
      for (x=0; x<80; x++)
	     ScrnBuf[x][y] = 32;
   }

void MoveCursor (int x, int y)
   {
   ProcessChar(ScrnBuf[CursorX][CursorY]);  // Erase cursor
   CursorX = x;
   CursorY = y;
   ShowCursor();
   }

void ScrollUp (void)
   {
   int i,x,y;
   // Scroll video memory
   Graphics_scroll(main_module.m_gfx, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, 0, -FontHeight) ;

   // Clear bottom line
   DisplayGraphics_set_color(main_module.m_gfx, CLR_WHITE);
   i = (ScreenHeight-1) * FontHeight;
   Graphics_fill_rect( main_module.m_gfx, 0, i, SCREEN_WIDTH, FontHeight);

   // Scroll Screen Buffer
   for (y=1; y<ScreenHeight; y++)
      for (x=0; x<ScreenWidth; x++)
	     ScrnBuf[x][y-1] = ScrnBuf[x][y];

   // Clear bottom line
   for (x=0; x<ScreenWidth; x++)
	     ScrnBuf[x][ScreenHeight-1] = 32;
   }

void ShowCursor (void)
   {
   char LinesText[2];
   int x,y;

   // Show character
   LinesText[0] = CURSOR_CHAR;
   LinesText[1] = 0;

   x = CursorX * FontWidth;
   y = CursorY * FontHeight;

   DisplayGraphics_set_color(main_module.m_gfx, CLR_BLACK);
   DisplayGraphics_draw_text(main_module.m_gfx, LinesText, x, y);

//   DisplayGraphics_show(main_module.m_gfx);
   }

void ProcessEscapeSequence (int c)
   {
   static int Value1,Value2;
   int ProcessResult = 0;

   switch (EscapeState)
	  {
	  case 1:                           // Look for [
		 if (c == 91)
			{
		    EscapeState++;
			Value1 = 0;
			Value2 = 0;
			}
		 else
			EscapeState = 0;
		 break;
	  case 2:                           // Look for ascii digit or other
		 if ((c > 0x2f) && (c < 0x3a))
			{
			// Got a digit
			Value1 = (Value1 * 10) + (c - 0x30);

			// If value is extremely large then treat it as an error
			if (Value1 > 132)
			   EscapeState = 0;
			}
		 else
			if (c == 59)                // if semicolon, get second value
			   EscapeState++;
			else
			   ProcessResult = 1;
		 break;
	  case 3:                         // Look for ascii digit or other
		 if ((c > 0x2f) && (c < 0x3a))
			{
			// Got a digit
			Value2 = (Value2 * 10) + (c - 0x30);

			// If value is extremely large then treat it as an error
			if (Value2 > 132)
			   EscapeState = 0;
			}
		 else
            ProcessResult = 1;
		 break;
	  }

   if (ProcessResult)
	  {
	  switch (c)
		 {
		 case 72:                       // H
		 case 102:                      // f
			// Move cursor
            if (!Value1) Value1=1;
			if (!Value2) Value2=1;
            MoveCursor(Value2-1,Value1-1);
			break;
		 case 74:                       // J
			// Clear
			if (Value1 == 2)
			   {
			   // Clear screen & home cursor
			   ClearScreen();
			   MoveCursor(0,0);
			   }
		 }
	  EscapeState = 0;
	  }
   }

void ProcessChar (int c)
   {
   char LinesText[2];
   int x,y;

   // Show character
   LinesText[0] = (char)c;
   LinesText[1] = 0;

   ScrnBuf[CursorX][CursorY] = c;

   x = CursorX * FontWidth;
   y = CursorY * FontHeight;

   DisplayGraphics_set_color(main_module.m_gfx, CLR_WHITE);
   Graphics_fill_rect( main_module.m_gfx, x, y, FontWidth, FontHeight);

   DisplayGraphics_set_color(main_module.m_gfx, CLR_BLACK);

   DisplayGraphics_draw_text(main_module.m_gfx, LinesText, x, y);

//   DisplayGraphics_show(main_module.m_gfx);
   }

void DisplayChar (int c)
   {
   int h = SCREEN_HEIGHT - FontHeight;
   int i = (ScreenHeight-1) * FontHeight;

   if (EscapeState)
	  {
	  ProcessEscapeSequence(c);
	  return;
	  }

   switch (c)
	  {
	  case 8:
		 // Backspace
         ProcessChar(ScrnBuf[CursorX][CursorY]);  // Erase cursor
		 if (CursorX != 0)
		    CursorX --;
//		 else
//			if (CursorY != 0)
//			   {
//			   CursorX = ScreenWidth-1;
//			   CursorY--;
//			   }
         ShowCursor();
		 break;
	  case 10:
		 // Line Feed
         ProcessChar(ScrnBuf[CursorX][CursorY]);  // Erase cursor
	     if (CursorY++ == ScreenHeight-1)
		    {
		    CursorY--;
			ScrollUp();
		    }
         ShowCursor();
		 break;
	  case 12:
		 // Clear Screen / Home Cursor
		 ClearScreen();
		 MoveCursor(0,0);
		 break;
	  case 13:
		 // Carriage Return
         ProcessChar(ScrnBuf[CursorX][CursorY]);  // Erase cursor
		 CursorX = 0;
         ShowCursor();
		 break;
	  case 27:
		 // Escape
		 EscapeState = 1;
		 break;
	  case 0x7f:
		 // Carriage Return
         DisplayChar(8);
         ProcessChar(32);
         ShowCursor();
		 break;
	  default:
         // Printable char
         ProcessChar(c);
         if (CursorX++ == ScreenWidth-1)
	        {
	        CursorX = 0;

	        if (CursorY++ == ScreenHeight-1)
		       {
		       CursorY--;
			   ScrollUp();
			   }
	        }
         ShowCursor();
	  }
   }

void SetTermFont (void)
   {
   Font_dtor( &TermFont, LEAVE_MEMORY );

   switch (FontSize)
	  {
	  case 0:
		FontWidth = 4; FontHeight = 6;
	  	Font_ctor_Ex( &TermFont, "font3x5.fnt", TRUE, 4);
		break;
	  case 1:
		FontWidth = 5; FontHeight = 7;
		Font_ctor_Ex( &TermFont, "font4x6.fnt", TRUE, 5);
		break;
	  default:
		FontWidth = 6; FontHeight = 8;
		Font_ctor_Ex( &TermFont, "font5x7.fnt", TRUE, 6);
	  }
   DisplayGraphics_set_font(main_module.m_gfx, &TermFont);

   //FontWidth = Font_get_char_width( &TermFont, '0' );
   //FontHeight = Font_get_char_height( &TermFont );
   ScreenWidth = SCREEN_WIDTH / FontWidth;
   ScreenHeight = SCREEN_HEIGHT / FontHeight;
   }

///////////////////////////////////////////////////////
//           Performs initialization                 //
///////////////////////////////////////////////////////
void OpenSession (void)
   {
   int i,x,y;

   init_module (&main_module);

   // Disable any active escape sequence
   EscapeState = 0;

   Font_ctor_Ex( &TermFont, "font3x5.fnt", TRUE, 4);

   // Save the clicks state
   clicks_state = get_clicks_enabled();
   // Disable key clicks
//   set_clicks_enabled(FALSE);

   ExitTerminal = FALSE;

   DisplayGraphics_set_page(main_module.m_gfx, 0);

//   TGraph_fill_screen( main_module.m_gfx, CLR_WHITE );

   CursorX = 0;
   CursorY = 0;

   SetTermFont();

   ClearScreen();

//   SetTermFont();
   }

void InitSerial (void)
   {
  /* open default serial port, wait a second for availability */
  if (SerialPort = com_open( COMM_DEV_DEFAULT, 1000 ))
	 {
     com_get_config (SerialPort, &SaveSerialConfig);
	 ReadConfigFile();
	 }
  else
     TRACE( "cannot open the port" );
//SerialPort = com_open( COMM_DEV_DEFAULT, 1000 );
//     SerialConfig->baud_rate = COMM_BAUD_57600; //9600;
   }

///////////////////////////////////////////////////////
//           Closes Session                          //
///////////////////////////////////////////////////////
void CloseSession (void)
   {
   // Restores the key click state
   set_clicks_enabled(clicks_state);

   /* close the port */
   if (SerialPort)
      {
//      com_close( SerialPort );
      com_set_config (SerialPort, &SaveSerialConfig);
      com_close( SerialPort );
	  }

   Font_dtor( &TermFont, LEAVE_MEMORY );
//   free(ptr_background);
   }

///////////////////////////////////////////////////////
//              Redraws CYBIKO                       //
//                  screen.                          //
///////////////////////////////////////////////////////
void RedrawScreen (void)
   {
   int attr,file,frame,i,x,y,xc,yc;
   char LinesText[81];

   if (cWinApp_has_focus(main_module.m_process))
      {
      TGraph_fill_screen( main_module.m_gfx, CLR_WHITE );

	  SetTermFont();
	  LinesText[ScreenWidth] = 0;

      DisplayGraphics_set_color(main_module.m_gfx, CLR_BLACK);
	  for (y=0; y<ScreenHeight; y++)
		 {
		 for (x=0; x<ScreenWidth; x++)
			LinesText[x] = (char)ScrnBuf[x][y];
         yc = y * FontHeight;
         DisplayGraphics_draw_text(main_module.m_gfx, LinesText, 0, yc);
         }
	  ShowCursor();
      DisplayGraphics_show(main_module.m_gfx);
      }
   }