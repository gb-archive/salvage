/*
 * serial.c
 *
 *  by Jeff Frohwein, jeff@devrs.com
 *
 * Started 2001-Jan-23
 * Last edit 2001-Apr-3
 */

#include <cybiko.h>

#define BEGIN "\nCybiko Debugger v1.0402 by Jeff Frohwein (? for help)\n"
#define DUMP_DEFAULT_LINE_COUNT 16

char *ptr = 0;
char *end;

int SearchLength;
int SearchStr[80];
char s[250];
com_t port;
int data;
char *myptr;

void DisplayChar (int c)
   {
//   (*(void (*)())myptr)();
//   (*myptr)();
   //struct Time time2;

   //Time_decode(&time2, get_trusted_time());

   com_write( port, c, 0 );
   }

void DisplayStr (char* str )
   {
   int i;

   for ( i = 0; str[ i ]; i++ )
      {
      com_write( port, str[ i ], 0 );
      }
   }

void CrLf (void)
   {
   DisplayChar(13);
   DisplayChar(10);
   }

int GetNextByte (void)
   {
   int d = data;
   // Read next byte if not already at end of line
   if (d != 0xa)
      {
	  d = com_read( port, 0 );
	  DisplayChar(d);
	  }
   return(d);
   }

void DisplayAddress (char *adr)
   {
   char s[8];
   if ((long)adr < 1048576) DisplayChar(48);
   if ((long)adr < 65536) DisplayChar(48);
   if ((long)adr < 4096) DisplayChar(48);
   if ((long)adr < 256) DisplayChar(48);
   if ((long)adr < 16) DisplayChar(48);

   sprintf(s, "%lx",adr);
   DisplayStr(s);
   }

void Dump (void)
   {
   int i,x,y;
   int tmp[32];

   while (ptr < end)
      {
	  DisplayAddress(ptr);
      DisplayChar(32);
	  DisplayChar(32);

	  // Show hex values
	  for (x=0; x<16; x++)
	     {
		 i = ptr[0] & 0xff;
		 tmp[x] = i;
		 ptr++;
		 sprintf(s, "%x ",i);
		 if (x==8)
		    DisplayChar(32);
//		 else
//			DisplayChar(32);
		 if (i<16) DisplayChar(48);
		 DisplayStr(s);
		 }

	  DisplayChar(32);

	  // Show ascii values
	  for (x=0; x<16; x++)
	     {
		 i = tmp[x];
		 if ( (i > 0x1f) &&
		 	  (i < 0x80) )
            DisplayChar(i);
		 else
			DisplayChar(46);            // Display a period
		 }
	  CrLf();
	  }
   }

void Search (void)
   {
   int i;
   char *p;
   bool NextAddress = FALSE;

   while (ptr < end)
	  {
	  i = 0;
	  p = ptr;
	  while ((p[0] & 0xff) == SearchStr[i])
		 {
		 i++;
		 p++;
		 }

	  if (i >= SearchLength)
		 {
		 if (NextAddress)
			DisplayChar(32);
		 DisplayAddress(ptr);
		 NextAddress = TRUE;
		 ptr += SearchLength-1;
		 }
	  ptr++;
	  }
   CrLf();
   }

// Get number following parameter.
// If there is none, return -1.
long GetNumber (void)
   {
   long result = -1;
   long value = 0;
   bool GotAnyDigit = FALSE;
   int val = 0x20;

   // Read next byte if not already at end of line

   while (val == 0x20)
     val = GetNextByte();
   data = val;

   while ( ((data > 0x2f) && (data < 0x3a)) ||
   	       ((data > 0x60) && (data < 0x67)) )
      {
	  value <<= 2;                      // Hack required for compiler 1.1.0
	  value <<= 2;                      // since multiply only works up to 16 bits.
     // data -= 0x30;
      if (data > (10+0x30)) data -= 0x27;
      value += (data - 0x30);
	  data = GetNextByte();
	  GotAnyDigit = TRUE;
	  }

   if (GotAnyDigit)
	  result = value;
   return (result);
   }

long main(int argc, char* argv[], bool start)
   {
   int i, j;
   int Quit = 0;
   long val;

   /* open default serial port, wait a second for availability */
   if (File_exists("ComPort.dl"))
      port = com_open( COMM_DEV_DEFAULT, 1000 );
   else
	  port = 0;

   if ( port )
      {
      DisplayStr(BEGIN );

      while (!Quit)
         {
		 DisplayChar(45);

         /* read a byte, wait forever */

         data = com_read( port, 0 );

         if ( data >= 0 ) /* data is received */
            {
            /* Echo the character */
			DisplayChar(data);
//			CrLf();

			switch (data)
			   {
			   case 'd':
				  // Dump - d[start[,end]]

				  // Get start address, if any.
				  if ((val = GetNumber()) != -1)
					 ptr = (char *)val;
				  // Get end address, if any
				  if (data == 0x2c)     // if comma
					 {
					 // comma found. Get end address
					 end = (char *)GetNumber();
					 // If bogus value, use default.
					 if (end < ptr)
						end = ptr + 16*DUMP_DEFAULT_LINE_COUNT;
					 }
				  else
					 end = ptr + 16*DUMP_DEFAULT_LINE_COUNT;

				  //CrLf();
				  Dump();
				  break;
			   case 'p':
				  // Patch - pStart,xx[,xx[..etc]]
				  SearchLength = 0;
				  ptr = (char *)GetNumber();
				  while (data == 0x2c)  // ,
					 {
					 ptr[SearchLength] = (char)GetNumber();
					 SearchLength++;
					 }
				  //CrLf();
				  break;
			   case 's':
				  // Search - sStart,End,xx[,xx[..etc..]]
				  SearchLength = 0;
				  ptr = (char *)GetNumber();
				  end = (char *)GetNumber();
				  while (data == 0x2c)  // ,
					 {
					 SearchStr[SearchLength] = (int)GetNumber();
					 SearchLength++;
					 }
				  if (data == 0x2d)     // -
		    	     {
					 //SearchStr[0] = 0x46;
					 //SearchLength = 1;
					 while ((data = GetNextByte()) != 0xa)
					    {
					    SearchStr[SearchLength] = data;
					    SearchLength++;
					    }
					 }
				  //CrLf();
                  if (SearchLength)
					 Search();
				  else
                     {
					 sprintf(s, "ERROR: Invalid format\n"); DisplayStr(s);
					 }
				  break;
			   case 'h':
			   case '?':
                  sprintf(s, "\nCybiko Debugger Help\n"); DisplayStr(s);
                  sprintf(s, " Dump    - d[start[,end]]\n"); DisplayStr(s);
                  sprintf(s, " Help    - h,?\n"); DisplayStr(s);
                  sprintf(s, " Patch   - pStartAddress,xx[,xx[..etc, up to 80 bytes]]\n"); DisplayStr(s);
                  sprintf(s, " Quit    - q\n"); DisplayStr(s);
                  sprintf(s, " SearchT - sStartAddress,EndAddress-text (up to 80 bytes)\n"); DisplayStr(s);
                  sprintf(s, " SearchV - sStartAddress,EndAddress,xx[,xx[..etc, up to 80 bytes]]\n"); DisplayStr(s);
				  break;
			   case 'q':
				  //CrLf();
				  Quit=1;
				  break;
			   }

			// Ignore rest of line
			while (data != 0xa)
			   data = com_read (port, 0);

			// Ignore 2 chars after line feed
			com_read( port, 0 );
            com_read( port, 0 );
            }
         }

	/* close the port */
    com_close( port );
    TRACE( "done reading" );
  }
  else TRACE( "Cannot open the port or 'ComPort.dl' is missing." );

  return 0;
}
