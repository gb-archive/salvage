//  Tetris.c
//
//  Main module of the application.
//
//  Written by CyBuilder.
//   Started:   2000-Nov-5
//   Last edit: 2000-Nov-13
//
//    Send suggestions/bugs to CyBuilder@hotmail.com
//   Due to the volume of email I get, most questions
//   will probably go unanswered. :( All suggestions will
//   be considered even if I don't respond.
//
// Known bugs:
//  None.
//
//  v1.0 - Initial release
//  v1.1 - Added music, multiple levels, & better score for fast drops.
//  v1.2 - Controls are more responsive, high score is saved, no annoying key click

#include "tetris.h"
#include "shapes.c"

///////////////////////////////////////////////////////
//           Main function of the                    //
//             game application.                     //
///////////////////////////////////////////////////////
long main(int argc, char* argv[], bool start)
   {
   int temp_cursor_index;
   int FastDrop;
   int MusicState = 1;
   int IgnoreControls = 0;
   bool ClicksState;
   struct MSequence mseq_GameMusic;
   struct KeyParam* ptr_key_param;
   struct Message* ptr_message;
   struct DirectKeyboard* ptr_direct_keyboard;

   ptr_direct_keyboard = DirectKeyboard_get_instance();

   // Setup starting position of dropping piece
   PieceX = 5;
   PieceY = PIECE_START_Y;

   // Setup initial shape & next one dropping
#ifdef FORCE_LONG
    CurrentPiece = SHAPELONG;
    NextPiece = SHAPELONG;
#else
   CurrentPiece = (int)random(NUM_OF_SHAPES);
   NextPiece = (int)random(NUM_OF_SHAPES);
#endif

   init_module(&main_module);

   // Save the clicks state
   ClicksState = get_clicks_enabled();
   // Disable key clicks
   set_clicks_enabled(FALSE);

   //  Setup game music pointer to "ingame.mus" resource file.
   MSequence_ctor(&mseq_GameMusic, "ingame.mus");

   InitSession();

   while (!exit_game_session)  //  The application's main loop.
      {
      InitGame();

      DrawBoard();

      while (!exit_current_game)
         {
         FastDrop = 0;

         //  Play game music if it's enabled but not playing.
         if ( MusicState &&
              (!MSequence_is_playing(&mseq_GameMusic)) )
            MSequence_play_background(&mseq_GameMusic);

         DirectKeyboard_scan( ptr_direct_keyboard );
         if ( (DirectKeyboard_is_key_pressed(ptr_direct_keyboard, KEY_LEFT)) &&
              (IgnoreControls == 0) )
            {
            MovePiece(KEY_LEFT);
            IgnoreControls = 3;
            }
         if ( (DirectKeyboard_is_key_pressed(ptr_direct_keyboard, KEY_RIGHT)) &&
              (IgnoreControls == 0) )
            {
            MovePiece(KEY_RIGHT);
            IgnoreControls = 3;
            }
         if ( (DirectKeyboard_is_key_pressed(ptr_direct_keyboard, KEY_DOWN)) &&
              (IgnoreControls == 0) )
            {
            FastDrop = 1;
            IgnoreControls = 2;
            }

         if (ptr_message = cWinApp_get_message(main_module.m_process, 1, 1, MSG_USER))
     // while(ptr_message = cWinApp_peek_message(main_module.m_process, 0, 1, MSG_USER))
            {
            switch(ptr_message->msgid)
               {
               case MSG_GOTFOCUS:  //  The process gets the focus (after invitations).
                  DrawBoard();
                  break;
               case MSG_SHUTUP:
               case MSG_QUIT:
                  exit_current_game = TRUE;
                  exit_game_session = TRUE;
                  break;
               case MSG_KEYDOWN:
                  ptr_key_param = Message_get_key_param(ptr_message);
                  switch(ptr_key_param->scancode)
                     {
                     case KEY_ENTER:
                        if (CurrentPiece != SHAPE2X2)
                           {
                           // Only rotate non 2x2 pieces.

                           RotateFallingPiece();
                           if (OpenAroundPiece(PieceX,PieceY))
                              {
                              // We can rotate piece. No barriers in the way.
                              KeepRotationShape();
                              DrawBoard();
                              }
                           else
                              {
                              // We can not rotate piece. Restore Rotated shape for testing.
                              CopyShapeToRotatedShape();
                              }
                           }
                        break;
                     case KEY_ESC:
                        //  Shows CyWin modal dialog "Do you really want to quit ?".
                        cDialog_ctor(&player_dialog,
                                     NULL,
                                     str_Really_exit,
                                     mbQuit | mbCancel,
                                     0,
                                     main_module.m_process);

                        if (cDialog_ShowModal(&player_dialog) == mrQuit)
                           {
                           exit_current_game = TRUE;
                           exit_game_session = TRUE;
                           }
                        cDialog_dtor(&player_dialog, LEAVE_MEMORY);

                        DrawBoard();
                        break;
                     case KEY_DEL:
                        // Toggle background music
                        if (MusicState)
                           {
                           // Turn off background music
                           MusicState=0;
                           MSequence_stop(&mseq_GameMusic);
                           }
                        else
                           // Turn on background music
                           MusicState=1;
                        break;
                     default:
                        //  Processes unprocessed message.
                        //  Need for processing HELP key.
                        cWinApp_defproc(main_module.m_process, ptr_message);
                     }  //  switch(ptr_key_param->KeyParam_scancode)
                  break;
               default:
                  //  Processes unprocessed message.
                  cWinApp_defproc(main_module.m_process, ptr_message);
               }  //  switch(ptr_message->Message_msgid)

            //  Deletes message.
            Message_delete(ptr_message);
            }
         // Process falling of piece
         UpdatePieceFall(FastDrop);

         if (IgnoreControls) IgnoreControls--;

         }  //  while(!exit_current_game)

      if (!exit_game_session)
         {
         exit_game_session = ShowScore();
         }
      }  //  while(!exit_game_session)

   // Restores the key click state
   set_clicks_enabled(ClicksState);
   // Save score if it's greater than high score
   SetHighScore();

   //  Performs cleanup.
   MSequence_dtor(&mseq_GameMusic, LEAVE_MEMORY);
   DirectKeyboard_dtor( ptr_direct_keyboard, FREE_MEMORY );
   free(ptr_background);

   return 0;
   }

void SetupShapeArray (int i)
   {
   int x,y;

   for (y=0;y<5;y++)
      for(x=0;x<5;x++)
         FallingPieceShape[x+(y*5)] = Shapes[i][y][x];
   }

int CalculateDropSpeed (void)
   {
   int i;

   switch (GameLevel)
      {
      case 0: i=0; break;
      case 1: i=3; break;
      case 2: i=6; break;
      case 3: i=8; break;
      case 4: i=10; break;
      case 5: i=12; break;
      case 6: i=13; break;
      case 7: i=14; break;
      case 8: i=15; break;
      default: i=16; break;
      }

   return (20-i);
   }

void UpdatePieceFall (int FastDrop)
   {
   int i = 1;
   int x,y;

   //DeltaTime = clock();

   if (i) //!= OldTime)
      {
      OldTime = DeltaTime;

      TensMS++;
      if (FastDrop) i = 2; else i = CalculateDropSpeed();

      if ( (FastDrop) ||
           (TensMS == i) )
         {
         TensMS = 0;
         // If nothing is under this piece then drop it one block

         // Don't lose piece points when dropping fast
         if (FastDrop == 0)
            PieceScore -= PIECE_INC_SCORE;

         if (OpenAroundPiece(PieceX,PieceY-1))
            {
            // Piece can fall one block
            PieceY--;
            DrawBoard();
            }
         else
            {
            // Piece has hit bottom or other pieces.

            // Add this piece to the graphics background.
            DisplayGraphics_set_page(main_module.m_gfx, 1);
            DrawFallingPiece(PieceX,PieceY,CurrentPiece);
            DisplayGraphics_set_page(main_module.m_gfx, 0);

            // End game if stack full
            if (PieceY == PIECE_START_Y)
               {
               exit_current_game = TRUE;
             //  exit_game_session = TRUE;
               }

            // Add this piece to the collision background
            for (y=0; y<5; y++)
               for (x=0; x<5; x++)
                  {
                  if (FallingPieceShape[x+((4-y)*5)])
                     Background[PieceX-2+x+((PieceY-2+y)*PLAYAREA_X)] = 1;
                  }

            // Update level info when necessary
            TotalPieces++;
            if (TotalPieces == PIECES_PER_LEVEL)
               {
               if (GameLevel < 9) GameLevel++;
               TotalPieces = 0;
               }

            // If any rows are complete then make them
            // flash and then disappear.
            CheckForCompleteRows ();

            CurrentPiece = NextPiece;
#ifdef FORCE_LONG
            NextPiece = SHAPELONG;
#else
            NextPiece = (int)random(NUM_OF_SHAPES);
#endif
            if (NextPiece > 5) NextPiece = 0;

            PieceY = PIECE_START_Y;
            PieceX = 5;

            GameScore += PieceScore;
            PieceScore = PIECE_MAX_SCORE;

            // Update level, lines & shape info on screen
            DrawInfoScreen();

            DrawFallingPiece(PieceX,PieceY,CurrentPiece);

            DrawBoard();
            }
         }
      }
   }

void CheckForCompleteRows (void)
   {
   int i;
   int MinRow = PLAYAREA_Y;
   int MaxRow = 0;
   int CompleteRow;
   int RowCount = 0;
   int x,y,yo;
   int row[4];

   // Reset Complete Rows
   for (i=0; i<4; i++)
      row[i] = 0;

   for (y=0; y<PLAYAREA_Y; y++)
      {
      CompleteRow = 1;
      for (x=0;x<PLAYAREA_X;x++)
         if (Background[x+(y*PLAYAREA_X)]==0) CompleteRow=0;
      if (CompleteRow)
         row[RowCount++] = y+1;
      }

   if ( (cWinApp_has_focus(main_module.m_process)) &&
        (RowCount) )
      {
      Graphics_set_draw_mode(main_module.m_gfx, DM_PUT);

      // Copys from 1 graphic page to current graphic page.
      DisplayGraphics_page_copy(main_module.m_gfx, 1, 0, 0, 0, 160, 100);

      // Update onscreen lines count
      Lines += RowCount;

      // If 1 row complete, add 100 to score
      if (RowCount==1) GameScore += 100;
      // If 2 rows complete, add 200 to score
      if (RowCount==2) GameScore += 200;
      // If 3 rows complete, add 400 to score
      if (RowCount==3) GameScore += 400;
      // If 4 rows complete, add 800 to score
      if (RowCount==4) GameScore += 800;

      //Cause complete rows to flash 3 times
      for (i=0; i<3; i++)
         {
         DisplayGraphics_set_color(main_module.m_gfx, CLR_LTGRAY);
         for (y=0; y<4; y++)
            {
            if (row[y])
               {
               DisplayGraphics_fill_rect(main_module.m_gfx,
                                         ORIGIN_SCRN_X,
                                         SCREEN_HEIGHT-(row[y]*BLOCK_SIZE),
                                         BLOCK_SIZE*PLAYAREA_X,
                                         BLOCK_SIZE);
               }
            }
         // Shows current graphic page.
         DisplayGraphics_show(main_module.m_gfx);
         FlashDelay();

         DisplayGraphics_set_color(main_module.m_gfx, CLR_WHITE);
         for (y=0; y<4; y++)
            {
            if (row[y])
               {
               DisplayGraphics_fill_rect(main_module.m_gfx,
                                         ORIGIN_SCRN_X,
                                         SCREEN_HEIGHT-(row[y]*BLOCK_SIZE),
                                         BLOCK_SIZE*PLAYAREA_X,
                                         BLOCK_SIZE);
               }
            }
         // Shows current graphic page.
         DisplayGraphics_show(main_module.m_gfx);
         FlashDelay();
         }

      DrawInfoScreen();

      // Scroll screen to get rid of complete lines
      DisplayGraphics_set_page(main_module.m_gfx, 1);
      for (y=3; y>=0; y--)
         {
         if (row[y])
            {
            DisplayGraphics_scroll(main_module.m_gfx,
                                   ORIGIN_SCRN_X,
                                   0,
                                   BLOCK_SIZE*PLAYAREA_X,
                                   SCREEN_HEIGHT-((row[y]-1)*BLOCK_SIZE),
                                   0,
                                   BLOCK_SIZE);

            // Scroll background array as well
            for (yo=0; yo<PLAYAREA_Y-row[y]-2; yo++)
               for (x=0; x<PLAYAREA_X; x++)
                  {
                  Background[x+((row[y]-1+yo)*PLAYAREA_X)] = Background[x+((row[y]-1+yo+1)*PLAYAREA_X)];
                  }
            }
         }
      DisplayGraphics_set_page(main_module.m_gfx, 0);

      DisplayGraphics_page_copy(main_module.m_gfx, 1, 0, 0, 0, 160, 100);
      DisplayGraphics_show(main_module.m_gfx);

      }
   }

void FlashDelay (void)
   {
   clock_t i,j;
   int k=0;

   while (k<20)
      {
      j=i;
      while (i == j)
         i=clock();
      k++;
      }
   }

// Check to see if area under shape is open.
// This decides whether we can move or rotate a piece.

int OpenAroundPiece (int ShapeX, int ShapeY)
   {
   int x,y;

   for (y=0; y<5; y++)
      for (x=0; x<5; x++)
         {
         if (FallingPieceShapeRotated[x+((4-y)*5)])
            {        //-2
            // Exit if piece has hit left side
            if (ShapeX-1+x-1 < 0) return(0);
            // Exit if piece has hit right side
            if (ShapeX-1+x > PLAYAREA_X) return(0);
            // Exit if piece has hit bottom
            if (ShapeY-1+y-1 < 0) return(0);
            // Exit if piece has hit another piece
            if (Background[ShapeX-2+x+((ShapeY-2+y)*PLAYAREA_X)]) return(0);
            }                  //-3
         }
   return(1);
   }

///////////////////////////////////////////////////////
//           Performs initialization                 //
//             of the game session.                  //
///////////////////////////////////////////////////////
void InitSession (void)
   {
   int i;

   exit_game_session = FALSE;

   // Randomize the random number generator
   srand((int)clock());

   HighScore = GetHighScore();

   //  Draws background at 1 graphics page.
   ptr_background = (char*)malloc(DisplayGraphics_get_bytes_total(main_module.m_gfx));

   DisplayGraphics_set_page(main_module.m_gfx, 1);

   //  Draws tetris bg image
   draw_lib(0,
            TETRIS_BG1,
            0,
            0,
            BM_NORMAL);

   DisplayGraphics_set_page(main_module.m_gfx, 0);

   //  Copys background image to memory.
   memcpy(ptr_background,
          DisplayGraphics_get_page_ptr(main_module.m_gfx, 1),
          DisplayGraphics_get_bytes_total(main_module.m_gfx));

   DrawBoard();
   }

///////////////////////////////////////////////////////
//           Performs initialization of the          //
//                   each game.                      //
///////////////////////////////////////////////////////
void InitGame (void)
   {
   int i;

   // Clear background
   for (i=0; i<PLAYAREA_X*PLAYAREA_Y; i++)
      Background[i] = 0;

   // Clear background
   for (i=0; i<25; i++)
      FallingPieceShape[i] = 0;

   SetupShapeArray(0);
   // Copy to rotated shape so that we can do bounds testing later.
   CopyShapeToRotatedShape();

   Lines = 0;
   GameLevel = 0;
   GameScore = 0;
   TotalPieces = 0;
   PieceScore = PIECE_MAX_SCORE;

   exit_current_game = FALSE;

   //  Draws background at 1 graphics page.
   DisplayGraphics_set_page(main_module.m_gfx, 1);

   DisplayGraphics_set_draw_mode(main_module.m_gfx , DM_PUT);
   DisplayGraphics_put_background(main_module.m_gfx, ptr_background);

//   DrawInfoScreen();

   DisplayGraphics_set_page(main_module.m_gfx, 0);
   DrawInfoScreen();
   }

///////////////////////////////////////////////////////
//         Moves player's cursor in the              //
//            specified direction.                   //
///////////////////////////////////////////////////////
void MovePiece (int direction)
   {
   if ( (!cWinApp_has_focus(main_module.m_process))
        || (exit_current_game) )
      {
      return;
      }

   switch(direction)
      {
      case KEY_LEFT:
         if (OpenAroundPiece(PieceX-1,PieceY)) PieceX--;
         break;
      case KEY_UP:
         break;
      case KEY_RIGHT:
         if (OpenAroundPiece(PieceX+1,PieceY)) PieceX++;
         break;
      default:
         break;
      }

   DrawBoard();
   }

///////////////////////////////////////////////////////
//              Redraws CYBIKO                       //
//                  screen.                          //
///////////////////////////////////////////////////////
void DrawBoard (void)
   {
   if(cWinApp_has_focus(main_module.m_process))
      {
      Graphics_set_draw_mode(main_module.m_gfx, DM_PUT);

      // Copys from 1 graphic page to current graphic page.
      DisplayGraphics_page_copy(main_module.m_gfx, 1, 0, 0, 0, 160, 100);
      DisplayGraphics_set_color(main_module.m_gfx, CLR_BLACK);

      // Draws cursor on current graphic page.
      if (!exit_current_game)
         {
         DrawFallingPiece(PieceX, //32+ABSCISSA(cursor_index)*8,
                          PieceY, //32+ORDINATE(cursor_index)*8);
                          CurrentPiece);
         }

      // Shows current graphic page.
      DisplayGraphics_show(main_module.m_gfx);
      }
   }

// PieceX & PieceY coordinates are in block increments and the
// origin is in the bottom left play field corner.

void DrawFallingPiece (int x, int y, int Shape)
   {
   int xo,yo;

   for (yo=0; yo<5; yo++)
      {
      for (xo=0; xo<5; xo++)
         {
         if (FallingPieceShape[xo+(yo*5)])
            draw_lib(0,
                     ShapePattern[Shape],
                     ORIGIN_SCRN_X+((x+xo-2)*BLOCK_SIZE),
                     ORIGIN_SCRN_Y+((-y+yo-2)*BLOCK_SIZE),
                     BM_NORMAL);
         }
      }
   }

void RotatePartOfPiece (int x1, int x2, int y)
   {
   int x;
   for (x=x1; x<x2; x++)
      {
      FallingPieceShapeRotated[4-y+(x*5)] = FallingPieceShape[x+(y*5)];
      FallingPieceShapeRotated[4-x+((4-y)*5)] = FallingPieceShape[4-y+(x*5)];
      FallingPieceShapeRotated[y+((4-x)*5)] = FallingPieceShape[4-x+((4-y)*5)];
      FallingPieceShapeRotated[x+(y*5)] = FallingPieceShape[y+((4-x)*5)];
      }
   }

void RotateFallingPiece (void)
   {
   FallingPieceShapeRotated[2+(2*5)] = FallingPieceShape[2+(2*5)];
   RotatePartOfPiece(0,4,0);
   RotatePartOfPiece(1,3,1);
   }

void KeepRotationShape (void)
   {
   int i;
   for (i=0; i<25; i++)
      FallingPieceShape[i] = FallingPieceShapeRotated[i];
   }

void CopyShapeToRotatedShape (void)
   {
   int i;
   for (i=0; i<25; i++)
      FallingPieceShapeRotated[i] = FallingPieceShape[i];
   }

///////////////////////////////////////////////////////
//       Draws information about the score,          //
//            lines, and next shape.                 //
///////////////////////////////////////////////////////
void DrawInfoScreen (void)
   {
   char LinesTxt[15];

   DisplayGraphics_set_page(main_module.m_gfx, 1);

   // Erase old score info (hack, but...)
   DisplayGraphics_set_color(main_module.m_gfx, CLR_WHITE);
   DisplayGraphics_fill_rect(main_module.m_gfx, 113+5, 20, 40, 10);
   // Erase old level info (hack, but...)
   DisplayGraphics_set_color(main_module.m_gfx, CLR_WHITE);
   DisplayGraphics_fill_rect(main_module.m_gfx, 113, 37, 40, 10);
   // Erase old lines info (hack, but...)
   DisplayGraphics_set_color(main_module.m_gfx, CLR_WHITE);
   DisplayGraphics_fill_rect(main_module.m_gfx, 113, 53, 40, 10);
   // Erase old shape (hack, but...)
   DisplayGraphics_set_color(main_module.m_gfx, CLR_WHITE);
   DisplayGraphics_fill_rect(main_module.m_gfx, 119, 73, 34, 20);

   DisplayGraphics_set_draw_mode(main_module.m_gfx, DM_PUT);

   DisplayGraphics_set_font(main_module.m_gfx, cool_normal_font);
   DisplayGraphics_set_color(main_module.m_gfx, CLR_DKGRAY);

   sprintf(LinesTxt, "%ld", HighScore);
   DisplayGraphics_draw_text(main_module.m_gfx,
                             LinesTxt,
                             113+5,
                             2);

   sprintf(LinesTxt, "%ld", GameScore);
   DisplayGraphics_draw_text(main_module.m_gfx,
                             LinesTxt,
                             113+5,
                             19);

   sprintf(LinesTxt, "Level %d", GameLevel);
   DisplayGraphics_draw_text(main_module.m_gfx,
                             LinesTxt,
                             113,
                             36);

   sprintf(LinesTxt, "Lines %d",Lines);
   DisplayGraphics_draw_text(main_module.m_gfx,
                             LinesTxt,
                             113,
                             53);

   SetupShapeArray(NextPiece);
   DrawFallingPiece(NEXTSHAPE_X,NEXTSHAPE_Y,NextPiece);
   SetupShapeArray(CurrentPiece);

   // Copy to rotated shape so that we can do bounds testing later.
   CopyShapeToRotatedShape();

   DisplayGraphics_set_page(main_module.m_gfx, 0);

   }


///////////////////////////////////////////////////////
//             Draws result of the                   //
//                current game.                      //
///////////////////////////////////////////////////////
bool ShowScore (void)
   {
   struct MSequence mseq_result;
   struct Message* ptr_message;
   char sz_result_text[64];
   bool result = FALSE;

   // Play game over tune
   MSequence_ctor(&mseq_result, "over.mus");
   MSequence_play_background(&mseq_result);

   //  Waits 3 seconds.
   cWinApp_pause(main_module.m_process, 3000);

   //  Deletes all keyboard messages from the message queue.
   while (ptr_message = cWinApp_peek_message(main_module.m_process,
                                             TRUE,
                                             MSG_KEYDOWN,
                                             MSG_KEYDOWN))
      {
      Message_delete(ptr_message);
      }

   //  Shows modal CyWin dialog with result of the game.
   sprintf(sz_result_text,
           "Score: %ld\nLevel: %d\nLines: %d",
           GameScore, GameLevel, Lines);

   cDialog_ctor(&player_dialog,
                NULL,
                sz_result_text,
                mbRestart | mbQuit | mbNoEsc,
                0,
                main_module.m_process);

   if (cDialog_ShowModal(&player_dialog) == mrQuit)
      result = TRUE;

   cDialog_dtor(&player_dialog, LEAVE_MEMORY);
   MSequence_dtor(&mseq_result, LEAVE_MEMORY);

   return result;
   }

long GetHighScore (void)
   {
   struct Input* ptr_input;

   ptr_input = Archive_open_Ex(main_module.m_process->module->archive,
                              "score.inf");
   //  Loads high scores from the "score.inf".
   Input_read(ptr_input, high_scores, sizeof(high_scores));

   Input_dtor(ptr_input, FREE_MEMORY);

   return(high_scores[0].score);
   }

void SetHighScore (void)
   {
   struct Output* ptr_output;

   if (GameScore > high_scores[0].score)
      {
      HighScore = GameScore;

       //  Stores new high score.
      high_scores[0].score = GameScore;
      high_scores[0].cyid = get_own_id();
      high_scores[0].time = time();
      strncpy(high_scores[0].nickname,
              ptr_Finder->mf.f_nick,
              NICKNAMESIZE);

      ptr_output = Archive_open_write_Ex(main_module.m_process->module->archive,
                                     "score.inf");
      //  Stores high scores in the "score.inf".
      Output_write(ptr_output, high_scores, sizeof(high_scores));
      Output_dtor(ptr_output, FREE_MEMORY);
      }

   }
