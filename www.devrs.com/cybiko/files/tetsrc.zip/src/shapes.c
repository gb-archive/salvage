
#define NUM_OF_SHAPES      7

#define TETRIS_BG1         0
#define BLOCK_BD           1            // black/dark
#define BLOCK_BL           2            // black/light
#define BLOCK_BW           3            // black/white
#define BLOCK_3D           4            // 3d effect
#define BLOCK_4            5            // Long 4 shape

const int ShapePattern [NUM_OF_SHAPES+1] = {
  BLOCK_BW,
  BLOCK_4,
  BLOCK_BD,
  BLOCK_3D,
  BLOCK_BL,
  BLOCK_BL,
  BLOCK_BD,
  BLOCK_4
};

#define SHAPE2X2           0
#define SHAPELONG          1

const int Shapes [NUM_OF_SHAPES+1][5][5] = {

{ {0,0,0,0,0},
  {0,1,1,0,0},
  {0,1,1,0,0},
  {0,0,0,0,0},
  {0,0,0,0,0} },

{ {0,0,0,0,0},
  {0,0,0,0,0},
  {0,1,1,1,1},
  {0,0,0,0,0},
  {0,0,0,0,0} },

{ {0,0,0,0,0},
  {0,0,1,1,0},
  {0,1,1,0,0},
  {0,0,0,0,0},
  {0,0,0,0,0} },

{ {0,0,0,0,0},
  {0,0,1,0,0},
  {0,1,1,1,0},
  {0,0,0,0,0},
  {0,0,0,0,0} },

{ {0,0,0,0,0},
  {0,1,0,0,0},
  {0,1,1,1,0},
  {0,0,0,0,0},
  {0,0,0,0,0} },

{ {0,0,0,0,0},
  {0,0,0,1,0},
  {0,1,1,1,0},
  {0,0,0,0,0},
  {0,0,0,0,0} },

{ {0,0,0,0,0},
  {0,1,1,0,0},
  {0,0,1,1,0},
  {0,0,0,0,0},
  {0,0,0,0,0} },

{ {0,0,0,0,0},                          // This shape should never occur.
  {0,1,0,1,0},                          // Left in for debugging purposes.
  {0,0,1,0,0},
  {0,1,0,1,0},
  {0,0,0,0,0} }

};