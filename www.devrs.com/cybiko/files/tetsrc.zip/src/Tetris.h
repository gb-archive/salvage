//  Tetris.h
//
//  Main module of the application.
//

#ifndef __TETRIS_H__
#define __TETRIS_H__

#include "CyWin.h"

#define BLOCK_SIZE         6            // 8 pixels wide
#define PLAYAREA_X         10           // Width of play area in blocks
#define PLAYAREA_Y         18           // Height of play area in blocks
#define ORIGIN_SCRN_X      16           // Bottom left corner of play area
#define ORIGIN_SCRN_Y      SCREEN_HEIGHT-BLOCK_SIZE // Bottom right corner of play area

#define PIECE_START_Y      PLAYAREA_Y-3
#define NEXTSHAPE_X        19
#define NEXTSHAPE_Y        2
#define PIECES_PER_LEVEL   20
#define PIECE_MAX_SCORE    68
#define PIECE_INC_SCORE    4

//#define FORCE_LONG 1                  // Force long (1x4) pieces only

//#define APP_NAME           "Tetris   "   //  Name of the application.

struct module_t main_module;           //  Main module of the application.
struct cDialog player_dialog;          //  CyWin dialog object.
struct score_t high_scores[1];        //  High scores of the game.

bool exit_current_game;                //  TRUE if current game is finished.
bool exit_game_session;                //  TRUE if program is finished.

char* ptr_background;                  //  Background image.

int FallingPieceShape[25];         // 2x2 array
int FallingPieceShapeRotated[25];  // 2x2 array
int Background[PLAYAREA_X*PLAYAREA_Y];
int PieceX,PieceY;

clock_t DeltaTime,OldTime;
int TensMS;
int Lines;                              // Number of lines completed
int NextPiece;
int CurrentPiece;
int GameLevel;
long HighScore;
long GameScore;
int TotalPieces;
int PieceScore;

int CalculateDropSpeed (void);
void CheckForCompleteRows (void);
void CopyShapeToRotatedShape (void);
void DrawBoard (void);
void DrawFallingPiece (int,int,int);
void DrawInfoScreen (void);
void FlashDelay (void);
long GetHighScore (void);
void InitGame (void);
void InitSession (void);
void KeepRotationShape (void);
void MovePiece (int direction);
int OpenAroundPiece (int,int);
void RotateFallingPiece (void);
void RotatePartOfPiece (int,int,int);
void SetHighScore (void);
void SetupShapeArray (int);
bool ShowScore (void);
void UpdatePieceFall (int);

#endif