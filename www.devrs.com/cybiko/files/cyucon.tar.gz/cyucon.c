/******************************************************************
** File: cyucon.c
** Description: the main file for CyUCon - Cybiko Unix Console
**
**  by Jeff Frohwein - http://www.devrs.com/cybiko
** All rights reserved.
****************************************************************************
** This program is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License
** as published by the Free Software Foundation; either version 2
** of the License, or (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details at www.gnu.org
****************************************************************************
** v1.0101 - Original release
****************************************************************************/
#include "cyucon.h"
#include "crctab.c"
//#include <stdio.h>

#define TITLE "CyUCon v0.1231 - Cybiko Unix Console, by Jeff Frohwein\n"
#define CMD_NONE 0
#define CMD_COMMAND 1
#define CMD_SEND 2

#define MAX_COMMAND_NAME 40
char param_name[80];

#define BUFSIZE 1024
#define PACKETSIZE 512

int cmd = CMD_NONE;
//int crnl_mapping; //0 - no mapping, 1 mapping
//int script = 0; /* script active flag */
//char scr_name[MAX_SCRIPT_NAME] = "script.scr"; /* default name of the script */
char device[MAX_DEVICE_NAME]; /* serial device name */
int log = 0; /* log active flag */
FILE* flog;   /* log file */
FILE *fptr;
int  pf = 0;  /* port file descriptor */
struct termios pots; /* old port termios settings to restore */
struct termios sots; /* old stdout/in termios settings to restore */
unsigned char rcv[32767];

void init_comm(struct termios *pts)
   {
   /* some things we want to set arbitrarily */
   pts->c_lflag &= ~ICANON; 
   pts->c_lflag &= ~(ECHO | ECHOCTL | ECHONL);
   pts->c_cflag |= HUPCL;
   pts->c_cc[VMIN] = 1;
   pts->c_cc[VTIME] = 0;
   
   /* Standard CR/LF handling: this is a dumb terminal.
    * Do no translation:
    *  no NL -> CR/NL mapping on output, and
    *  no CR -> NL mapping on input.
    */
   pts->c_oflag &= ~ONLCR;
   pts->c_iflag &= ~ICRNL;

   /* no hardware flow control by default */
   pts->c_cflag &= ~CRTSCTS;
   pts->c_iflag &= ~(IXON | IXOFF | IXANY);
   /* set 9600 bps speed by default */
   cfsetospeed(pts, B57600);
   cfsetispeed(pts, B57600);
   }

void init_stdin(struct termios *sts)
   {
   /* again, some arbitrary things */
   sts->c_iflag &= ~BRKINT;
   sts->c_iflag |= IGNBRK;
   sts->c_lflag &= ~ISIG;
   sts->c_cc[VMIN] = 1;
   sts->c_cc[VTIME] = 0;
   sts->c_lflag &= ~ICANON;
   /* no local echo: allow the other end to do the echoing */
   sts->c_lflag &= ~(ECHO | ECHOCTL | ECHONL);
   }

void main_usage(int exitcode, char *str, char *dev)
  {
  fprintf(stderr, TITLE"\n"
          " -c      = Send a command to cybiko.\n"
          " -c\"cmd\" = Send a command on command line to cybiko. Ex: -c\"ls -l\"\n"
          " -d[dev] = Specify a serial port. (Default is /dev/ttyS0 or COM1.)\n"
          " -h,-?   = This help menu.\n"
          " -s      = Send a file to cybiko.\n"
          " -s[file]= Send a file on command line to cybiko. Ex: -sMyApp.app\n"
          "\n"
          "If you get a 'cannot open device' error message, then you need to be logged in as root or have permissions set to use that port.\n"
          "\n");

  if (exitcode==2)
    fprintf(stderr, "Exitcode %d - %s %s\n\n", exitcode, str, dev);

  }

/* restore original terminal settings on exit */
void cleanup_termios (int signal) {
  /* close the log file first */
  if (log) {
    fflush(flog);
    fclose(flog);
  }
  tcsetattr(pf, TCSANOW, &pots);
  tcsetattr(STDIN_FILENO, TCSANOW, &sots);
  exit(0);
}

unsigned int crc1 (char *buf)
   {
   int i;
   int crc = 0;

   for (i=0; i<strlen(buf); i++)
      crc = (crc * 2) ^ (buf[i]*2);
   crc = (crc & 0xffff) ^ (crc >> 17);

   return(crc);
   }

void SendCommand (int pf, char *buf2)
   {
   char term[4];
   int done = 0;
   int i = crc1(buf2);
   fd_set  ready;        /* used for select */
   char buf[BUFSIZE];

   rcv[0] = 0;
   term[0] = 0xa;
   term[1] = i & 0xff;
   term[2] = i >> 8;
   write(pf, buf2, strlen(buf2));
   write(pf, term, 3);

   // wait until done
   while (!done)
      {
      FD_ZERO(&ready);
      FD_SET(STDIN_FILENO, &ready);
      FD_SET(pf, &ready);
      select(pf+1, &ready, NULL, NULL, NULL);

      // If data received, send it to screen
      if (FD_ISSET(pf, &ready))
         {
         /* pf has characters for us */
         i = read(pf, buf, BUFSIZE);
         if (i > 0)
            {
            buf[i]=0;
            strcat(rcv, buf);
	    write(STDOUT_FILENO, buf, i);
	    if (log)
	       fwrite(buf, 1, i, flog);
            }
         }

      // Terminate if user presses any button
      if (FD_ISSET(STDIN_FILENO, &ready))
         {
         /* standard input has characters for us */
         i = read(STDIN_FILENO, buf, BUFSIZE);
         if (i > 0)
            done = 1;
         }

      // Terminate upon completion of data
      if ( (rcv[strlen(rcv)-1]==0x20) &&
           (rcv[strlen(rcv)-2]==0x0a) &&
           (rcv[strlen(rcv)-3]==0x0d) &&
           (rcv[strlen(rcv)-4]=='>') &&
           (rcv[strlen(rcv)-5]==' ') &&
           (rcv[strlen(rcv)-6]=='y') &&
           (rcv[strlen(rcv)-7]=='d') &&
           (rcv[strlen(rcv)-8]=='a') &&
           (rcv[strlen(rcv)-9]=='e') &&
           (rcv[strlen(rcv)-10]=='R') )
        done = 1;

      }
   }

void SendFile (int pf, char *buf2)
   {
   FILE *fptr;
   fpos_t pos;
   char term[5];
   char size[8];
   char tmpbuf[80];
   char rcvstr[] = "rcv ";
   int done = 0;
   int cnt = 0;
   int i;
   size_t numread;
   fd_set  ready;        /* used for select */
   unsigned int eax,ebx,ecx,esi,crc2;
   char buf[BUFSIZE];
   unsigned char fbuf[PACKETSIZE];

   fptr = fopen(buf2, "r");
   while (!feof(fptr))
      {
      i=getc(fptr);
      cnt++;
      }
   fclose(fptr);
   sprintf(size, " %d", cnt-1);

   strcpy(tmpbuf,rcvstr);
   strcat(tmpbuf,buf2);
   strcat(tmpbuf,size);

   i = crc1(tmpbuf);
   rcv[0] = 0;
   term[0] = 0xa;
   term[1] = i & 0xff;
   term[2] = i >> 8;
   write(pf, tmpbuf, strlen(tmpbuf));
   write(pf, term, 3);

   fptr = fopen(buf2, "r");

   // wait until done
   while (!done)
      {
      FD_ZERO(&ready);
      FD_SET(STDIN_FILENO, &ready);
      FD_SET(pf, &ready);
      select(pf+1, &ready, NULL, NULL, NULL);

      // If data received, send it to screen
      if (FD_ISSET(pf, &ready))
         {
         /* pf has characters for us */
         i = read(pf, buf, BUFSIZE);
         if (i > 0)
            {
            buf[i]=0;
            strcat(rcv, buf);
	    write(STDOUT_FILENO, buf, i);
	    if (log)
	       fwrite(buf, 1, i, flog);
            }
         }

      // Terminate if user presses any button
      if (FD_ISSET(STDIN_FILENO, &ready))
         {
         /* standard input has characters for us */
         i = read(STDIN_FILENO, buf, BUFSIZE);
         if (i > 0)
            done = 1;
         }

      // Send next packet
      if ( (rcv[strlen(rcv)-1]==0x0a) &&
           (rcv[strlen(rcv)-2]==0x0d) &&
           (rcv[strlen(rcv)-3]> 0x2f) &&
           (rcv[strlen(rcv)-3]< 0x3a) )
        {
        i = rcv[strlen(rcv)-3] - 0x30;
        if ( (rcv[strlen(rcv)-4] > 0x2f) && (rcv[strlen(rcv)-4] < 0x3a) )
           i = i + (10*(rcv[strlen(rcv)-4] - 0x30));
        if ( (rcv[strlen(rcv)-5] > 0x2f) && (rcv[strlen(rcv)-5] < 0x3a) )
           i = i + (100*(rcv[strlen(rcv)-5] - 0x30));
        sprintf(size, "[Send packet %d]",i);
	write(STDOUT_FILENO, size, strlen(size));

        // Set file position to start of packet
        pos = i << 9;
        fsetpos(fptr, &pos);
 
       // Read a packet from disk
        numread = fread(fbuf, 1, PACKETSIZE, fptr);
        term[0] = 'C';
        term[1] = i;
        term[2] = 0;
        term[3] = numread & 0xff;
        term[4] = numread >> 8;
        write(pf, term, 5);

        eax = i;       // packet number
        ebx = numread;

        esi = foo[(eax ^ 0xff) & 0xff] ^ 0xffffff;
        eax = foo[(esi & 0xff) ^ ((eax >> 8) & 0xff)];
        esi = esi >> 8;
        eax = eax ^ esi;
        ecx = foo[(eax & 0xff) ^ (ebx & 0xff)] ^ (eax >> 8);
        eax = foo[((ebx >> 8) & 0xff) ^ (ecx & 0xff)] ^ (ecx >> 8);

        for (i=0; i<numread; i++)
           {
           term[0] = fbuf[i];
           write(pf, term, 1);
           eax = (eax >> 8) ^  foo[(eax & 0xff) ^ (fbuf[i] & 0xff)];
           }
        crc2 = eax ^ 0xffffffff;
        term[0] = crc2 & 0xff;
        term[1] = (crc2 >> 8) & 0xff;
        term[2] = (crc2 >> 16) & 0xff;
        term[3] = (crc2 >> 24) & 0xff;
        write(pf, term, 4);
        }

     // Terminate upon completion of data
      if ( (rcv[strlen(rcv)-1]==0x20) &&
           (rcv[strlen(rcv)-2]==0x0a) &&
           (rcv[strlen(rcv)-3]==0x0d) &&
           (rcv[strlen(rcv)-4]=='>') &&
           (rcv[strlen(rcv)-5]==' ') &&
           (rcv[strlen(rcv)-6]=='y') &&
           (rcv[strlen(rcv)-7]=='d') &&
           (rcv[strlen(rcv)-8]=='a') &&
           (rcv[strlen(rcv)-9]=='e') &&
           (rcv[strlen(rcv)-10]=='R') )
        done = 1;
      }

   fclose(fptr);
   }

int main(int argc, char *argv[]) {
  struct  termios pts;  /* termios settings on port */
  struct  termios sts;  /* termios settings on stdout/in */
  struct sigaction sact;/* used to initialize the signal handler */
  int i,j;

  // Default to com1  
  strcpy(device, "/dev/ttyS0\0");

  /* parse command line */
  for (i = 1; i < argc; i++)
    {

    if (strncmp(argv[i], "-c", 2) == 0)
      {
      if (argv[i][2] == '\0')
        {
	// Quiry user for a command to send
        strcpy(param_name, TITLE);
        write(STDOUT_FILENO, param_name, strlen(param_name));
        strcpy(param_name, "Enter command: ");
        write(STDOUT_FILENO, param_name, strlen(param_name));
        j = read(STDIN_FILENO, param_name, MAX_COMMAND_NAME);
        param_name[j-1] = 0;
        }
      else
        // Send command that was included on command line
        strncpy(param_name, &argv[1][2], MAX_COMMAND_NAME);
      cmd = CMD_COMMAND;
      continue;
      }

   if (strncmp(argv[i], "-s", 2) == 0)
      {
      if (argv[i][2] == '\0')
        {
	// Quiry user for a command to send
        strcpy(param_name, TITLE);
        write(STDOUT_FILENO, param_name, strlen(param_name));
        strcpy(param_name, "Enter filename: ");
        write(STDOUT_FILENO, param_name, strlen(param_name));
        j = read(STDIN_FILENO, param_name, MAX_COMMAND_NAME);
        param_name[j-1] = 0;
        }
      else
        // Send command that was included on command line
        strncpy(param_name, &argv[1][2], MAX_COMMAND_NAME);
      if ((fptr = fopen(param_name,"r"))==NULL)
        {
        fprintf(stderr, "File '%s' not found.\n", param_name);
        exit(0);
        }
      fclose(fptr);
      cmd = CMD_SEND;
      continue;
      }

    if (strncmp(argv[i], "-d", 2) == 0)
      {
      if (argv[i][2] != '\0') /* we have a device */
	strncpy(device, &argv[i][2], MAX_DEVICE_NAME);
      continue;
      }

    if (strncmp(argv[i], "-?", 2) == 0 ||
	strncmp(argv[i], "-h", 2) == 0)
      {
      main_usage(0, "", "");
      exit(0);
      }
  }

  /* open the device */
  pf = open(device, O_RDWR);
  if (pf < 0)
    {
    main_usage(2, "cannot open device", device);
    exit(2);
    }

  /* modify the port configuration */
  tcgetattr(pf, &pts);
  memcpy(&pots, &pts, sizeof(pots));
  init_comm(&pts);
  tcsetattr(pf, TCSANOW, &pts);
     
  /* Now deal with the local terminal side */
  tcgetattr(STDIN_FILENO, &sts);
  memcpy(&sots, &sts, sizeof(sots)); /* to be used upon exit */
  init_stdin(&sts);
  tcsetattr(STDIN_FILENO, TCSANOW, &sts);

  /* set the signal handler to restore the old
   * termios handler */
  sact.sa_handler = cleanup_termios; 
  sigaction(SIGHUP, &sact, NULL);
  sigaction(SIGINT, &sact, NULL);
  sigaction(SIGPIPE, &sact, NULL);
  sigaction(SIGTERM, &sact, NULL);

   /* run the main program loop */
   switch (cmd)
     {
     case CMD_NONE :
       main_usage(0, "", ""); 
       break;
     case CMD_COMMAND :
       SendCommand(pf, param_name);
       break;
     case CMD_SEND :
       SendFile(pf, param_name);
       break;
     }
  /* restore original terminal settings and exit */
  tcsetattr(pf, TCSANOW, &pots);
  tcsetattr(STDIN_FILENO, TCSANOW, &sots);

  exit(0);

}
