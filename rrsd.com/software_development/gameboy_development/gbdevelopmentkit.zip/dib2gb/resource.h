//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by dib2gb.rc
//
#define IDR_MAINFRAME                   2
#define IDR_DIBTYPE                     3
#define IDS_DIB_TOO_BIG                 4
#define IDS_CANNOT_LOAD_DIB             5
#define IDS_CANNOT_SAVE_DIB             6
#define IDD_ABOUTBOX                    100
#define ID_FILE_SAVEALL                 32770
#define ID_FILE_SAVEALLAS               32771
#define ID_HELP_HELP                    32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         101
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
