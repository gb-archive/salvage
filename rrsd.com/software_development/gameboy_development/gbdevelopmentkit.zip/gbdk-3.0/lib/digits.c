const char * const digits = "0123456789ABCDEF";
