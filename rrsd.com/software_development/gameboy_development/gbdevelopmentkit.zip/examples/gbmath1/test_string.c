#include "types.h"
#include "assert.h"
#include <stdio.h>
#include <string.h>

void test_memcpy(){
}
void test_strcpy(){
}
void test_memcmp(){
}
void test_strcmp(){
}
void test_memset(){
}

void test_string(){
}
