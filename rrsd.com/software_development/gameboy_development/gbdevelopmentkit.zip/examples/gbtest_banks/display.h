extern void
display_set(UINT8 i, UINT8 value) banked ;
extern void
display_init() banked ;
extern void
display_update()  banked ;

#define BLANK_SPACE 16
