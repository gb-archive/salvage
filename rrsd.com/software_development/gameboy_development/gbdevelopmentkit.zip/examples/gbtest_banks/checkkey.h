extern void checkkey(void) banked;
extern void setkey(void) banked;
extern BOOL getloop() banked;
