#ifndef BANKS_H
#define BANKS_H

/* when switching between screens */
#if defined(DISPLAY_BANK) 
#pragma bank CODE_2
#endif

#if defined(KEY_BANK) 
#pragma bank CODE_3
#endif

#endif // BANKS_H
