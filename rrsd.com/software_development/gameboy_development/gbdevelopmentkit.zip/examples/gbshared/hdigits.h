extern const unsigned char hdigitsdata[];
extern const unsigned char hdigitstiles[];
extern UINT16 sizeof_hdigitsdata();
