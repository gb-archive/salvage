#include <gb/gb.h>

extern void
hex_display_set(UINT8 row, INT32 hx);
extern void
hex_display_update();
extern void
decimal_display_set(UINT8 row, INT32 hx);
extern void 
hex_display_reinit();
extern void
hex_display_init();
