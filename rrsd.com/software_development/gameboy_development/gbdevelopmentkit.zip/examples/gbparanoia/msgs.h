#include "paranoia.h"
#include "banks.h"

extern void Characteristics(VOID) banked;
extern void Heading(VOID) banked;
extern void History(VOID) banked;
extern void Instructions(VOID) banked;
