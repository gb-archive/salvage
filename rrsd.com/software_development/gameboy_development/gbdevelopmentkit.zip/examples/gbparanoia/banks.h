#ifndef BANKS_H
#define BANKS_H

#if defined(PART1_MODULE)
#pragma bank CODE_1
#endif

#if defined(PART2_MODULE)
#pragma bank CODE_2
#endif

#if defined(PART3_MODULE)
#pragma bank CODE_3
#endif

#if defined(PART4_MODULE)
#pragma bank CODE_4
#endif

#if defined(PART5_MODULE)
#pragma bank CODE_5
#endif

#if defined(PART6_MODULE)
#pragma bank CODE_6
#endif

#if defined(PART7_MODULE)
#pragma bank CODE_7
#endif

#if defined(PART8_MODULE)
#pragma bank CODE_7
#endif

#if defined(MSGS_MODULE)
#pragma bank CODE_1
#endif

#if defined(SUBS_MODULE)
#pragma bank CODE_1
#endif

#if defined(POWF_MODULE)
#pragma bank CODE_7
#endif

#if defined(PARANOIA_MODULE)
#pragma bank CODE_7
#endif

#endif /* BANKS_H */
