#include "banks.h"
#pragma bank PARANOIA_BANK;



#define BANK(x) #pragma bank x

BANK(PARANOIA_BANK)


