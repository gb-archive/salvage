#include <gb/gb.h> /* halt */
#include <stdio.h> /* printf */

#include "msgs.h"
#include "subs.h"
#include "paranoia.h"

void main(){
    printf("Hello World\n");
    /*
	Instructions();
	Pause();
	Heading();
	Pause();
	Characteristics();
	Pause();
	History();
	Pause();
    */
    Pause();part1();
	Pause();part2();
	Pause();part3();
	Pause();part4();
	Pause();part5();
	Pause();part6();
	Pause();part7();
	Pause();part8();
    printf("Bye World\n");
    halt();
}
