//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GBCart.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_GBCART_TYPE                 129
#define ID_PROGRAM_FAILED               129
#define ID_PROGRAM_VERIFY_FAIL          130
#define ID_PROGRAM_SUCCEED              131
#define IDD_TEST                        132
#define ID_PROGRAM_VERIFY_PASS          132
#define IDD_CONFIGURE                   133
#define ID_ERASE_PASSED                 133
#define ID_ERASE_FAILED                 134
#define ID_PROGRAM_VERIFY_FAIL2         135
#define IDC_D0_D7                       1000
#define IDC_A0_A7                       1001
#define IDC_A8_A15                      1002
#define IDC_CTRL                        1003
#define IDC_READ                        1004
#define IDC_WRITE                       1005
#define IDC_AUDIO_IN                    1006
#define IDC_BYTE                        1011
#define IDC_READ_BYTE                   1012
#define IDC_WRITE_BYTE                  1013
#define IDC_LOW                         1014
#define IDC_HIGH                        1015
#define IDC_SET_SIGNALS                 1017
#define IDC_MEMORY_TYPE                 1019
#define IDC_NOT_BANKED                  1020
#define IDC_BANKED                      1021
#define IDC_PORT_ADDRESS                1022
#define IDC_PROTECT                     1024
#define IDC_UNPROTECT                   1025
#define IDC_RADIO3                      1026
#define IDC_UNCHANGED                   1026
#define ID_PROGRAM_BLANCKCHECK          32780
#define ID_PROGRAM_PROGRAM              32783
#define ID_PROGRAM_VERIFY               32784
#define ID_PROGRAM_READ                 32785
#define ID_PROGRAM_BLANKCHECK           32786
#define ID_PROGRAM_ERASE                32787
#define ID_PROGRAM_HEADER               32788
#define ID_TEST                         32789
#define ID_SHOW_HEX_DATA                32790
#define ID_PROGRAM_STOP                 32791
#define ID_CONFIGURE                    32794

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32795
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
