//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by hwinterface.rc
//
#define IDS_HWINTERFACE                 1
#define IDD_ABOUTBOX_HWINTERFACE        1
#define IDB_HWINTERFACE                 1
#define IDI_ABOUTDLL                    1
#define IDS_HWINTERFACE_PPG             2
#define IDS_HWINTERFACE_PPG_CAPTION     200
#define IDD_PROPPAGE_HWINTERFACE        200
#define IDR_BIN1                        201
#define IDC_CURSOR1                     202

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        204
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
