/* GBTerminal for GameBoy */
/*  last edit 14-Dec-97   */
/*    by Jeff Frohwein    */
/*  GS version edited     */
/*    by Joshua Neal      */

/* Compiled with Microsoft C 6.0 */
/* GS Version Compiled with Borland C++ V3.1 */

/* Rev 1.3 - Modified for GB-to-PC, Rev D cable */
/* Rev 1.4 - Added upload file option */
/* Rev 1.5 - Added wait for ready after NEW command */
/* Rev 1.6 - Added -w option */
/* Rev 1.7 - Modified for Scott Kroeger's cable */
/* Rev GS  - Modified for Game Shark Pro cable */

#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <dos.h>
#include <time.h>

enum BOOLEAN
   {
   false,
   true
   };

#define CHAR_CR    13                   /* Ascii CR */
#define CHAR_LF    10                   /* Ascii LF */
#define GBB_IDLE 0x80                   /* Idle char used by GB Basic */
#define GBB_RDY     1                   /* Ready char used by GB Basic */
#define GBB_LST     2                   /* List Done used by GB Basic */
#define ESCAPE     27                   /* Key character to break */
#define EXIT_OKAY   0                   /* Routine exit was normal */
#define EXIT_BRK    1                   /* Routine exit from break key */
#define NUM_IDLE    5                   /* Number of idles for Contact */

#define DELAY   delay2(WaitDelay)

/* Change those defines to match your compiler. */
#define OUTPORT(port, val)      outp(port, val); DELAY
#define INPORT(port)		inp(port)

#define CTRL    ctrl_port
#define DATA    data_port
#define STATUS  status_port

/*
 * Bits for MUX (C B A):
 *      ~AUTOFDXT ~SCLINT ~STROBE
 * Bits in CTRL register (7..0):
 *      N/A N/A N/A IRQEnable ~SCLINT INIT ~AUTOFDXT ~STROBE
 */

#define MASK            0x00
#define nSTROBE         0x01
#define nAUTOFDXT       0x02
#define INIT            0x04
#define nSCLINT         0x08

/*
 * Bits read (7..0):
 *      BUSY ~ACKPR PE SLCT ERROR N/A N/A N/A
 * Bits from REGISTER (D7..D4, D3..D0):
 *      SLCT PE BUSY ~ACK
 */

#ifdef MK_FP
#undef MK_FP
#endif
#define MK_FP(seg, ofs)     ((void far *) ((unsigned long) (seg)<<16|(ofs)))


int WaitDelay;
unsigned ctrl_port;
unsigned data_port;
unsigned status_port;
char AddAuto;
char AddNew;
char AddRun;
char AddSave;
char DataPortValue;

void usage(void)
   {
   printf(" Usage: gsterm [-p int] [-b int] [-w int]\n");
   printf("            [-a] [-n] [-r] [-s] [-t] [-d | -u file[.bas]]\n");
   printf("\t-a\tAdd AUTO suffix to download\n");
   printf("\t-d\tDownload file (PC->GB)\n");
   printf("\t-n\tAdd NEW prefix to download\n");
   printf("\t-p\tSpecify the port to use (default is 1 = LPT1)\n");
   printf("\t-r\tAdd RUN suffix to download\n");
   printf("\t-s\tAdd SAVE suffix to download\n");
   printf("\t-t\tTerminal mode\n");
   printf("\t-u\tUpload file (GB->PC)\n");
   printf("\t-w\tWait delay for PC I/O (default is 500)\n");
   printf("\n");
   printf(" NOTE: Supports GB Basic V1.20 or later.\n");
   }

int init_port(int port)
   {
   data_port = *(unsigned far *) MK_FP(0x0040, 6 + 2 * port);
   if (data_port == 0)
      {
      printf("Can't find address of parallel port %d...\n", port);
      exit(1);
      }
   else
      {
      status_port = data_port + 1;
      ctrl_port = data_port + 2;
      printf("Parallel port %d is located at %Xh.\n", port, data_port);
      }
   }

void delay2(int d)
   {
   while (d--);
   }

/* Send & receive a byte with GameBoy     */
/* Entry: lock holds state of serial lock */

int SerialTransfer(enum BOOLEAN lock, char out)
   {
   short int b,
    z;
   b = 0;

   /* If serial lock hasn't yet been achieved   */
   /* then add extra clock to rotate into lock. */

   if (lock == false)
      {
//      OUTPORT(CTRL, 0x4);
//      OUTPORT(CTRL, 0xc);
//      DataPortValue &= ~2;
//      OUTPORT(DATA, DataPortValue);
//      DataPortValue |= 2;
//      OUTPORT(DATA, DataPortValue);
	OUTPORT(CTRL, 0x1);
	OUTPORT(CTRL, 0x0);

      }

   for (z = 0; z < 8; z++)
      {
//      OUTPORT(CTRL, 0x4);
//      DataPortValue &= ~2;
//      OUTPORT(DATA, DataPortValue);
	OUTPORT(CTRL, 0x1);
      if (out & 0x80)
	 {
//         OUTPORT(DATA, 0xff);
	 DataPortValue |= 1;
	 OUTPORT(DATA, DataPortValue);
	 }
      else
	 {
//         OUTPORT(DATA, 0xfe);
	 DataPortValue &= ~1;
	 OUTPORT(DATA, DataPortValue);
	 }
      out = out << 1;
//      OUTPORT(CTRL, 0xc);
//      DataPortValue |= 2;
//      OUTPORT(DATA, DataPortValue);
	OUTPORT(CTRL, 0x0);
      b = b << 1;
//      b = b + (((INPORT(CTRL) >> 1) & 1) ^ 1);
//j      b = b + (((INPORT(STATUS) >> 5) & 1));
      b = b + (((INPORT(STATUS) >> 6) & 1));

      }
   return (b);
   }

/* Delay then send & receive a byte with GameBoy. */
/* This gives GameBoy time to reload it's registers. */
/* Entry: lock holds state of serial lock */

int SerialTransferDelay(enum BOOLEAN lock, char out)
   {
   int i,j;

   for(i=0; i<(WaitDelay/10); i++)        //waitdelay/10
      {
      for(j=0; j<3; j++);
      }
   return (SerialTransfer(lock, out));
   }

/* Send & receive a byte with GameBoy then wait for ready */

int SerialTransferWait(char out)
   {
   short int a;

   a = ~GBB_RDY;
   while (a != GBB_RDY)
      {
      a = SerialTransferDelay(true, out);
      out = GBB_IDLE;

      /* Exit if break key pressed */
      if (kbhit())
	 if (getch() == ESCAPE)
	    return(EXIT_BRK);
      }
   return(EXIT_OKAY);
   }

/* if port not specified set to LPT1 */

void SetInitPort(void)
   {
   if (data_port == 0)
      init_port(1);
//   OUTPORT(DATA, 0xfe);     /* Pull diodes high on GB-to-PC cable */

      DataPortValue = 0xfe;
      OUTPORT(DATA, DataPortValue);
   }

 /* Wait for input ready character or escape */
char WaitReady(enum BOOLEAN lock, char c)
   {
   short int a;

   a = 0;
   while ((c != ESCAPE) && (a != GBB_RDY))
      {
      c = GBB_IDLE;
      a = SerialTransferDelay(lock, c);

      if (kbhit())
         c = getch();
      }
   return (c);
   }

/* Wait for CR character or escape */
char WaitCR(VOID)
   {
   short int a;
   char c;

   a = 0;
   while (a != CHAR_CR)
      {
      c = GBB_IDLE;
      a = SerialTransferDelay(true, c);

      /* Exit if break key pressed */
      if (kbhit())
         if (getch() == ESCAPE)
            return(EXIT_BRK);
      }
   return (EXIT_OKAY);
   }

/* Return on Serial Lock or break key */
/* Return: EXIT_OKAY or EXIT_BRK      */
char SerialLock(VOID)
   {
   char c;
   char GbbIdle = GBB_IDLE;
   short int a;
   short int cnt = 0;
   enum BOOLEAN lock = false;

   while (cnt < NUM_IDLE)
      {
      a = SerialTransferDelay(lock, GbbIdle);
//      printf("%x ",a);
      /* If we receive NUM_IDLE idles in a row then exit */

      if (a == GBB_IDLE)
         {
         lock = true;
         cnt++;
         }
      else
         {
	 lock = false;
	 cnt = 0;
         }

      /* Exit if break key pressed */
      if (kbhit())
         if (getch() == ESCAPE)
            return(EXIT_BRK);
      }

   /* Clear everything in GB Basic     */
   /* input buffer by sending '@' char */

   c = 0x40;
   if (SerialTransferWait(c) == EXIT_BRK)
      return(EXIT_BRK);

   /* Wait for Ready from GB Basic */
   c = WaitReady(true, c);

   return(EXIT_OKAY);
   }

void UploadFile(FILE * fp)
   {
   char c;
   char GbbIdle = GBB_IDLE;
   short int a;
   short int olda = GBB_IDLE;
   unsigned char val;
   enum BOOLEAN lock;

   printf("Press ESC to exit.\n");
   printf("Trying to contact GameBoy....\n");

   lock = true;
   c = 0;

   /* Wait for serial lock or escape key */

   if (SerialLock() == EXIT_BRK)
      return;

   printf("Uploading file...\n");

   /* Send LIST command */
   c = 'l';
   if (SerialTransferWait(c) == EXIT_BRK) return;
   c = 'i';
   if (SerialTransferWait(c) == EXIT_BRK) return;
   c = 's';
   if (SerialTransferWait(c) == EXIT_BRK) return;
   c = 't';
   if (SerialTransferWait(c) == EXIT_BRK) return;
   c = 13;
   a = SerialTransferDelay(lock, c);

   /* Wait for CR or break key */

   if (WaitCR() == EXIT_BRK)
      return;

   c = EXIT_OKAY;
   while (c != EXIT_BRK) /* && (a != GBB_LST) */
      {
      a = SerialTransferDelay(lock, GbbIdle);

      /* Check for end of file by looking*/
      /* for 'Ok'. If so, exit. */
      if ( (olda == CHAR_CR) &&
	   (a == 0x4f ) )
	 return;

      /* Keep a record of last valid char */
      if (a !=GBB_IDLE)
         olda = a;

      if ((a != GBB_IDLE) &&
          (a != GBB_RDY)  &&
	  (a != GBB_LST))
         {
         /* Print char to file */
         fputc(a, fp);

         /* if char is a CR add a LF */
         if (a==CHAR_CR)
            {
            a = CHAR_LF;
            fputc(a, fp);
            }
         }

      /* Exit if break key pressed */
      if (kbhit())
         if (getch() == ESCAPE)
            c = EXIT_BRK;
      }
   }

void DownloadFile(FILE * fp)
   {
   int byte;
   char c;
   char GbbIdle = 0x80;
   short int a,
    cnt,
    z;
   enum BOOLEAN lock;

   printf("Press ESC to exit.\n");
   printf("Trying to contact GameBoy....\n");

   lock = true;
   c = 0;

   /* Wait for serial lock or escape key */

   if (SerialLock() == EXIT_BRK)
      return;

   printf("Downloading file...\n");

   if (AddNew)
      {
      /* Send NEW command */
      c = 'n';
      if (SerialTransferWait(c) == EXIT_BRK) return;
      c = 'e';
      if (SerialTransferWait(c) == EXIT_BRK) return;
      c = 'w';
      if (SerialTransferWait(c) == EXIT_BRK) return;
      c = 13;
      if (SerialTransferWait(c) == EXIT_BRK) return;
      }

   /* If escape not pressed then download file */

   while (!feof(fp))
      {
      c = fgetc(fp);

      /* Ignore non-ascii stuff in file */
      if ((c != 10) && (c > 12) && (c < 129))
         {
	 if (SerialTransferWait(c) == EXIT_BRK)
            return;
         // printf("%hx ", c)
         }
      }

   if (AddSave)
      {
      /* Send SAVE command */
      c = 's';
      if (SerialTransferWait(c) == EXIT_BRK) return;
      c = 'a';
      if (SerialTransferWait(c) == EXIT_BRK) return;
      c = 'v';
      if (SerialTransferWait(c) == EXIT_BRK) return;
      c = 'e';
      if (SerialTransferWait(c) == EXIT_BRK) return;
      c = 13;
      if (SerialTransferWait(c) == EXIT_BRK) return;
      }

   if (AddAuto)
      {
      /* Send AUTO command */
      c = 'a';
      if (SerialTransferWait(c) == EXIT_BRK) return;
      c = 'u';
      if (SerialTransferWait(c) == EXIT_BRK) return;
      c = 't';
      if (SerialTransferWait(c) == EXIT_BRK) return;
      c = 'o';
      if (SerialTransferWait(c) == EXIT_BRK) return;
      c = 13;
      if (SerialTransferWait(c) == EXIT_BRK) return;
      }

   if (AddRun)
      {
      /* Send RUN command */
      c = 'r';
      if (SerialTransferWait(c) == EXIT_BRK) return;
      c = 'u';
      if (SerialTransferWait(c) == EXIT_BRK) return;
      c = 'n';
      if (SerialTransferWait(c) == EXIT_BRK) return;
      c = 13;
      a = SerialTransferDelay(lock, c);
      }
   }

void TerminalMode(void)
   {
   char c;
   short int a;
   enum BOOLEAN lock;

   printf("Press ESC to exit.\n");

   while (1==1)
      {

      printf("Trying to contact GameBoy....\n");

      /* Wait for serial lock or escape key */

      if (SerialLock() == EXIT_BRK)
         return;

      printf("Terminal mode.\n");

      lock = true;
      c = GBB_IDLE;
      while (lock == true)
         {
         a = SerialTransferDelay(true, c);
	 c = GBB_IDLE;

         if ( (a != GBB_IDLE) &&
              (a > 7) )
            {
            if (a == 13)
               printf("\n");
            else
               printf("%c", a);    /* printf("%hx ", a); */
            }

         /* Exit if break key pressed */
         if (kbhit())
            if ((c =getch()) == ESCAPE)
               return;

         /* Non-ascii char means serial lock lost */
         if (a>128)
            lock = false;
         }
      printf("\nSerial lock lost.\n");
      }
   }

void main(int argc, char **argv)
   {
   int arg;
   int PortValue;
   FILE *fp;
   char fname[20];

   WaitDelay = 500;

   data_port = 0;               /* Indicate port not selected */
   AddAuto = 0;                 /* default add AUTO off */
   AddNew = 0;                  /* default add NEW off */
   AddRun = 0;                  /* default add RUN off */

   printf("GameBoy Terminal V1.7, by Jeff Frohwein, 4-Apr-98\n");

   /* If no arguments then print help menu */
   if (argc < 2)
      {
      usage();
      exit(1);
      }

   for (arg = 1; arg < argc; arg++)
      {

      /* If invalid command line character then exit */
      if ( (argv[arg][0] != '-') ||
           (strlen(argv[arg]) != 2 ) )
         {
         usage();
         exit(1);
         }

      switch (argv[arg][1])
	 {
      case 'a':
      case 'A':
	 AddAuto = 1;
         break;
      case 'd':
      case 'D':
         /* Add extension .BAS if none present */
         strcpy(fname, argv[++arg]);
         if (strchr(fname, '.') == NULL)
            strcat(fname, ".bas");

         if ((fp = fopen(fname, "rb")) == NULL)
            {
            printf("Error opening file '%s'\n", fname);
            exit(1);
            }
         SetInitPort();
         DownloadFile(fp);
         fclose(fp);
         break;
      case 'n':
      case 'N':
         AddNew = 1;
         break;
      case 'p':
      case 'P':
         PortValue = atoi(argv[++arg]);
         if (PortValue == 0)
            {
            printf("Error: No port value given.\n");
            exit(1);
            }
         init_port(PortValue);
         break;
      case 'r':
      case 'R':
         AddRun = 1;
         break;
      case 's':
      case 'S':
	 AddSave = 1;
         break;
      case 't':
      case 'T':
         SetInitPort();
	 TerminalMode();
         break;
      case 'u':
      case 'U':
         /* Add extension .BAS if none present */
         strcpy(fname, argv[++arg]);
         if (strchr(fname, '.') == NULL)
            strcat(fname, ".bas");

         if ((fp = fopen(fname, "wb")) == NULL)
            {
            printf("Error opening file '%s'\n", fname);
            exit(1);
            }
         SetInitPort();
         UploadFile(fp);
         fclose(fp);
         break;
      case 'w':
      case 'W':
	 /* PC I/O delay for faster PCs */
         WaitDelay = atoi(argv[++arg]);
         if (WaitDelay == 0)
            {
	    printf("Error: No I/O delay value given.\n");
            exit(1);
            }
         break;
      default:
         usage();
	 exit(1);
         }
      }
   exit(0);
   }
