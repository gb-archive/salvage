GBA Example1 for CGBIDE - www.semis.demon.co.uk
===============================================

Example1 draws colour bars on the screen in graphics mode 4.

Install this example into: C:\devkitadv\MyProjects\exp1cgbide\

Please ensure:
 The DOS path (see Autoexec.bat) includes: C:\devkitadv\bin
 The CGBIDE 'User Defined Tool Location' is set to: C:\devkitadv\MyProjects\exp1cgbide\make.bat
 The C:\devkitadv\utils directory includes: Gbarm.exe (ROM manipulator)

List of files:
    exp1.gba    - GBA example1 ROM image
    exp1.gbp    - CGBIDE project file
    exp1.mak    - Make file for devkitadv
    exp1.wgb    - CGBIDE workspace file (load from CGBIDE)
    gbalib.c    - GBA library source file
    gbalib.h    - GBA library header file
    main.c      - Example1 source file
    make.bat    - Batch file to run Make file from CGBIDE
    readme.txt  - This file
