/*
 * PCIO Advance library implementation file
 * ----------------------------------------
 * Filename:    gfx4lib.c
 * Description: Graphics Mode 4 primitives
 * Version:     1.1
 * Date:        June 9th, 2002
 * Authors:     Steven Willis
 */

#include <stdio.h>
#include <stdarg.h>
#include "gbalib.h"
#include "gfx4lib.h"

/* Plot a pixel at 'x','y' in 'Colour' using logical 'Mode',
 * Mode[7]    selects between Frame buffer 0 or 1.
 * Mode[6:4]  reserved.
 * Mode[3:0]  Logical  Result,
 *   0          =        New Colour
 *   1          XOR      Current colour ^ New Colour 
 *   2          OR       Current colour | New Colour 
 *   3          AND      Current colour & New Colour 
 */
void Plot(u8 mode, u8 colour, u8 x, u8 y)
{
    u16  data, col;
    vu16 *pxladdr;

    // Make sure it's inside the screen
    if ((x <= MAX_SCNX) && (y <= MAX_SCNY)) {
        // Frame buffer 0 or 1
        if (mode & FRAME_BUF1)
            pxladdr = ((vu16 *)(VRAM_BASE1 + (x & 0xFE) + (y * 240)));
        else
            pxladdr = ((vu16 *)(VRAM_BASE0 + (x & 0xFE) + (y * 240)));

        // Plot in logical mode
        col = colour;
        switch ((mode << 1) | (x & 0x01)) {
            case 0:  *pxladdr = (*pxladdr & 0xFF00) | col;
                     break;
            case 1:  *pxladdr = (*pxladdr & 0x00FF) | (col << 8);
                     break;
            case 2:  *pxladdr = *pxladdr ^ col;
                     break;
            case 3:  *pxladdr = *pxladdr ^ (col << 8);
                     break;
            case 4:  *pxladdr = *pxladdr | col;
                     break;
            case 5:  *pxladdr = *pxladdr | (col << 8);
                     break;
            case 6:  *pxladdr = *pxladdr & col;
                     break;
            case 7:  *pxladdr = *pxladdr & (col << 8);
                     break;
            default: break;
        }
    }
}


// Draw line from 'x1','y1' to 'x2','y2' in 'Colour' using logical 'Mode'
void DrawLine(u8 mode, u8 colour, u8 x1, u8 y1, u8 x2, u8 y2)
{
    s16          x, y, dx, dy;
    register s16 x_inc, y_inc, p, c1, c2;

    dx = x2 - x1;
    dy = y2 - y1;
    x = x1;
    y = y1;
    Plot(mode, colour, x, y);

    if (abs(dy) > abs(dx)) {
        if (dx > 0)
            y_inc = 1;
        else
            y_inc = -1;

        if (dy > 0)
            x_inc = 1;
        else
            x_inc = -1;

        c1 = 2 * abs(dx);
        c2 = 2 * (abs(dx) -abs(dy));
        p  = 2 * abs(dx) -abs(dy);

        while ((x != x2) || (y != y2)) {
            if (p < 0)
                p += c1;
            else {
                p += c2;
                x += y_inc;
            }
            y += x_inc;
            Plot(mode, colour, x, y);
        }
    }
    else {
        if (dx > 0)
            x_inc = 1;
        else
            x_inc = -1;

        if (dy > 0)
            y_inc = 1;
        else
            y_inc = -1;

        c1 = 2 * abs(dy);
        c2 = 2 * (abs(dy) - abs(dx));
        p  = 2 * abs(dy) - abs(dx);

        while ((x != x2) || (y != y2)) {
            if (p < 0)
                p += c1;
            else {
                p += c2;
                y += y_inc;
            }
            x += x_inc;
            Plot(mode, colour, x, y);
        }
    }
}


// Draw rectangle from 'x1','y1' to 'x2','y2' in 'Colour' using logical 'Mode'
void DrawRectangle(u8 mode, u8 colour, u8 x1, u8 y1, u8 x2, u8 y2)
{
    DrawLine(mode, colour, x1, y1, x2, y1);
    DrawLine(mode, colour, x2, y1, x2, y2);
    DrawLine(mode, colour, x2, y2, x1, y2);
    DrawLine(mode, colour, x1, y2, x1, y1);
}


// Fill rectangle from 'x1','y1' to 'x2','y2' of 'Width' in 'Colour' using logical 'Mode'
void FillRectangle(u8 mode, u8 colour, u8 x1, u8 y1, u8 x2, u8 y2, u8 width)
{
	u8 loop, swop, x1f, y1f;

    // Order the rectangle with x1/y1 as upper/left
    if (x1 > x2) {
        swop = x1;
        x1   = x2;
        x2   = swop;
    }
    if (y1 > y2) {
        swop = y1;
        y1   = y2;
        y2   = swop;
    }

	// Fill the rectangle outwards from the start co-ordinates
    for(loop=0; loop < width; loop++) {
        x1f = (x1 > loop) ? (x1 - loop) : 0;
        y1f = (y1 > loop) ? (y1 - loop) : 0;
        DrawRectangle(mode, colour, x1f, y1f, (x2 + loop), (y2 + loop));
    }
}


// Draw circle from center 'x','y' of given 'Radius' in 'Colour' using logical 'Mode'
void DrawCircle(u8 mode, u8 colour, u8 x, u8 y, u8 radius)
{
    register s16 x1, y1, p;

    x1 = 0;
    y1 = radius;
    p = 3 - (2 * radius);
    while (x1 < y1) {
        Plot(mode, colour, x + y1, y + x1);
        Plot(mode, colour, x - y1, y + x1);
        Plot(mode, colour, x + y1, y - x1);
        Plot(mode, colour, x - y1, y - x1);
        Plot(mode, colour, x + x1, y + y1);
        Plot(mode, colour, x - x1, y + y1);
        Plot(mode, colour, x + x1, y - y1);
        Plot(mode, colour, x - x1, y - y1);
        if (p < 0)
            p += 4 * x1 + 6;
        else {
            p += 4 * (x1 - y1) + 10;
            y1--;
        }
        x1++;
    }
    if (y1 == x1) {
        Plot(mode, colour, x + y1, y + x1);
        Plot(mode, colour, x - y1, y + x1);
        Plot(mode, colour, x + y1, y - x1);
        Plot(mode, colour, x - y1, y - x1);
        Plot(mode, colour, x + x1, y + y1);
        Plot(mode, colour, x - x1, y + y1);
        Plot(mode, colour, x + x1, y - y1);
        Plot(mode, colour, x - x1, y - y1);
    }
}


// Fill circle from center 'x','y' of given 'Radius' and 'Width' in 'Colour'
// using logical 'Mode'
void FillCircle(u8 mode, u8 colour, u8 x, u8 y, u8 radius, u8 width)
{
	u8 loop;
	
	// A second offset circle is also drawn to fill in the gaps
    for(loop=0; loop < width; loop++) {
		DrawCircle(mode, colour, x, y, (radius + loop));
		DrawCircle(mode, colour, (x + 1), y, (radius + loop));
	}
}


/* Draw character at 'x','y' of given 'Style' in 'Colour' using logical 'Mode'
 * Style[7] sets double height characters.
 * Style[6] sets background to 'Colour' and character to black (used for variables).
 * Style[1:0],
 *   0 Forwards
 *   1 Down
 *   2 Backwards
 *   3 Up
 */
void DrawChar(u8 mode, u8 colour, u8 x, u8 y, u8 style, unsigned char ascii)
{
    u8          size, chrcol;
    register u8 xpxl, ypxl, xplot, yplot;

    size   = (style & 0x80) ? 1 : 0;
    chrcol = (style & 0x40) ? BLACK : colour;
    
    /* Calculate starting offsets for different rotations */
    switch (style & 3) {
        case 0:  break;
        case 1:  x = x - (FONT_HEIGHT - 1);
                 break;
        case 2:  x = x - (FONT_WIDTH  - 1);
                 y = y - (FONT_HEIGHT - 1);
                 break;
        case 3:  y = y - (FONT_WIDTH  - 1);
                 break;
        default: x = 0;
                 y = 0;
                 break;
    }

    // Plot pixel image of ascii character
    for (ypxl = 0; ypxl < FONT_HEIGHT; ypxl++) {
        for (xpxl = 0; xpxl < FONT_WIDTH; xpxl++) {
            switch (style & 0x03) {
                case 0:  xplot = (xpxl << size) + x;
                         yplot = (ypxl << size) + y;
                         break;
                case 1:  xplot = ((FONT_HEIGHT << size) - (ypxl << size) - 1) + x;
                         yplot = (xpxl << size) + y;
                         break;
                case 2:  xplot = (((FONT_WIDTH << size) - 1) - (xpxl << size)) + x;
                         yplot = ((FONT_HEIGHT << size) - (ypxl << size) - 1 ) + y;
                         break;
                case 3:  xplot = (ypxl << size) + x;
                         yplot = (((FONT_WIDTH << size) - 1) - (xpxl << size)) + y;
                         break;
                default: xplot = 0;
                         yplot = 0;
                         break;
            }
            // Plot character
            if (Font8x8[ascii][ypxl] & (1 << (7 - xpxl))) {
                Plot(mode, chrcol, xplot  , yplot);
                if (size) {
                    Plot(mode, chrcol, xplot+1, yplot);
                    Plot(mode, chrcol, xplot  , yplot+1);
                    Plot(mode, chrcol, xplot+1, yplot+1);
                }
            }
            // Plot background
            else if (style & 0x40) {
                Plot(mode, colour, xplot  , yplot);
                if (size) {
                    Plot(mode, colour, xplot+1, yplot);
                    Plot(mode, colour, xplot  , yplot+1);
                    Plot(mode, colour, xplot+1, yplot+1);
                }
            }
        }
    }
}


// Draw string at 'x','y' of given 'Style' in 'Colour' using logical 'Mode'
void DrawString(u8 mode, u8 colour, u8 x, u8 y, u8 style, char *s)
{
    u8 loop, size;

    size = (style & 0x80) ? 1 : 0;
    for (loop = 0; loop < strlen(s); loop++) {
        // Draw the character
        DrawChar(mode, colour, x, y, style, s[loop]);

        // Move to the new charater position
        switch (style & 0x03) {
            case 0: x += (FONT_WIDTH << size);
                    break;
            case 1: y += (FONT_WIDTH << size);
                    break;
            case 2: x -= (FONT_WIDTH << size);
                    break;
            case 3: y -= (FONT_WIDTH << size);
                    break;
            default:break;
        }
    }
}


// Draw with printf function 'x','y' of given 'Style' in 'Colour'
// using logical 'Mode'
void Gprintf(u8 mode, u8 colour, u8 x, u8 y, u8 style, const char *infmt, ...)
{
    va_list ap;
    u8      strn[255];

    // Use vsprintf if non-null arg list
    va_start(ap, infmt);
    if(ap != NULL)
        vsprintf((char *) strn, infmt, ap);
    else
        strcpy(strn, infmt);
    strn[255] = 0;
    DrawString(mode, colour, x, y, style, strn);
}


// Draw progress box from 'x1','y1' to 'x2','x2' with 'Percent' done
// in 'Colour' using logical 'Mode'
void DrawProgress(u8 mode, u8 colour, u8 x1, u8 y1, u8 x2, u8 y2, u8 percent)
{
    u8  xoffset;

    for (xoffset = 0; xoffset <= ((x2 - x1) * percent / 100); xoffset++)
        DrawLine(mode, colour, (x1 + xoffset), y1, (x1 + xoffset), y2);
    DrawRectangle(mode, BLACK, x1, y1, x2, y2);
}


// Set a window in the screen from 'x1','y1' to 'x2','x2' in 'Colour' using logical 'Mode'
void SetWindow(u8 mode, u8 colour, u8 x1, u8 y1, u8 x2, u8 y2)
{
    u8 x, y;
    
    for(y = y1; y <= y2; y++) {
        for(x = x1; x <= x2; x++)
            Plot(mode, colour, x, y);
    }
}


// Clear the whole screen to 'Colour', using frame defined in 'Mode'
// Note: logical 'Mode' settings have no effect
void ClearScreen(u8 mode, u8 colour)
{
    u16  scnword, loop, framesize;
    vu8  *frameptr;

    // Clear the defined frame
    framesize = (MAX_SCNX + 1) * (MAX_SCNY + 1);
    frameptr  = (mode & FRAME_BUF1) ? (u8 *)VRAM_BASE1 : (u8 *)VRAM_BASE0;
    scnword   = colour;
    for (loop = 0; loop <= framesize; loop++)
        *(frameptr++) = scnword;
}


// Move the 'cursor' type to 'mousex','mousey'
void MoveCursor(u16 cursor, u8 mousex, u8 mousey)
{
    vu16 *obja;

    obja = (u16 *)OAM_BASE;
    *(obja++) = 0x2000 | mousey;
    *(obja++) = 0x0000 | mousex;
    *(obja++) = 0x0000 | cursor;
}


// Initiate graphics mode 4
void InitGraphics(void)
{
   	u32  loop;
	vu16 *palette, *oamdat;

    // Select mode 4
	*DISPCNT = DISP_OBJ | DISP_MODE(4) | DISP_OAM_1D | DISP_BG2;
    *BG2CNT  = 0;
    *BG2X    = 0;
    *BG2Y    = 0;

	// Load the 64 colour background palette (could be 256 colour)
	palette = (u16 *)BG_PAL;
	for (loop = 0; loop < 64; loop++)
		*(palette++) = Pal64[loop];

	// Load the 64 colour object palette (could be 256 colour)
	palette = (u16 *)OBJ_PAL;
	for (loop = 0; loop < 64; loop++)
		*(palette++) = Pal64[loop];
	*(palette++) = 0x0000;

	// Move all objects off the screen
	oamdat = (u16 *)OAM_BASE;
    for (loop = 0; loop < (128 * 7); loop += 7) {
		*(oamdat++) = 0x22FF;
		*(oamdat++) = 0x01FF;
		*(oamdat++) = 0x0000;
		*(oamdat++) = 0x0000;
		*(oamdat++) = 0x0000;
		*(oamdat++) = 0x0000;
		*(oamdat++) = 0x0000;
    }

	// Load the cursors into object 0/1
	oamdat = (u16 *)OBJ_CHR1;
    for (loop = 0; loop < 32; loop++)
		*(oamdat++) = Cursor1[loop];
    for (loop = 0; loop < 32; loop++)
		*(oamdat++) = Cursor2[loop];

    // Clear VRAM
    ClearScreen(0, WHITE);
}
