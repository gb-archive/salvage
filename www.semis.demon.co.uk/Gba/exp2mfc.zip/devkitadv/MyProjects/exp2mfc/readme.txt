GBA Example2 for MFC Visual C++ 6.0 - www.semis.demon.co.uk
===========================================================

Example2 draws colour graphics and text on the screen in graphics mode 4.

Install this example into: C:\devkitadv\MyProjects\exp2mfc\

Please ensure:
 The DOS path (see Autoexec.bat) includes: C:\devkitadv\bin
 The C:\devkitadv\utils directory includes: Gbarm.exe (ROM manipulator)

List of files:
    exp2.gba    - GBA example2 ROM image
    exp2.mak    - Make file for devkitadv
    exp2mfc.dsp - Visual C++ 6.0 project file
    exp2mfc.dsw - Visual C++ 6.0 workspace file (load from MFC)
    fixrom.bat  - Batch file to fix the ROM using Gbarm.exe
    gbalib.c    - GBA library source file
    gbalib.h    - GBA library header file
    gfx4lib.c   - Mode 4 graphics library source file
    gfx4lib.h   - Mode 4 graphics library header file
    main.c      - Example2 source file
    readme.txt  - This file
