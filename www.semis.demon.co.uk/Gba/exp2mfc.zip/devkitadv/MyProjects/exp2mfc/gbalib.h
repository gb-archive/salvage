/*
 * Gameboy Advance library header file
 * -----------------------------------
 * Filename:    gbalib.h
 * Description: GBA interface primitives
 * Version:     1.0
 * Date:        June 9th, 2002
 * Authors:     Steven Willis
 */

#ifndef _gbalib_h
#define _gbalib_h


// Type Definitions
typedef	unsigned char                   u8;
typedef unsigned short int              u16;
typedef unsigned int                    u32;
typedef unsigned long long int          u64;
typedef volatile unsigned char          vu8;
typedef volatile unsigned short int     vu16;
typedef volatile unsigned int           vu32;
typedef volatile unsigned long long int vu64;
typedef signed char             		s8;
typedef signed short int        		s16;
typedef signed int              		s32;
typedef signed long long int    		s64;


// Graphics memory
#define VIDC_BASE       	0x04000000                  // Video registers base address
#define VRAM_BASE0      	0x06000000                  // VRAM base address frame 0
#define VRAM_BASE1      	0x0600A000                  // VRAM base address frame 1
#define BG_PAL          	0x05000000                  // Background palette (256 * 16bits)
#define OBJ_PAL         	0x05000200                  // Object palette (256 * 16bits)
#define OBJ_CHR0        	0x06010000					// OBJ character data Modes 0,1,2
#define OBJ_CHR1        	0x06014000					// OBJ character data Modes 3,4,5
#define OAM_BASE        	0x07000000					// OAM base address

// Graphics registers
#define DISPCNT         	(vu16*)(VIDC_BASE)          // Display control
#define DISPSTAT        	(vu16*)(VIDC_BASE + 0x4)    // Display status
#define VCOUNT          	(vu16*)(VIDC_BASE + 0x6)    // Vertical row count
#define BG0CNT          	(vu16*)(VIDC_BASE + 0x8)    // Background screen control
#define BG1CNT          	(vu16*)(VIDC_BASE + 0xA)
#define BG2CNT          	(vu16*)(VIDC_BASE + 0xC)    // Used for mode 4
#define BG3CNT          	(vu16*)(VIDC_BASE + 0xE)
#define BG0X            	(vu16*)(VIDC_BASE + 0x10)   // Background scrolling offsets
#define BG0Y            	(vu16*)(VIDC_BASE + 0x12)
#define BG1X            	(vu16*)(VIDC_BASE + 0x14)
#define BG1Y            	(vu16*)(VIDC_BASE + 0x16)
#define BG2X            	(vu16*)(VIDC_BASE + 0x18)
#define BG2Y            	(vu16*)(VIDC_BASE + 0x1A)
#define BG3X            	(vu16*)(VIDC_BASE + 0x1C)
#define BG3Y            	(vu16*)(VIDC_BASE + 0x1E)
#define MOSAIC          	(vu16*)(VIDC_BASE + 0x4C)   // Mosaic Control
#define BLDMOD          	(vu16*)(VIDC_BASE + 0x50)   // Blending ControlRegister
#define COLEV           	(vu16*)(VIDC_BASE + 0x52)
#define COLY            	(vu16*)(VIDC_BASE + 0x54)

// Graphics DISPCNT bit defines
#define DISP_MODE(n)		(n & 7)						// Display Mode Number
#define DISP_FBSEL			0x10						// Frame Buffer Select
#define DISP_HBLPROC		0x20						// H-Blank processing
#define DISP_OAM_1D			0x40						// OAM 1D/2D
#define DISP_DISABLE		0x80						// Display Disable
#define DISP_BG0			0x100						// BG 0 Enable
#define DISP_BG1			0x200						// BG 1 Enable
#define DISP_BG2			0x400						// BG 2 Enable
#define DISP_BG3			0x800						// BG 3 Enable
#define DISP_OBJ			0x1000						// OBJ Enable
#define DISP_WINDOW(n)		(( n & 3 ) << 13)			// Window Select/Enable
#define DISP_OWNABLE		0x8000						// OBJ Window display

// Misc. Graphics defines
#define MAX_SCNX        	239                         // Maximum screen X position
#define MAX_SCNY        	159                         // Maximum screen Y position
#define RGB(r,g,b)			((((b)>>3)<<10)+(((g)>>3)<<5)+((r)>>3))


// Serial Communication Registers
#define SIO_BASE            0x04000000
#define SIODATA32_L			(vu16*)(SIO_BASE + 0x120)	// 32 bit serial data low register
#define SIODATA32_H			(vu16*)(SIO_BASE + 0x122)	// 32 bit serial data high register
#define SIOCNT     			(vu16*)(SIO_BASE + 0x128)	// Serial control register
#define SIODATA8			(vu16*)(SIO_BASE + 0x12A)	// 8 bit serial data register
#define RCNT 	    		(vu16*)(SIO_BASE + 0x134)	// Communications function

// Normal Communications SIOCNT bits
#define SIO_INTCLK		    0x0001                      // Internal clock as sender
#define SIO_2MHZ		    0x0002                      // 2MHz clock (/256KHz)
#define SIO_SIFLAG		    0x0004                      // Reads the SI pin level
#define SIO_SOSET		    0x0008                      // Sets the SO pin level
#define SIO_SLAVE		    0x0008                      // Slave 1 ID (/Master)
#define SIO_START		    0x0080                      // Start serial transfer
#define SIO_32BIT		    0x1000                      // 32 bit mode (/8 bit)
#define SIO_IRQEN		    0x4000                      // Interrupt enable after transfer

// General Purpose Communications RCNT bits
#define GBASC               0x0001                      // Serial clock
#define GBASD               0x0002                      // Serial data
#define GBASI               0x0004                      // Serial input
#define GBASO               0x0008                      // Serial output
#define GBASCDIR            0x0010                      // Serial clock direction (1 = O/P)
#define GBASDDIR            0x0020                      // Serial data direction
#define GBASIDIR            0x0040                      // Serial input direction
#define GBASODIR            0x0080                      // Serial output direction

// RCNT Communications mode set
#define RCNT_NORM		    0x0000                      // Normal mode
#define RCNT_GEN		    0x8000                      // General purpose mode
#define RCNT_JOY		    0xC000                      // Joy bus mode


// Timer Registers
#define TIMER_BASE          0x04000000
#define TM0CNT_L			(vu16*)(TIMER_BASE + 0x100)	// Timer 0 data (16 bit)
#define TM0CNT_H			(vu16*)(TIMER_BASE + 0x102)	// Timer 0 control
#define TM1CNT_L			(vu16*)(TIMER_BASE + 0x104)	// Timer 1 data (16 bit)
#define TM1CNT_H			(vu16*)(TIMER_BASE + 0x106)	// Timer 1 control
#define TM2CNT_L			(vu16*)(TIMER_BASE + 0x108)	// Timer 2 data (16 bit)
#define TM2CNT_H			(vu16*)(TIMER_BASE + 0x10A)	// Timer 2 control
#define TM3CNT_L			(vu16*)(TIMER_BASE + 0x10C)	// Timer 3 data (16 bit)
#define TM3CNT_H			(vu16*)(TIMER_BASE + 0x10E)	// Timer 3 control

// Timer control bits
#define TIMER_P0 		    0x0000                      // No    prescalar (59.595ns)
#define TIMER_P64		    0x0001                      // /64   prescalar (3.814us)
#define TIMER_P256		    0x0002                      // /256  prescalar (15.256us)
#define TIMER_P1024		    0x0003                      // /1024 prescalar (61.025us)
#define TIMER_CH1P		    0x0004                      // Count when TM1CNT_L overflows
#define TIMER_INT		    0x0040                      // Timer interrupt enable
#define TIMER_EN		    0x0080                      // Timer enable


// User Keys
#define REG_KEYS			(vu16*)(VIDC_BASE + 0x130)	// Key Status
#define KEY_A				(0x0001)
#define	KEY_B				(0x0002)
#define KEY_SELECT			(0x0004)
#define KEY_START			(0x0008)
#define KEY_RIGHT			(0x0010)
#define KEY_LEFT			(0x0020)
#define KEY_UP				(0x0040)
#define	KEY_DOWN			(0x0080)
#define	KEY_R				(0x0100)
#define	KEY_L				(0x0200)


// Misc. defines
#ifndef NULL
#define	NULL	0
#endif
#ifndef FALSE
#define	FALSE   0
#endif
#ifndef TRUE
#define	TRUE    1
#endif


// External function definitions
extern void Sleep    (u32 delay);						// Sleep for delay*mS
extern void Sleepus  (u32 delay);						// Sleep for delay*uS

#endif
