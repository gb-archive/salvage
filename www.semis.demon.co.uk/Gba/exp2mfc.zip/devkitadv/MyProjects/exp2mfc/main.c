/*
 * Example2 implementation file
 * ----------------------------
 * Filename:    main.c
 * Description: Paint demonstration program
 * Version:     1.0
 * Date:        June 9th, 2002
 * Authors:     Steven Willis
 */

#include "gbalib.h"
#include "gfx4lib.h"

#define ProgramVersion  1

int main(void)
{
    u8   mousex, mousey;
   	u32  loop, buttons;

	// Setup graphics screen in mode 4
	InitGraphics();

	// Draw a screen grid
	for (loop = 15; loop <= 235; loop += 20)
		DrawLine(0, GRAY, loop, 10, loop, 130);
	for (loop =  10; loop <= 130; loop += 20)
		DrawLine(0, GRAY, 15, loop, 235, loop);

    // Fill the screen with coloured shapes
	FillCircle   (0,    RED, 125, 70,   0,  16);
	FillCircle   (0,  GREEN, 125, 70,  20,   2);
    FillRectangle(0, ORANGE,  45, 25, 205, 115, 5);

	// Write some text
    Gprintf(0, BLACK, 20, 140, 0x80, "Example2 ver%d", ProgramVersion);
    Gprintf(0,   RED, 1,  159,    3, "www.semis.demo.co.uk");
	
	// Draw a cursor
	mousex = MAX_SCNX / 2;
	mousey = MAX_SCNY / 2;
	do {
		// Move the cursor
		if ((~*REG_KEYS & KEY_LEFT)  && (mousex > 0))
			mousex--;
		if ((~*REG_KEYS & KEY_RIGHT) && (mousex < MAX_SCNX))
			mousex++;
		if ((~*REG_KEYS & KEY_UP)    && (mousey > 0))
			mousey--;
		if ((~*REG_KEYS & KEY_DOWN)  && (mousey < MAX_SCNY))
			mousey++;
		MoveCursor(CURSOR1, mousex, mousey);

		// Display mousex/y values
    	Gprintf(0, WHITE, 140, 0, 0x40, "X:%3d Y:%3d", mousex, mousey);

		// Draw if 'A' key is down
		if (~*REG_KEYS & KEY_A)
			FillCircle(0, BLUE, mousex, mousey, 0, 3);
		else
			Sleep(1);

	} while(1);
}
