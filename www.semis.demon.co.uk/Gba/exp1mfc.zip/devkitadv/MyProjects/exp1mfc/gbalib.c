/*
 * Gameboy Advance library implementation file
 * -------------------------------------------
 * Filename:    pcioalib.c
 * Description: GBA interface primitives
 * Version:     1.0
 * Date:        Feb 4th, 2002
 * Authors:     Steven Willis
 */

#include "gbalib.h"

// Delay n*ms
void Sleep(u32 delay)
{
    // Use Timer 2, set the timer and prescalar for 59.595ns counts
    *TM2CNT_H = TIMER_P0;
    *TM2CNT_L = 0;
    *TM2CNT_H = TIMER_EN | TIMER_P0;

    // Delay time is 'delay' * 16780 * 59.595ns
    do {
        if (*TM2CNT_L >= 16780) {
            *TM2CNT_H = TIMER_P0;
            *TM2CNT_L = 0;
            *TM2CNT_H = TIMER_EN | TIMER_P0;
            delay--;
        }
    } while(delay);
}


// Delay n*us
void Sleepus(u32 delay)
{
    // Use Timer 2, set the timer and prescalar for 59.595ns counts
    *TM2CNT_H = TIMER_P0;
    *TM2CNT_L = 0;
    *TM2CNT_H = TIMER_EN | TIMER_P0;

    // Delay time is 'delay' * 17 * 59.595ns
    do {
        if (*TM2CNT_L >= 17) {
            *TM2CNT_H = TIMER_P0;
            *TM2CNT_L = 0;
            *TM2CNT_H = TIMER_EN | TIMER_P0;
            delay--;
        }
    } while(delay);
}

