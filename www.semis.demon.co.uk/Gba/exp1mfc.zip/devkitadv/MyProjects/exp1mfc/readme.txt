GBA Example1 for MFC Visual C++ 6.0 - www.semis.demon.co.uk
===========================================================

Example1 draws colour bars on the screen in graphics mode 4.

Install this example into: C:\devkitadv\MyProjects\exp1mfc\

Please ensure:
 The DOS path (see Autoexec.bat) includes: C:\devkitadv\bin
 The C:\devkitadv\utils directory includes: Gbarm.exe (ROM manipulator)

List of files:
    exp1.gba    - GBA example1 ROM image
    exp1mfc.dsp - Visual C++ 6.0 project file
    exp1.mak    - Make file for devkitadv
    exp1mfc.dsw - Visual C++ 6.0 workspace file (load from MFC)
    fixrom.bat  - Batch file to fix the ROM using Gbarm.exe
    gbalib.c    - GBA library source file
    gbalib.h    - GBA library header file
    main.c      - Example1 source file
    readme.txt  - This file
