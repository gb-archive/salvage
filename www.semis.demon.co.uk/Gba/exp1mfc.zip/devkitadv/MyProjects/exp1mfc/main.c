/*
 * Example1 implementation file
 * ----------------------------
 * Filename:    main.c
 * Description: Paint demonstration program
 * Version:     1.0
 * Date:        June 8th, 2002
 * Authors:     Steven Willis
 */

#include "gbalib.h"

// Initiate graphics mode 4
void InitGraphics(void)
{
   	u32  loop, framesize;
	vu16 *palette;
	vu8  *frameptr;

    // Select mode 4
	*DISPCNT = DISP_OBJ | DISP_MODE(4) | DISP_OAM_1D | DISP_BG2;
    *BG2CNT  = 0;
    *BG2X    = 0;
    *BG2Y    = 0;

	// Load a simple 8 colour background palette (could be 256 colour)
	palette = (u16 *)BG_PAL;
	*(palette++) = RGB(  0,  0,  0);
	*(palette++) = RGB(  0,  0,255);
	*(palette++) = RGB(  0,255,  0);
	*(palette++) = RGB(  0,255,255);
	*(palette++) = RGB(255,  0,  0);
	*(palette++) = RGB(255,  0,255);
	*(palette++) = RGB(255,255,  0);
	*(palette++) = RGB(255,255,255);

    // Clear the VRAM screen
    framesize = (MAX_SCNX + 1) * (MAX_SCNY + 1);
    frameptr  = (u8 *)VRAM_BASE0;
    for (loop = 0; loop < framesize; loop++)
        *(frameptr++) = 0;
}

int main(void)
{
   	u32  loop, x, framesize;
   	vu16 colour;
	vu8 *frameptr;

	// Setup graphics screen in mode 4
	InitGraphics();

    // Fill the screen with colour bars
    framesize = ((MAX_SCNX / 30) + 1) * (MAX_SCNY + 1);
    frameptr  = (u8 *)VRAM_BASE0;
    colour 	  = 0;
    
    for (loop = 0; loop < framesize; loop++) {
    	for (x = 0; x < 30; x++)
    		*(frameptr++) = (colour & 0x07);
    	colour++;
	}	

	while(1);
}
