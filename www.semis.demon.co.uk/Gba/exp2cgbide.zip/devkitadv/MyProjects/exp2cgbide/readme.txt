GBA Example2 for CGBIDE - www.semis.demon.co.uk
===============================================

Example2 draws colour graphics and text on the screen in graphics mode 4.

Install this example into: C:\devkitadv\MyProjects\exp2cgbide\

Please ensure:
 The DOS path (see Autoexec.bat) includes: C:\devkitadv\bin
 The CGBIDE 'User Defined Tool Location' is set to: C:\devkitadv\MyProjects\exp2cgbide\make.bat
 The C:\devkitadv\utils directory includes: Gbarm.exe (ROM manipulator)

List of files:
    exp2.gba    - GBA example2 ROM image
    exp2.gbp    - CGBIDE project file
    exp2.mak    - Make file for devkitadv
    exp2.wgb    - CGBIDE workspace file (load from CGBIDE)
    gbalib.c    - GBA library source file
    gbalib.h    - GBA library header file
    gfx4lib.c   - Mode 4 graphics library source file
    gfx4lib.h   - Mode 4 graphics library header file
    main.c      - Example2 source file
    make.bat    - Batch file to run Make file from CGBIDE
    readme.txt  - This file
