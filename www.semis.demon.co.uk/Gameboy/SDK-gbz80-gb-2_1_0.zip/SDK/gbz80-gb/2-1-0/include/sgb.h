#ifndef _SGB_H
#define _SGB_H

UBYTE
sgb_check(void);
/* Return a non-null value if running on Super GameBoy */

#endif /* _SGB_H */
