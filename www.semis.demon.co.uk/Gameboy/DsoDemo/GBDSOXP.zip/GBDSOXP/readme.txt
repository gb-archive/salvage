GBDSO Grab for Windows XP
=========================

These files will allow the GBDSO grab utility to operate under Windows XP
without the Windows exception errors caused by the direct port access.

1. Copy these files to a working area e.g. C:\GBDSOgrab\

2. Copy UserPort.sys to ..\WINDOWS\system32\drivers\

3. Run UserPort.exe,
    - Select the defaults in both windows (or your LPT port if you know it)
    - Press 'Update'
    - Press 'Start'

Now run dsograb.exe and press 'Test' you should not get any Windows exception
errors. If you reboot your PC the driver should automatically load so you can
run dsograb.exe straight away.

To remove the driver delete ..\WINDOWS\system32\drivers\UserPort.sys then run
UserPort.exe and press 'Stop'.


-- end of readme.txt --
